# KeychainOS Pending Features Pack

Includes all pending modules from the latest design review plus NFC.

NFC requires external NFC hardware such as a PN532-class module. The pack provides an abstraction and UI shell but does not assume pin wiring.

Remote modules are safe shells and protocol helpers. Computer control requires a companion receiver app. MQTT needs `umqtt.simple`. USB HID requires suitable firmware support. Infrared, battery, audio, haptic, and physical-button modules report hardware-not-installed until configured.

The display benchmark at 60/80 MHz is experimental. Run it deliberately and restore 20 MHz afterward.

No final main.py is included, by design.
