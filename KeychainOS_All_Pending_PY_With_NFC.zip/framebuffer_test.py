"""Allocate a 240x320 RGB565 framebuffer, preferring PSRAM if exposed."""
import framebuf,gc
def create():
    buffer=bytearray(240*320*2); return buffer,framebuf.FrameBuffer(buffer,240,320,framebuf.RGB565)
def run(display,touch,ui):
    buffer,fb=create(); fb.fill(0x001F); fb.text('FRAMEBUFFER',70,150,0xFFFF); display.set_window(0,0,239,319); display.cs.value(0); display.dc.value(1); display.spi.write(buffer); display.cs.value(1)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return 'EXIT'
