"""Wi-Fi computer companion remote command client."""
import json
try:
    import requests
except ImportError:
    import urequests as requests

def command(base_url,name,value=None):
    payload=json.dumps({'command':name,'value':value}); response=requests.post(base_url,data=payload,headers={'Content-Type':'application/json'})
    try: return response.status_code
    finally: response.close()
COMMANDS=('PLAY_PAUSE','NEXT','PREVIOUS','VOLUME_UP','VOLUME_DOWN','MUTE','LOCK')
