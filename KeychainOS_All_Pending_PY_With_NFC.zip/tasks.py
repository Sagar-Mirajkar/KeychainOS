"""Persistent task list."""
import json
FILE='/tasks.json'
def load():
    try:return json.load(open(FILE,'r'))
    except Exception:return []
def save(items):json.dump(items,open(FILE,'w'))
def add(title,priority='NORMAL',due=None):
    items=load(); items.append({'title':title,'priority':priority,'due':due,'done':False}); save(items); return items
