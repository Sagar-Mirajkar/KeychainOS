"""Persistent calendar events."""
import json
FILE='/calendar_events.json'
def load():
    try:return json.load(open(FILE,'r'))
    except Exception:return []
def add(title,year,month,day,hour=0,minute=0,repeat=None):
    items=load(); items.append({'title':title,'date':[year,month,day,hour,minute],'repeat':repeat}); json.dump(items,open(FILE,'w')); return items
