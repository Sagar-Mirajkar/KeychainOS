"""Configurable HTTP remote requests."""
try:
    import requests
except ImportError:
    import urequests as requests

def send(url,method='GET',body=None,headers=None):
    method=method.upper(); response=requests.get(url,headers=headers) if method=='GET' else requests.post(url,data=body,headers=headers)
    try: return response.status_code,response.text
    finally: response.close()

def run(display,touch,ui):
    display.fill(0x0841); ui.centred_text(display,'HTTP REMOTE',50,0x07FF,0x0841); ui.centred_text(display,'Configure profiles first',140,0xFFFF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return 'EXIT'
