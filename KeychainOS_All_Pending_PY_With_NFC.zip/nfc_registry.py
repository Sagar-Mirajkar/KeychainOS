"""NFC feature registry."""
NFC_FEATURES=(("NFC SCANNER","nfc_app"),("NDEF TOOLS","nfc_ndef"))
