"""Consistent visible error reporting."""
import time

def show(display,touch,ui,title,error):
    display.fill(0xF800); ui.centred_text(display,title,80,0xFFFF,0xF800); ui.centred_text(display,str(error)[:28],130,0xFFFF,0xF800); ui.centred_text(display,'Tap to close',260,0xFFE0,0xF800)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('TAP','RIGHT'): return
