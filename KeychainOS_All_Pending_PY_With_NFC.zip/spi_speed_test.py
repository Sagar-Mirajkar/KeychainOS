"""Cautious display SPI-speed benchmark."""
import time
SPEEDS=(20000000,40000000,60000000,80000000)
def run(display,touch,ui):
    results=[]
    for speed in SPEEDS:
        try:
            display.spi.init(baudrate=speed,polarity=0,phase=0); start=time.ticks_us(); display.fill(0x07E0); elapsed=time.ticks_diff(time.ticks_us(),start); results.append((speed,elapsed,True))
        except Exception as error: results.append((speed,repr(error),False))
    display.spi.init(baudrate=20000000,polarity=0,phase=0); display.fill(0x0841)
    for i,item in enumerate(results): ui.draw_text(display,'{}MHz {}'.format(item[0]//1000000,item[1]),8,50+i*40,0xFFFF,0x0841,220)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return results
