"""All newly generated pending features."""
FEATURES={
'REMOTE':('remote_home','http_remote','mqtt_remote','computer_remote','presentation_remote','media_remote','ble_remote','usb_remote','ir_remote'),
'NFC':('nfc_app','nfc_ndef'),
'PERSONAL':('tasks','reminders','habit_tracker','calendar_events'),
'DISPLAY_TESTS':('display_benchmark','dirty_rect_test','framebuffer_test','double_buffer_test','spi_speed_test','transition_test'),
'SD':('media_index','media_importer','thumbnail_cache','recent_files','favourites','sd_benchmark','sd_health'),
'SYSTEM':('lazy_loader','performance_monitor','refresh_manager','safe_mode','error_screen','status_bar','navigation_manager')
}
