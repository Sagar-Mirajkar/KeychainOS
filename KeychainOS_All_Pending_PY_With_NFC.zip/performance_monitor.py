"""Runtime performance measurements and persistent samples."""
import gc,time,json
LOG='/performance.json'
class Monitor:
    def __init__(self): self.samples=[]; self.started=time.ticks_ms()
    def begin(self,label): return (label,time.ticks_us(),gc.mem_free())
    def end(self,token):
        label,start,memory=token; sample={'label':label,'us':time.ticks_diff(time.ticks_us(),start),'memory_before':memory,'memory_after':gc.mem_free()}; self.samples.append(sample); return sample
    def uptime_ms(self): return time.ticks_diff(time.ticks_ms(),self.started)
    def save(self):
        with open(LOG,'w') as output: json.dump(self.samples[-100:],output)
