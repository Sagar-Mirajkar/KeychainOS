"""Shared status-bar state and renderer."""
STATE={'wifi':False,'ble':False,'sd':False,'battery':None,'developer':False}

def update(**values): STATE.update(values)

def draw(display,ui,title,background=0xBDF7,foreground=0x0000):
    display.fill_rect(0,0,240,28,background); ui.draw_text(display,title[:12],70,5,foreground,background,96)
    icons=('W' if STATE['wifi'] else '-', 'B' if STATE['ble'] else '-', 'S' if STATE['sd'] else '-')
    ui.draw_text(display,''.join(icons),202,5,foreground,background,28)
