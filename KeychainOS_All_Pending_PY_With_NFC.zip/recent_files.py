"""Recent-file tracking."""
import json
FILE='/recent_files.json'

def load():
    try:return json.load(open(FILE,'r'))
    except Exception:return []

def add(path,limit=20):
    items=load(); items=[p for p in items if p!=path]; items.insert(0,path); items=items[:limit]; json.dump(items,open(FILE,'w')); return items
