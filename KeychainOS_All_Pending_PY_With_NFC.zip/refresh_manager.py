"""Display-refresh policy and dirty-area tracking."""
MODES=('COMPATIBILITY','FAST','LOW FLICKER','BUFFERED')
class RefreshManager:
    def __init__(self,display,mode='LOW FLICKER'):
        self.display=display; self.mode=mode; self.dirty=[]
    def set_mode(self,mode):
        if mode not in MODES: raise ValueError('Unknown refresh mode')
        self.mode=mode
    def invalidate(self,x,y,w,h): self.dirty.append((x,y,w,h))
    def clear(self): self.dirty=[]
    def full(self,colour): self.display.fill(colour); self.clear()
    def regions(self): return tuple(self.dirty)
