"""Favourite-file tracking."""
import json
FILE='/favourites.json'

def load():
    try:return json.load(open(FILE,'r'))
    except Exception:return []

def toggle(path):
    items=load(); items.remove(path) if path in items else items.append(path); json.dump(items,open(FILE,'w')); return items
