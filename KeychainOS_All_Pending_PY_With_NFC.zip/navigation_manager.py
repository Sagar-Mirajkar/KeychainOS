"""Screen stack and app navigation manager."""
class Navigation:
    def __init__(self,home='HOME'): self.stack=[home]
    def current(self): return self.stack[-1]
    def push(self,screen): self.stack.append(screen); return screen
    def back(self):
        if len(self.stack)>1: self.stack.pop()
        return self.current()
    def home(self): self.stack=self.stack[:1]; return self.current()
