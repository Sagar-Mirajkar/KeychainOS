"""Daily habit completion tracker."""
import json
FILE='/habits.json'
def load():
    try:return json.load(open(FILE,'r'))
    except Exception:return []
def add(name):
    items=load(); items.append({'name':name,'days':[]}); json.dump(items,open(FILE,'w')); return items
def mark(name,date):
    items=load()
    for item in items:
        if item['name']==name and date not in item['days']: item['days'].append(date)
    json.dump(items,open(FILE,'w')); return items
