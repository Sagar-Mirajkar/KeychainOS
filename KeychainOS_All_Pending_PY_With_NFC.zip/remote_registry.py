"""Remote-control registry."""
REMOTES=(("COMPUTER","computer_remote"),("PRESENTATION","presentation_remote"),("MEDIA","media_remote"),("HTTP","http_remote"),("MQTT","mqtt_remote"),("BLE","ble_remote"),("USB","usb_remote"),("INFRARED","ir_remote"),("MACROS","macro_manager"))
