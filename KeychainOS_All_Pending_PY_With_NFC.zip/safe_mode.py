"""Safe-mode marker and minimal recovery helpers."""
import os
MARKER='/safe_mode'

def enable(): open(MARKER,'w').write('1')

def disable():
    try: os.remove(MARKER)
    except OSError: pass

def active():
    try: os.stat(MARKER); return True
    except OSError: return False

def required_modules(): return ('st7789','touch','ui')
