"""Infrared service placeholder. Requires IR LED/receiver hardware."""
HARDWARE_INSTALLED=False
def available(): return HARDWARE_INSTALLED
def send(protocol,address,command):
    if not HARDWARE_INSTALLED: raise RuntimeError('IR hardware not installed')
