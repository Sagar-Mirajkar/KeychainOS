"""Physical Back/Home button service placeholder."""
HARDWARE_INSTALLED=False
def available():return HARDWARE_INSTALLED
def pressed():return False
