"""SD sequential read/write benchmark."""
import os,time

def benchmark(folder='/sd',size=32768):
    path=folder+'/benchmark.tmp'; data=bytes(1024); start=time.ticks_ms()
    with open(path,'wb') as output:
        for _ in range(size//1024): output.write(data)
    write_ms=max(1,time.ticks_diff(time.ticks_ms(),start)); start=time.ticks_ms()
    with open(path,'rb') as source:
        while source.read(1024): pass
    read_ms=max(1,time.ticks_diff(time.ticks_ms(),start)); os.remove(path)
    return {'write_kb_s':(size//1024)*1000//write_ms,'read_kb_s':(size//1024)*1000//read_ms}
