"""Custom BLE GATT remote shell, not Classic Bluetooth audio."""
def run(display,touch,ui):
    display.fill(0x0841); ui.centred_text(display,'BLE REMOTE',60,0x07FF,0x0841); ui.centred_text(display,'GATT profiles required',145,0xFFFF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return 'EXIT'
