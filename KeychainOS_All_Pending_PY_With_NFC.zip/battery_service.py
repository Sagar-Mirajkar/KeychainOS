"""Battery service placeholder; requires voltage sensing or fuel gauge."""
HARDWARE_INSTALLED=False
def available():return HARDWARE_INSTALLED
def voltage():
    if not HARDWARE_INSTALLED: raise RuntimeError('Battery monitor not installed')
def percent():
    if not HARDWARE_INSTALLED:return None
