"""MQTT remote shell. Requires umqtt.simple in firmware/filesystem."""
def publish(host,topic,payload,client_id='keychainos',port=1883):
    from umqtt.simple import MQTTClient
    client=MQTTClient(client_id,host,port=port); client.connect(); client.publish(topic,payload); client.disconnect(); return True

def run(display,touch,ui):
    display.fill(0x0841); ui.centred_text(display,'MQTT REMOTE',50,0x07FF,0x0841); ui.centred_text(display,'Profiles required',140,0xFFFF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return 'EXIT'
