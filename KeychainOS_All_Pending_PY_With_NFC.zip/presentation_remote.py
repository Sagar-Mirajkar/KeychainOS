"""Presentation-control command definitions."""
COMMANDS=('NEXT','PREVIOUS','START','END','BLACK_SCREEN','WHITE_SCREEN')
def run(display,touch,ui,sender=None):
    index=0
    while True:
        display.fill(0x0841); ui.centred_text(display,'PRESENTATION',30,0xFFE0,0x0841); ui.centred_text(display,COMMANDS[index],140,0x07FF,0x0841)
        g=touch.capture_gesture()
        if g and g[0]=='RIGHT': return 'EXIT'
        if g and g[0]=='LEFT': index=(index+1)%len(COMMANDS)
        elif g and g[0]=='TAP' and sender: sender(COMMANDS[index])
