"""Measure full-screen and rectangle draw times."""
import time
def run(display,touch,ui):
    results=[]
    for colour in (0xF800,0x07E0,0x001F,0xFFFF):
        start=time.ticks_us(); display.fill(colour); results.append(time.ticks_diff(time.ticks_us(),start))
    display.fill(0x0841); ui.centred_text(display,'AVG {} us'.format(sum(results)//len(results)),130,0x07FF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return results
