"""Execute delays and registered macro actions."""
import time

def run_steps(steps,handlers):
    for step in steps:
        kind=step.get('type')
        if kind=='delay': time.sleep_ms(int(step.get('ms',0)))
        elif kind in handlers: handlers[kind](step)
        else: raise ValueError('Unknown macro step: '+str(kind))
    return True
