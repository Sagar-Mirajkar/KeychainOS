"""Double-buffer allocation test."""
def allocate(): return bytearray(240*320*2),bytearray(240*320*2)
def run(display,touch,ui):
    try: first,second=allocate(); message='DOUBLE BUFFER OK'
    except MemoryError: message='NOT ENOUGH RAM'
    display.fill(0x0841); ui.centred_text(display,message,140,0x07FF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return message
