"""Audio service placeholder; requires buzzer or I2S hardware."""
HARDWARE_INSTALLED=False
def available():return HARDWARE_INSTALLED
def beep(frequency=1000,duration_ms=100):
    if not HARDWARE_INSTALLED: raise RuntimeError('Audio hardware not installed')
