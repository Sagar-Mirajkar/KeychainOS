"""Import and unload applications only when needed."""
import gc,sys

def load(name):
    gc.collect(); return __import__(name)

def unload(name):
    if name in sys.modules: del sys.modules[name]
    gc.collect()

def run_app(name,display,touch,ui,*args):
    module=load(name)
    try: return module.run(display,touch,ui,*args)
    finally: unload(name)
