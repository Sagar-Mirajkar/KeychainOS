"""Classify newly copied SD files without destructive conversion."""
import os
TEXT=('.txt','.md','.json','.csv','.py','.log')
IMAGES=('.bmp','.rgb','.jpg','.jpeg','.png','.gif')

def classify(name):
    lower=name.lower()
    if lower.endswith(TEXT): return 'text'
    if lower.endswith(IMAGES): return 'image'
    return 'unsupported'

def scan(folder='/sd/incoming'):
    return [(name,classify(name)) for name in sorted(os.listdir(folder))]
