"""Persistent SD media index."""
import json,os
FILE='/sd/.keychainos/media_index.json'

def load():
    try: return json.load(open(FILE,'r'))
    except Exception: return {}

def save(index):
    folder=FILE.rsplit('/',1)[0]
    try: os.mkdir('/sd/.keychainos')
    except OSError: pass
    with open(FILE+'.new','w') as output: json.dump(index,output)
    try: os.remove(FILE)
    except OSError: pass
    os.rename(FILE+'.new',FILE)

def update(path,metadata):
    index=load(); index[path]=metadata; save(index)
