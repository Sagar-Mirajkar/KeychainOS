"""Small NDEF record helpers for NFC tags."""
def text_record(text,language='en'):
    payload=bytes([len(language)])+language.encode()+text.encode(); return {'tnf':1,'type':b'T','payload':payload}
def uri_record(uri): return {'tnf':1,'type':b'U','payload':b'\x00'+uri.encode()}
def decode_text(payload):
    size=payload[0]&0x3f; return payload[1+size:].decode()
