"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='NFC'
MODES=('SCAN TAG','READ NDEF','TAG INFO','WRITE TEXT')

def run(display,touch,ui):
    import nfc_service
    index=0
    while True:
        header(display,ui,'NFC'); ui.centred_text(display,MODES[index],110,CYAN,DARK)
        ui.centred_text(display,'Hardware ready' if nfc_service.available() else 'PN532 not installed',155,GREEN if nfc_service.available() else YELLOW,DARK)
        ui.centred_text(display,'Swipe browse / Tap',270,MUTED,DARK)
        g=touch.capture_gesture()
        if exit_requested(g): return 'EXIT'
        if g[0]=='LEFT': index=(index+1)%len(MODES)
        elif g[0]=='RIGHT': return 'EXIT'
        elif g[0]=='TAP' and nfc_service.available():
            tag=nfc_service.read_passive_target(2000); ui.centred_text(display,str(tag)[:28],210,WHITE,DARK); time.sleep_ms(1000)
