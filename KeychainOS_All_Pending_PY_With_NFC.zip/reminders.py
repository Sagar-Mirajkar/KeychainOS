"""Persistent reminders."""
import json
FILE='/reminders.json'
def load():
    try:return json.load(open(FILE,'r'))
    except Exception:return []
def add(label,year,month,day,hour,minute,repeat=None):
    items=load(); items.append({'label':label,'when':[year,month,day,hour,minute],'repeat':repeat,'enabled':True}); json.dump(items,open(FILE,'w')); return items
