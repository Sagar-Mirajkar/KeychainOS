"""Thumbnail metadata cache. Pixel generation is converter-side for now."""
import json,os
FILE='/sd/.keychainos/thumbnails.json'

def load():
    try:return json.load(open(FILE,'r'))
    except Exception:return {}

def save(data):
    try: os.mkdir('/sd/.keychainos')
    except OSError: pass
    with open(FILE,'w') as output: json.dump(data,output)
