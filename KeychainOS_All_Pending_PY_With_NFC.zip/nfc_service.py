"""NFC service abstraction. Intended for PN532-class external hardware."""
HARDWARE_INSTALLED=False
_DRIVER=None

def configure(driver):
    global _DRIVER,HARDWARE_INSTALLED
    _DRIVER=driver; HARDWARE_INSTALLED=driver is not None

def available(): return HARDWARE_INSTALLED and _DRIVER is not None

def firmware_version():
    if not available(): raise RuntimeError('NFC hardware not installed')
    return _DRIVER.firmware_version()

def read_passive_target(timeout=1000):
    if not available(): raise RuntimeError('NFC hardware not installed')
    return _DRIVER.read_passive_target(timeout)

def read_ndef(tag):
    if not available(): raise RuntimeError('NFC hardware not installed')
    return _DRIVER.read_ndef(tag)

def write_ndef(tag,records):
    if not available(): raise RuntimeError('NFC hardware not installed')
    return _DRIVER.write_ndef(tag,records)
