"""Compare instant, wipe, and card-only transitions."""
import time
def run(display,touch,ui):
    mode=0; names=('INSTANT','WIPE','CARD ONLY')
    while True:
        if mode==0: display.fill(0x001F)
        elif mode==1:
            for x in range(0,240,12): display.fill_rect(x,0,12,320,0x07FF)
        else: display.fill_rect(50,80,140,140,0xF81F)
        ui.centred_text(display,names[mode],280,0xFFFF,0x0000); g=touch.capture_gesture()
        if g and g[0]=='RIGHT': return 'EXIT'
        if g and g[0]=='TAP': mode=(mode+1)%3
