"""Report intended optional hardware readiness."""
MODULES=('battery_service','audio_service','haptic_service','ir_service','button_service','nfc_service')
def report():
    output={}
    for name in MODULES:
        module=__import__(name); output[name]=module.available()
    return output
