"""Move one card by redrawing only old and new regions."""
import time
def run(display,touch,ui):
    display.fill(0x0841); x=20; direction=1
    while True:
        display.fill_rect(x,120,60,60,0x0841); x+=direction*8
        if x<=0 or x>=180: direction=-direction
        display.fill_rect(x,120,60,60,0x07FF); g=touch.poll_gesture()
        if g=='RIGHT': return 'EXIT'
        time.sleep_ms(30)
