"""Persistent remote and automation macros."""
import json,os
FILE='/macros.json'

def load():
    try: return json.load(open(FILE,'r'))
    except Exception: return []

def save(items):
    with open(FILE+'.new','w') as output: json.dump(items,output)
    try: os.remove(FILE)
    except OSError: pass
    os.rename(FILE+'.new',FILE)

def add(name,steps):
    items=load(); items.append({'name':name,'steps':steps}); save(items); return items
