"""USB HID remote capability placeholder for later firmware support."""
CAPABILITIES=('KEYBOARD','MOUSE','MEDIA','GAMEPAD','PRESENTATION')
def available():
    try:
        import usb_hid
        return True
    except ImportError: return False
def run(display,touch,ui):
    display.fill(0x0841); ui.centred_text(display,'USB REMOTE',60,0x07FF,0x0841); ui.centred_text(display,'Requires USB HID firmware',145,0xFFFF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return 'EXIT'
