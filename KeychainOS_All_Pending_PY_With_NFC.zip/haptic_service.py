"""Haptic service placeholder; requires motor driver hardware."""
HARDWARE_INSTALLED=False
def available():return HARDWARE_INSTALLED
def pulse(duration_ms=50):
    if not HARDWARE_INSTALLED: raise RuntimeError('Haptic hardware not installed')
