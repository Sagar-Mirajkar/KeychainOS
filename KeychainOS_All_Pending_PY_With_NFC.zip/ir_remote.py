"""Infrared remote UI placeholder."""
import ir_service
def run(display,touch,ui):
    display.fill(0x0841); ui.centred_text(display,'INFRARED REMOTE',55,0xFFE0,0x0841); ui.centred_text(display,'Hardware not installed',145,0xFFFF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ('RIGHT','TAP'): return 'EXIT'
