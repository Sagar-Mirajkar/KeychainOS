"""Non-destructive SD mount and capacity checks."""
import os
def report(path='/sd'):
    try:
        names=os.listdir(path); v=os.statvfs(path); return {'mounted':True,'files':len(names),'total':v[2]*v[0],'free':v[3]*v[0]}
    except Exception as error:return {'mounted':False,'error':repr(error)}
