"""Registry for KeychainOS Settings menu."""
SETTINGS=(
 ("THEMES","settings_themes"),
 ("BRIGHTNESS","settings_brightness"),
 ("SCREEN TIMEOUT","settings_screen_timeout"),
 ("DATE & TIME","settings_date_time"),
 ("WI-FI","settings_wifi"),
 ("TOUCH","settings_touch"),
 ("DEVICE INFO","settings_device_info"),
 ("SOFTWARE UPDATE","settings_software_update"),
 ("STORAGE","settings_storage"),
 ("RESTART","settings_restart"),
)
