"""KeychainOS module generated for MicroPython ESP32-S3."""

import time

BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display, ui, title):
    display.fill(DARK)
    display.fill_rect(0,0,240,34,BLUE)
    ui.draw_text(display,"< BACK",8,8,WHITE,BLUE,56)
    ui.draw_text(display,title,78,8,WHITE,BLUE,152)

def wants_exit(gesture):
    if gesture is None:
        return False
    kind,x,y=gesture
    return kind=="RIGHT" or (kind=="TAP" and x<70 and y<42)

NAME="TIMER"
PRESETS=(60,180,300,600)

def run(display,touch,ui):
    index=0; remaining=PRESETS[index]*1000; running=False; last_tick=time.ticks_ms(); last=-1
    header(display,ui,"TIMER")
    ui.centred_text(display,"Swipe L/R: preset",252,YELLOW,DARK)
    ui.centred_text(display,"Tap: start/pause",274,MUTED,DARK)
    while True:
        now=time.ticks_ms()
        if running:
            delta=time.ticks_diff(now,last_tick); remaining=max(0,remaining-delta)
            if remaining==0: running=False
        last_tick=now
        seconds=(remaining+999)//1000
        if seconds!=last:
            last=seconds; text="{:02d}:{:02d}".format(seconds//60,seconds%60)
            display.fill_rect(20,90,200,80,BLACK); ui.centred_text(display,text,120,CYAN,BLACK)
            if seconds==0: ui.centred_text(display,"TIME UP",190,RED,DARK)
        if touch.read() is not None:
            g=touch.capture_gesture()
            if wants_exit(g): return "EXIT"
            if g[0] in ("LEFT","RIGHT") and not running:
                index=(index+(1 if g[0]=="LEFT" else -1))%len(PRESETS); remaining=PRESETS[index]*1000; last=-1
            elif g[0]=="TAP": running=not running
            elif g[0]=="DOWN": running=False; remaining=PRESETS[index]*1000; last=-1
        time.sleep_ms(30)
