"""KeychainOS module generated for MicroPython ESP32-S3."""

import time

BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display, ui, title):
    display.fill(DARK)
    display.fill_rect(0,0,240,34,BLUE)
    ui.draw_text(display,"< BACK",8,8,WHITE,BLUE,56)
    ui.draw_text(display,title,78,8,WHITE,BLUE,152)

def wants_exit(gesture):
    if gesture is None:
        return False
    kind,x,y=gesture
    return kind=="RIGHT" or (kind=="TAP" and x<70 and y<42)

NAME="RESTART"

def run(display,touch,ui):
    import machine
    header(display,ui,"RESTART")
    ui.centred_text(display,"Tap centre to restart",130,YELLOW,DARK)
    while True:
        g=touch.capture_gesture()
        if wants_exit(g): return "EXIT"
        if g[0]=="TAP" and 70<g[1]<170 and 80<g[2]<220:
            ui.centred_text(display,"Restarting...",180,CYAN,DARK); time.sleep_ms(500); machine.reset()
