"""KeychainOS module generated for MicroPython ESP32-S3."""

import time

BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display, ui, title):
    display.fill(DARK)
    display.fill_rect(0,0,240,34,BLUE)
    ui.draw_text(display,"< BACK",8,8,WHITE,BLUE,56)
    ui.draw_text(display,title,78,8,WHITE,BLUE,152)

def wants_exit(gesture):
    if gesture is None:
        return False
    kind,x,y=gesture
    return kind=="RIGHT" or (kind=="TAP" and x<70 and y<42)

NAME="SOFTWARE UPDATE"

def run(display,touch,ui):
    header(display,ui,"SOFTWARE UPDATE")
    ui.centred_text(display,"OTA framework ready",105,CYAN,DARK)
    ui.centred_text(display,"Manual test mode",140,YELLOW,DARK)
    ui.centred_text(display,"Safe updater retained",175,WHITE,DARK)
    while True:
        if wants_exit(touch.capture_gesture()): return "EXIT"
