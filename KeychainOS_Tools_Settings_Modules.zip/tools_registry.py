"""Registry for KeychainOS Tools menu."""
TOOLS=(
 ("CALCULATOR","calculator"),
 ("CLOCK","clock"),
 ("STOPWATCH","stopwatch"),
 ("TIMER","timer"),
 ("CALENDAR","calendar_tool"),
 ("FLASHLIGHT","flashlight"),
 ("COUNTER","counter"),
 ("CONVERTER","converter"),
 ("SYSTEM MONITOR","system_monitor"),
 ("WI-FI INFO","wifi_info"),
)
