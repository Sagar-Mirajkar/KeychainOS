"""KeychainOS module generated for MicroPython ESP32-S3."""

import time

BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display, ui, title):
    display.fill(DARK)
    display.fill_rect(0,0,240,34,BLUE)
    ui.draw_text(display,"< BACK",8,8,WHITE,BLUE,56)
    ui.draw_text(display,title,78,8,WHITE,BLUE,152)

def wants_exit(gesture):
    if gesture is None:
        return False
    kind,x,y=gesture
    return kind=="RIGHT" or (kind=="TAP" and x<70 and y<42)

NAME="CALENDAR"
MONTHS=("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC")

def run(display,touch,ui):
    import machine
    dt=machine.RTC().datetime(); year=dt[0]; month=dt[1]
    while True:
        header(display,ui,"CALENDAR")
        ui.centred_text(display,"{} {}".format(MONTHS[month-1],year),52,YELLOW,DARK)
        for d in range(1,32):
            col=(d-1)%7; row=(d-1)//7; x=12+col*32; y=82+row*34
            display.outline_rect(x,y,27,27,MUTED,1); ui.draw_text(display,str(d),x+5,y+7,WHITE,DARK,18)
        ui.centred_text(display,"Swipe L/R: month",286,MUTED,DARK)
        g=touch.capture_gesture()
        if wants_exit(g): return "EXIT"
        if g[0]=="LEFT": month+=1; year+=1 if month==13 else 0; month=1 if month==13 else month
        elif g[0]=="RIGHT": month-=1; year-=1 if month==0 else 0; month=12 if month==0 else month
