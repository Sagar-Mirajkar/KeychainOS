"""KeychainOS module generated for MicroPython ESP32-S3."""

import time

BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display, ui, title):
    display.fill(DARK)
    display.fill_rect(0,0,240,34,BLUE)
    ui.draw_text(display,"< BACK",8,8,WHITE,BLUE,56)
    ui.draw_text(display,title,78,8,WHITE,BLUE,152)

def wants_exit(gesture):
    if gesture is None:
        return False
    kind,x,y=gesture
    return kind=="RIGHT" or (kind=="TAP" and x<70 and y<42)

NAME="DEVICE INFO"

def run(display,touch,ui):
    import gc,machine,sys
    header(display,ui,"DEVICE INFO")
    rows=("ESP32-S3","MicroPython","CPU {} MHz".format(machine.freq()//1000000),"RAM {} free".format(gc.mem_free()),str(sys.implementation[1]))
    for i,text in enumerate(rows): ui.draw_text(display,text,18,60+i*38,WHITE,DARK,204)
    while True:
        if wants_exit(touch.capture_gesture()): return "EXIT"
