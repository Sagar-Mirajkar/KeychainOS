"""KeychainOS module generated for MicroPython ESP32-S3."""

import time

BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display, ui, title):
    display.fill(DARK)
    display.fill_rect(0,0,240,34,BLUE)
    ui.draw_text(display,"< BACK",8,8,WHITE,BLUE,56)
    ui.draw_text(display,title,78,8,WHITE,BLUE,152)

def wants_exit(gesture):
    if gesture is None:
        return False
    kind,x,y=gesture
    return kind=="RIGHT" or (kind=="TAP" and x<70 and y<42)

NAME="STORAGE"

def run(display,touch,ui):
    import os
    while True:
        values=os.statvfs('/'); block=values[0]; free=values[3]*block; total=values[2]*block
        header(display,ui,"STORAGE")
        ui.centred_text(display,"Total {} KB".format(total//1024),100,WHITE,DARK)
        ui.centred_text(display,"Free {} KB".format(free//1024),140,CYAN,DARK)
        ui.centred_text(display,"Files {}".format(len(os.listdir('/'))),180,YELLOW,DARK)
        if wants_exit(touch.capture_gesture()): return "EXIT"
