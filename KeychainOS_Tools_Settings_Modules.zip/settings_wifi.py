"""KeychainOS module generated for MicroPython ESP32-S3."""

import time

BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display, ui, title):
    display.fill(DARK)
    display.fill_rect(0,0,240,34,BLUE)
    ui.draw_text(display,"< BACK",8,8,WHITE,BLUE,56)
    ui.draw_text(display,title,78,8,WHITE,BLUE,152)

def wants_exit(gesture):
    if gesture is None:
        return False
    kind,x,y=gesture
    return kind=="RIGHT" or (kind=="TAP" and x<70 and y<42)

NAME="WI-FI"

def run(display,touch,ui):
    import network
    wlan=network.WLAN(network.STA_IF)
    while True:
        header(display,ui,"WI-FI SETTINGS")
        ui.centred_text(display,"ON" if wlan.active() else "OFF",110,CYAN,DARK)
        ui.centred_text(display,"Tap to toggle radio",255,MUTED,DARK)
        g=touch.capture_gesture()
        if wants_exit(g): return "EXIT"
        if g[0]=="TAP": wlan.active(not wlan.active())
