"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="SOFTWARE"

def run(display,touch,ui):
    import sys,gc,os
    header(display,ui,"SOFTWARE")
    rows=("KeychainOS modular build","MicroPython {}".format(sys.implementation[1]),"Modules {}".format(len(os.listdir('/'))),"Free RAM {}".format(gc.mem_free()),"OTA: GitHub manifest","Licence: project defined")
    for i,text in enumerate(rows): ui.draw_text(display,text[:28],8,60+i*36,WHITE,DARK,224)
    while True:
        if exit_requested(touch.capture_gesture()): return "EXIT"
