"""About-menu registry."""
ABOUT_ITEMS=(("ABOUT","about"),("HARDWARE","about_hardware"),("SOFTWARE","about_software"),("DIAGNOSTICS","diagnostics"))
