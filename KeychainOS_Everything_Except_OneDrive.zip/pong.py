"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='PONG'

def run(display,touch,ui):
    px=104; ball_x=120; ball_y=150; dx=3; dy=3; score=0
    while True:
        display.fill(BLACK); display.fill_rect(px,292,48,6,CYAN); display.fill_rect(ball_x,ball_y,7,7,WHITE); ui.draw_text(display,str(score),108,8,YELLOW,BLACK,24)
        point=touch.read()
        if point: px=max(0,min(192,point[0]-24))
        ball_x+=dx; ball_y+=dy
        if ball_x<=0 or ball_x>=233: dx=-dx
        if ball_y<=35: dy=-dy
        if ball_y>=284 and px-6<=ball_x<=px+48: dy=-abs(dy); score+=1
        if ball_y>315: ball_x=120; ball_y=150; score=0
        if point:
            g=touch.poll_gesture()
            if g=="RIGHT": return "EXIT"
        time.sleep_ms(25)
