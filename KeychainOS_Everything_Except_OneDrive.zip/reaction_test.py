"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='REACTION TEST'

import random

def run(display,touch,ui):
    while True:
        header(display,ui,"REACTION TEST"); ui.centred_text(display,"Wait for GREEN",140,WHITE,DARK); time.sleep_ms(random.randint(1000,3500)); display.fill(GREEN); started=time.ticks_ms(); g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        elapsed=time.ticks_diff(time.ticks_ms(),started); display.fill(DARK); ui.centred_text(display,"{} ms".format(elapsed),140,CYAN,DARK); time.sleep_ms(1200)
