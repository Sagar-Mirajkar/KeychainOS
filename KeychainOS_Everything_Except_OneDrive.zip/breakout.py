"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='BREAKOUT'

def run(display,touch,ui):
    bricks=[]
    for row in range(4):
        for col in range(8): bricks.append([col*30,row*14+42,28,10])
    paddle=96; bx=120; by=240; dx=3; dy=-3
    while True:
        display.fill(BLACK)
        for b in bricks: display.fill_rect(b[0],b[1],b[2],b[3],CYAN)
        display.fill_rect(paddle,298,48,5,YELLOW); display.fill_rect(bx,by,6,6,WHITE)
        point=touch.read()
        if point: paddle=max(0,min(192,point[0]-24))
        bx+=dx; by+=dy
        if bx<=0 or bx>=234: dx=-dx
        if by<=35: dy=abs(dy)
        if by>=290 and paddle-6<=bx<=paddle+48: dy=-abs(dy)
        for b in bricks[:]:
            if b[0]<=bx<=b[0]+b[2] and b[1]<=by<=b[1]+b[3]: bricks.remove(b); dy=-dy; break
        if by>315 or not bricks: return "EXIT"
        if point and touch.poll_gesture()=="RIGHT": return "EXIT"
        time.sleep_ms(25)
