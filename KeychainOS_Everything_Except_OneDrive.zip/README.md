# KeychainOS Expansion Pack

This pack intentionally excludes OneDrive integration.

Contents:
- Additional games
- Additional tools
- Expanded settings and About modules
- Core services
- GitHub Raw manifest installer
- BLE scanner foundation

Do not upload main.py from an older bundle after installing these modules. Generate the final registry-driven main.py after module testing.
