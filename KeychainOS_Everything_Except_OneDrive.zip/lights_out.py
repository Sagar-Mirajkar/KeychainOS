"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='LIGHTS OUT'

def run(display,touch,ui):
    cells=[False]*25
    def toggle(i):
        r=i//5; c=i%5
        for rr,cc in ((r,c),(r-1,c),(r+1,c),(r,c-1),(r,c+1)):
            if 0<=rr<5 and 0<=cc<5: cells[rr*5+cc]=not cells[rr*5+cc]
    for i in (6,12,18): toggle(i)
    while True:
        display.fill(DARK); header(display,ui,"LIGHTS OUT")
        for i,on in enumerate(cells):
            x=18+(i%5)*42; y=58+(i//5)*42; display.fill_rect(x,y,36,36,YELLOW if on else PANEL)
        g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        if g[0]=="TAP" and g[2]>=58: toggle(min(24,((g[2]-58)//42)*5+(g[1]-18)//42))
