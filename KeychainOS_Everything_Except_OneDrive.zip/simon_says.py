"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='SIMON SAYS'

import random

def run(display,touch,ui):
    sequence=[]; entered=[]
    zones=((0,45,120,130,RED),(120,45,120,130,GREEN),(0,175,120,130,BLUE),(120,175,120,130,YELLOW))
    while True:
        sequence.append(random.randrange(4)); entered=[]
        for value in sequence:
            for i,z in enumerate(zones): display.fill_rect(z[0],z[1],z[2],z[3],z[4] if i==value else PANEL)
            time.sleep_ms(350); display.fill(DARK); time.sleep_ms(150)
        while len(entered)<len(sequence):
            for z in zones: display.fill_rect(z[0],z[1],z[2],z[3],z[4])
            g=touch.capture_gesture()
            if exit_requested(g): return "EXIT"
            if g[0]=="TAP":
                value=(1 if g[1]>=120 else 0)+(2 if g[2]>=175 else 0); entered.append(value)
                if entered[-1]!=sequence[len(entered)-1]: return "EXIT"
