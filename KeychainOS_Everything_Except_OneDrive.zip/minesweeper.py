"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='MINESWEEPER'

import random

def run(display,touch,ui):
    cols=8; rows=8; mines=set()
    while len(mines)<10: mines.add((random.randrange(cols),random.randrange(rows)))
    opened=set()
    while True:
        display.fill(DARK); header(display,ui,"MINESWEEPER")
        for r in range(rows):
            for c in range(cols):
                x=c*30; y=48+r*30; colour=BLACK if (c,r) in opened else PANEL; display.fill_rect(x+2,y+2,26,26,colour); display.outline_rect(x+2,y+2,26,26,MUTED,1)
                if (c,r) in opened:
                    if (c,r) in mines: ui.draw_text(display,"*",x+10,y+8,RED,BLACK,8)
                    else:
                        n=sum((c+dx,r+dy) in mines for dx in (-1,0,1) for dy in (-1,0,1)); ui.draw_text(display,str(n),x+10,y+8,CYAN,BLACK,8)
        g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        if g[0]=="TAP" and g[2]>=48: opened.add((min(7,g[1]//30),min(7,(g[2]-48)//30)))
