"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='MEMORY MATCH'

import random

def run(display,touch,ui):
    cards=list(range(8))*2; random.shuffle(cards); open_cards=[]; matched=set()
    while True:
        display.fill(DARK); header(display,ui,"MEMORY MATCH")
        for i,val in enumerate(cards):
            c=i%4; r=i//4; x=12+c*56; y=52+r*58; visible=i in open_cards or i in matched; display.fill_rect(x,y,50,50,CYAN if visible else PANEL); ui.draw_text(display,str(val+1) if visible else "?",x+20,y+18,BLACK if visible else WHITE,CYAN if visible else PANEL,8)
        g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        if g[0]=="TAP" and g[2]>=52:
            i=min(15,((g[2]-52)//58)*4+g[1]//56)
            if i not in matched and i not in open_cards: open_cards.append(i)
            if len(open_cards)==2:
                if cards[open_cards[0]]==cards[open_cards[1]]: matched.update(open_cards)
                time.sleep_ms(500); open_cards=[]
            if len(matched)==16: return "EXIT"
