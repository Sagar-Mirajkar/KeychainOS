"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='2048'

import random

def add_tile(board):
    empty=[i for i,v in enumerate(board) if v==0]
    if empty: board[random.choice(empty)]=2

def compress(line):
    values=[v for v in line if v]
    out=[]; i=0
    while i<len(values):
        if i+1<len(values) and values[i]==values[i+1]: out.append(values[i]*2); i+=2
        else: out.append(values[i]); i+=1
    return out+[0]*(4-len(out))

def run(display,touch,ui):
    board=[0]*16; add_tile(board); add_tile(board)
    while True:
        display.fill(DARK); header(display,ui,"2048")
        for r in range(4):
            for c in range(4):
                x=18+c*52; y=56+r*52; value=board[r*4+c]; display.fill_rect(x,y,46,46,PANEL); display.outline_rect(x,y,46,46,WHITE,1)
                if value: ui.draw_text(display,str(value),x+7,y+16,YELLOW,PANEL,32)
        g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        old=board[:]
        if g[0] in ("LEFT","RIGHT"):
            for r in range(4):
                line=board[r*4:r*4+4]; line=line[::-1] if g[0]=="RIGHT" else line; line=compress(line); line=line[::-1] if g[0]=="RIGHT" else line; board[r*4:r*4+4]=line
        elif g[0] in ("UP","DOWN"):
            for c in range(4):
                line=[board[r*4+c] for r in range(4)]; line=line[::-1] if g[0]=="DOWN" else line; line=compress(line); line=line[::-1] if g[0]=="DOWN" else line
                for r in range(4): board[r*4+c]=line[r]
        if board!=old: add_tile(board)
