"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME='CONNECT FOUR'

def run(display,touch,ui):
    board=[[0]*7 for _ in range(6)]; player=1
    while True:
        display.fill(DARK); header(display,ui,"CONNECT FOUR")
        for r in range(6):
            for c in range(7):
                colour=RED if board[r][c]==1 else YELLOW if board[r][c]==2 else BLACK; display.fill_rect(c*34+5,r*38+52,28,28,colour)
        g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        if g[0]=="TAP":
            c=min(6,g[1]//34)
            for r in range(5,-1,-1):
                if board[r][c]==0: board[r][c]=player; player=3-player; break
