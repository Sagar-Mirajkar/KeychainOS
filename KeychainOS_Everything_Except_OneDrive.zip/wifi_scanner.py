"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="WI-FI SCANNER"

def run(display,touch,ui):
    import network
    wlan=network.WLAN(network.STA_IF); wlan.active(True); results=wlan.scan(); header(display,ui,"WI-FI SCANNER")
    for i,item in enumerate(results[:10]):
        ssid=item[0].decode() if isinstance(item[0],bytes) else str(item[0]); ui.draw_text(display,ssid[:18]+" "+str(item[3]),4,50+i*24,WHITE,DARK,232)
    while True:
        if exit_requested(touch.capture_gesture()): return "EXIT"
