"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="ALARM"

def run(display,touch,ui):
    import alarm_manager
    alarms=alarm_manager.load(); header(display,ui,"ALARMS")
    ui.centred_text(display,"Saved alarms: {}".format(len(alarms)),100,CYAN,DARK); ui.centred_text(display,"Tap adds 08:00",160,YELLOW,DARK)
    while True:
        g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        if g[0]=="TAP": alarm_manager.add(8,0,"Alarm"); return "EXIT"
