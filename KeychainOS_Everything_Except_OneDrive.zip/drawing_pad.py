"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="DRAWING PAD"

def run(display,touch,ui):
    display.fill(WHITE); ui.draw_text(display,"< BACK",8,8,BLACK,WHITE,56)
    while True:
        point=touch.read()
        if point:
            if point[0]<70 and point[1]<42:
                g=touch.capture_gesture()
                if g: return "EXIT"
            display.fill_rect(point[0]-2,point[1]-2,5,5,BLACK)
        time.sleep_ms(10)
