"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="I2C SCANNER"

def run(display,touch,ui):
    from machine import I2C,Pin
    buses=(("TOUCH",I2C(1,scl=Pin(7),sda=Pin(15),freq=400000)),)
    header(display,ui,"I2C SCANNER"); y=60
    for label,bus in buses:
        ui.draw_text(display,label,8,y,YELLOW,DARK,80); y+=24
        for addr in bus.scan(): ui.draw_text(display,hex(addr),20,y,CYAN,DARK,80); y+=22
    while True:
        if exit_requested(touch.capture_gesture()): return "EXIT"
