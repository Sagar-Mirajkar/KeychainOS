"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="METRONOME"

def run(display,touch,ui):
    bpm=120; last=time.ticks_ms(); on=False
    while True:
        interval=60000//bpm
        if time.ticks_diff(time.ticks_ms(),last)>=interval: last=time.ticks_ms(); on=not on
        display.fill(GREEN if on else DARK); ui.centred_text(display,"{} BPM".format(bpm),130,WHITE,GREEN if on else DARK)
        g=touch.poll_gesture()
        if g=="RIGHT": return "EXIT"
        if g=="UP": bpm=min(240,bpm+5)
        elif g=="DOWN": bpm=max(30,bpm-5)
        time.sleep_ms(20)
