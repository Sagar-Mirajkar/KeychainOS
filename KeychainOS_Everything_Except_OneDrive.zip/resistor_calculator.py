"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="RESISTOR"
COLORS=("BLACK","BROWN","RED","ORANGE","YELLOW","GREEN","BLUE","VIOLET","GREY","WHITE")

def resistance(a,b,m): return (a*10+b)*(10**m)

def run(display,touch,ui):
    a=1;b=0;m=2
    while True:
        header(display,ui,"RESISTOR"); ui.centred_text(display,"{} {} {}".format(COLORS[a],COLORS[b],COLORS[m]),90,YELLOW,DARK); ui.centred_text(display,"{} ohm".format(resistance(a,b,m)),145,CYAN,DARK)
        g=touch.capture_gesture()
        if exit_requested(g): return "EXIT"
        if g[0]=="LEFT": a=(a+1)%10
        elif g[0]=="UP": b=(b+1)%10
        elif g[0]=="DOWN": m=(m+1)%10
