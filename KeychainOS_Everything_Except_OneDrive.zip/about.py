"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="ABOUT"
VERSION="0.1.0"
BUILD="2026-07-27"

def run(display,touch,ui):
    import gc,sys,machine
    rows=("KeychainOS "+VERSION,"Build "+BUILD,"ESP32-S3","ST7789 240x320","CST816D Touch","MicroPython","CPU {} MHz".format(machine.freq()//1000000),"Free RAM {}".format(gc.mem_free()),"github.com/Sagar-Mirajkar/KeychainOS")
    header(display,ui,"ABOUT")
    for i,text in enumerate(rows): ui.draw_text(display,text[:28],8,48+i*27,WHITE,DARK,224)
    while True:
        if exit_requested(touch.capture_gesture()): return "EXIT"
