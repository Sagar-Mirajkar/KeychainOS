"""Bulk KeychainOS installer using a public GitHub Raw manifest."""
import gc
import hashlib
import json
import os
import network
import time

try:
    import requests
except ImportError:
    import urequests as requests

from wifi_secrets import WIFI_NAME, WIFI_PASSWORD

MANIFEST_URL = "https://raw.githubusercontent.com/Sagar-Mirajkar/KeychainOS/refs/heads/main/ota/manifest.json"


def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if wlan.isconnected(): return wlan
    wlan.connect(WIFI_NAME, WIFI_PASSWORD)
    started = time.ticks_ms()
    while not wlan.isconnected():
        if time.ticks_diff(time.ticks_ms(), started) > 30000: raise RuntimeError("Wi-Fi timeout")
        time.sleep_ms(250)
    return wlan


def fetch(url):
    response = requests.get(url)
    try:
        status = getattr(response, "status_code", 200)
        if status != 200: raise RuntimeError("HTTP {}".format(status))
        return response.content
    finally:
        response.close()


def hash_hex(data):
    return "".join("{:02x}".format(value) for value in hashlib.sha256(data).digest())


def install():
    connect_wifi()
    manifest = json.loads(fetch(MANIFEST_URL).decode("utf-8"))
    staged = []
    backups = []
    try:
        for item in manifest["files"]:
            path = item["path"]
            data = fetch(item["url"])
            if item.get("sha256") and hash_hex(data) != item["sha256"].lower(): raise ValueError("Hash mismatch: " + path)
            if path.endswith(".py"): compile(data.decode("utf-8"), path, "exec")
            temp = path + ".new"
            with open(temp, "wb") as output: output.write(data)
            staged.append((path, temp))
        for path, temp in staged:
            backup = path + ".bak"
            try: os.remove(backup)
            except OSError: pass
            try: os.rename(path, backup); backups.append((path, backup))
            except OSError: pass
            os.rename(temp, path)
        for path, backup in backups:
            try: os.remove(backup)
            except OSError: pass
        print("KeychainOS installation complete")
        return manifest.get("version")
    except Exception:
        for path, temp in staged:
            try: os.remove(temp)
            except OSError: pass
        for path, backup in reversed(backups):
            try: os.remove(path)
            except OSError: pass
            try: os.rename(backup, path)
            except OSError: pass
        raise


install()
