"""Expanded games registry."""
GAMES=(("SNAKE","snake"),("TIC TAC TOE","tic_tac_toe"),("PONG","pong"),("BREAKOUT","breakout"),("2048","game_2048"),("MINESWEEPER","minesweeper"),("MEMORY MATCH","memory_match"),("LIGHTS OUT","lights_out"),("CONNECT FOUR","connect_four"),("SIMON SAYS","simon_says"),("REACTION TEST","reaction_test"))
