"""KeychainOS MicroPython module."""
import time
BLACK=0x0000
WHITE=0xFFFF
RED=0xF800
GREEN=0x07E0
BLUE=0x001F
CYAN=0x07FF
YELLOW=0xFFE0
DARK=0x0841
PANEL=0x18E3
MUTED=0xA514

def header(display,ui,title):
    display.fill(DARK)
    display.fill_rect(0,0,240,36,BLUE)
    ui.draw_text(display,"< BACK",8,9,WHITE,BLUE,56)
    ui.draw_text(display,title[:18],76,9,WHITE,BLUE,152)

def exit_requested(g):
    return bool(g and (g[0]=="RIGHT" or (g[0]=="TAP" and g[1]<70 and g[2]<42)))

NAME="HARDWARE"
ROWS=("ESP32-S3-WROOM-1-N8R8","8 MB Flash / 8 MB PSRAM","ST7789T3 240 x 320","CST816D capacitive touch","LCD SPI bus 2","Touch I2C bus 1","Backlight GPIO 6","SD chip select GPIO 38")

def run(display,touch,ui):
    header(display,ui,"HARDWARE")
    for i,text in enumerate(ROWS): ui.draw_text(display,text,8,52+i*31,WHITE,DARK,224)
    while True:
        if exit_requested(touch.capture_gesture()): return "EXIT"
