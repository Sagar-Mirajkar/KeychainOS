"""Paged SD-card text viewer."""
def run(display,touch,ui,path):
    text=open(path,'r').read(); lines=text.splitlines() or ['']; offset=0
    while True:
        display.fill(0x0841); ui.draw_text(display,'< BACK',8,8,0xFFFF,0x001F,56)
        for i,line in enumerate(lines[offset:offset+15]): ui.draw_text(display,line[:28],6,40+i*18,0xFFFF,0x0841,228)
        g=touch.capture_gesture()
        if g and (g[0]=='RIGHT' or (g[0]=='TAP' and g[1]<70 and g[2]<42)): return 'EXIT'
        if g and g[0]=='UP': offset=min(max(0,len(lines)-15),offset+5)
        elif g and g[0]=='DOWN': offset=max(0,offset-5)
