# KeychainOS SD Media Pack

Supported now:
- FAT SD mounting
- Text paging
- Uncompressed 24-bit BMP
- Raw RGB565 images
- Preconverted RGB565 frame animations

JPEG/PNG/GIF decoding is not included in stock pure-Python MicroPython because of RAM and decoder constraints. Convert media on a computer/phone, or later install custom firmware with native decoders.
