"""Media capability reference for KeychainOS."""
SUPPORTED=('TXT/MD/JSON/PY/CSV','BMP 24-bit uncompressed','RAW RGB565 .rgb','Frame folders of .rgb')
CONVERSION_REQUIRED=('JPEG','PNG','GIF','Animated PNG','Most video')
AUDIO_LIMITED=('WAV requires I2S audio hardware','MP3/AAC require decoder and audio hardware')
