"""Streaming uncompressed 24-bit BMP viewer for ST7789."""
import struct

def show(display,path,x=0,y=0):
    f=open(path,'rb')
    if f.read(2)!=b'BM': f.close(); raise ValueError('Not BMP')
    f.seek(10); offset=struct.unpack('<I',f.read(4))[0]
    f.seek(18); width=struct.unpack('<i',f.read(4))[0]; height=struct.unpack('<i',f.read(4))[0]
    f.seek(28); bpp=struct.unpack('<H',f.read(2))[0]
    f.seek(30); compression=struct.unpack('<I',f.read(4))[0]
    if bpp!=24 or compression!=0: f.close(); raise ValueError('Use uncompressed 24-bit BMP')
    top_down=height<0; height=abs(height); draw_w=min(width,display.width-x); draw_h=min(height,display.height-y); row_bytes=((width*3+3)//4)*4
    for out_row in range(draw_h):
        source_row=out_row if top_down else height-1-out_row
        f.seek(offset+source_row*row_bytes); raw=f.read(width*3); rgb565=bytearray(draw_w*2)
        for col in range(draw_w):
            b,g,r=raw[col*3:col*3+3]; colour=((r&0xF8)<<8)|((g&0xFC)<<3)|(b>>3); rgb565[col*2]=colour>>8; rgb565[col*2+1]=colour&255
        display.set_window(x,y+out_row,x+draw_w-1,y+out_row); display.cs.value(0); display.dc.value(1); display.spi.write(rgb565); display.cs.value(1)
    f.close(); return (width,height)
