"""Play preconverted raw RGB565 frame animations from SD."""
import os,time
import rgb565_viewer

def play(display,touch,folder,width=240,height=320,delay_ms=100,loop=True):
    frames=sorted(folder+'/'+n for n in os.listdir(folder) if n.lower().endswith('.rgb'))
    if not frames: raise ValueError('No .rgb frames')
    while True:
        for path in frames:
            rgb565_viewer.show(display,path,width,height)
            g=touch.poll_gesture()
            if g=='RIGHT': return 'EXIT'
            time.sleep_ms(delay_ms)
        if not loop:return 'EXIT'
