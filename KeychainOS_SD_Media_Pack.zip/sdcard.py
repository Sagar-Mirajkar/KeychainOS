"""Minimal SPI SD-card block driver for MicroPython."""
from micropython import const
import time

_CMD_TIMEOUT=const(100)
_R1_IDLE_STATE=const(1)
_TOKEN_CMD25=const(0xFC)
_TOKEN_STOP_TRAN=const(0xFD)
_TOKEN_DATA=const(0xFE)

class SDCard:
    def __init__(self,spi,cs,baudrate=1320000):
        self.spi=spi; self.cs=cs; self.cmdbuf=bytearray(6); self.dummy=bytearray(512); self.tokenbuf=bytearray(1); self.cdv=512
        self.cs.init(self.cs.OUT,value=1); self.init_card(baudrate)
    def _spi_init(self,baudrate): self.spi.init(baudrate=baudrate,phase=0,polarity=0)
    def _select(self): self.cs(0)
    def _deselect(self): self.cs(1); self.spi.write(b'\xff')
    def _cmd(self,cmd,arg,crc,final=0,release=True,skip1=False):
        self.cmdbuf[0]=0x40|cmd; self.cmdbuf[1]=(arg>>24)&255; self.cmdbuf[2]=(arg>>16)&255; self.cmdbuf[3]=(arg>>8)&255; self.cmdbuf[4]=arg&255; self.cmdbuf[5]=crc
        self._select(); self.spi.write(self.cmdbuf)
        if skip1: self.spi.readinto(self.tokenbuf,0xff)
        for _ in range(_CMD_TIMEOUT):
            self.spi.readinto(self.tokenbuf,0xff); response=self.tokenbuf[0]
            if not response&0x80:
                for _ in range(final): self.spi.readinto(self.tokenbuf,0xff)
                if release:self._deselect()
                return response
        self._deselect(); return -1
    def init_card(self,baudrate):
        self._spi_init(100000); self.cs(1)
        for _ in range(16): self.spi.write(b'\xff')
        for _ in range(5):
            if self._cmd(0,0,0x95)==_R1_IDLE_STATE: break
        else: raise OSError('no SD card')
        r=self._cmd(8,0x1aa,0x87,4)
        if r==_R1_IDLE_STATE:
            for _ in range(1000):
                self._cmd(55,0,0); r=self._cmd(41,0x40000000,0)
                if r==0: break
                time.sleep_ms(1)
            else: raise OSError('SD init timeout')
            self._cmd(58,0,0,4); self.cdv=1
        else:
            for _ in range(1000):
                self._cmd(55,0,0); r=self._cmd(41,0,0)
                if r==0: break
            self.cdv=512
        self._cmd(16,512,0); self._spi_init(baudrate)
    def readblocks(self,block_num,buf):
        nblocks=len(buf)//512
        for i in range(nblocks):
            if self._cmd(17,(block_num+i)*self.cdv,0,release=False)!=0: self._deselect(); return 1
            for _ in range(1000):
                self.spi.readinto(self.tokenbuf,0xff)
                if self.tokenbuf[0]==_TOKEN_DATA: break
            self.spi.readinto(memoryview(buf)[i*512:(i+1)*512],0xff); self.spi.read(2,0xff); self._deselect()
        return 0
    def writeblocks(self,block_num,buf):
        nblocks=len(buf)//512
        for i in range(nblocks):
            if self._cmd(24,(block_num+i)*self.cdv,0,release=False)!=0: self._deselect(); return 1
            self.spi.write(b'\xff'+bytes([_TOKEN_DATA])); self.spi.write(memoryview(buf)[i*512:(i+1)*512]); self.spi.write(b'\xff\xff')
            self.spi.readinto(self.tokenbuf,0xff); self._deselect()
        return 0
    def ioctl(self,op,arg):
        if op==4:return 0
        if op==5:return 512
        if op==6:return 0
        return 0
