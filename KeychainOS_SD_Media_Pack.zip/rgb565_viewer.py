"""Viewer for raw RGB565 big-endian images."""
def show(display,path,width,height,x=0,y=0):
    f=open(path,'rb'); draw_w=min(width,display.width-x); draw_h=min(height,display.height-y)
    for row in range(draw_h):
        data=f.read(width*2)
        if len(data)<width*2: break
        display.set_window(x,y+row,x+draw_w-1,y+row); display.cs.value(0); display.dc.value(1); display.spi.write(data[:draw_w*2]); display.cs.value(1)
    f.close()
