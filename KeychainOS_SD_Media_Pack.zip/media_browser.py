"""SD media browser for text, BMP, RGB565, and frame folders."""
import os
import sd_manager,bmp_viewer,rgb565_viewer,sd_text_viewer,frame_animation
TEXT_EXT=('.txt','.md','.json','.py','.csv','.log')

def open_item(display,touch,ui,path):
    lower=path.lower()
    if lower.endswith(TEXT_EXT): return sd_text_viewer.run(display,touch,ui,path)
    if lower.endswith('.bmp'): display.fill(0); bmp_viewer.show(display,path); touch.capture_gesture(); return 'EXIT'
    if lower.endswith('.rgb'): rgb565_viewer.show(display,path,240,320); touch.capture_gesture(); return 'EXIT'
    try:
        os.listdir(path); return frame_animation.play(display,touch,path)
    except OSError: raise ValueError('Unsupported file type')

def run(display,touch,ui,start='/sd'):
    sd_manager.mount(); path=start; selected=0; offset=0
    while True:
        names=sorted(os.listdir(path)); display.fill(0x0841); ui.draw_text(display,'< SD MEDIA',8,8,0xFFFF,0x001F,96)
        visible=names[offset:offset+11]
        for i,name in enumerate(visible):
            colour=0x07FF if offset+i==selected else 0xFFFF; ui.draw_text(display,name[:27],8,44+i*24,colour,0x0841,220)
        g=touch.capture_gesture()
        if g and (g[0]=='RIGHT' or (g[0]=='TAP' and g[1]<70 and g[2]<42)):
            if path!='/sd': path=path.rsplit('/',1)[0] or '/sd'; selected=offset=0
            else:return 'EXIT'
        elif g and g[0]=='UP' and names: selected=min(len(names)-1,selected+1); offset=max(offset,selected-10)
        elif g and g[0]=='DOWN' and names: selected=max(0,selected-1); offset=min(offset,selected)
        elif g and g[0]=='TAP' and names: open_item(display,touch,ui,path+'/'+names[selected])
