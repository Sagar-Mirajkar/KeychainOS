"""Mount and manage the display-side SD card."""
from machine import Pin,SPI
import os
import sdcard

MOUNT_POINT='/sd'; SD_CS=38

def mount():
    try:
        os.stat(MOUNT_POINT); return MOUNT_POINT
    except OSError: pass
    spi=SPI(2,baudrate=1320000,polarity=0,phase=0,sck=Pin(1),mosi=Pin(2),miso=Pin(42))
    card=sdcard.SDCard(spi,Pin(SD_CS,Pin.OUT,value=1))
    os.mount(card,MOUNT_POINT)
    return MOUNT_POINT

def unmount():
    try: os.umount(MOUNT_POINT)
    except OSError: pass

def usage():
    v=os.statvfs(MOUNT_POINT); block=v[0]; return {'total':v[2]*block,'free':v[3]*block}

def files(path=MOUNT_POINT): return sorted(os.listdir(path))
