@echo off
setlocal EnableExtensions

REM ============================================================
REM KeychainOS MicroPython modular project scaffold
REM Creates the project in the folder where this BAT is executed.
REM ============================================================

set "ROOT=%CD%\KeychainOS_MicroPython"

if exist "%ROOT%" (
    echo.
    echo ERROR: The destination already exists:
    echo %ROOT%
    echo.
    echo Rename or remove that folder, then run this script again.
    exit /b 1
)

echo Creating KeychainOS project at:
echo %ROOT%
echo.

REM Create folders
mkdir "%ROOT%" || exit /b 1
mkdir "%ROOT%\games" || exit /b 1
mkdir "%ROOT%\apps" || exit /b 1
mkdir "%ROOT%\system" || exit /b 1
mkdir "%ROOT%\assets" || exit /b 1
mkdir "%ROOT%\assets\icons" || exit /b 1
mkdir "%ROOT%\assets\images" || exit /b 1

REM Root main.py
> "%ROOT%\main.py" (
    echo """KeychainOS main entry point.
    echo.
    echo Keep startup, app selection, and navigation here.
    echo Display and touch hardware will move to system modules.
    echo """
    echo.
    echo from games import snake
    echo from games import tic_tac_toe
    echo.
    echo.
    echo def build_context^(^):
    echo     """Return shared display, touch, and UI callbacks.
    echo.
    echo     Replace the placeholders after moving the working hardware
    echo     functions from the current monolithic main.py.
    echo     """
    echo     return {
    echo         "fill_rect": None,
    echo         "fill_screen": None,
    echo         "draw_text": None,
    echo         "outline_rect": None,
    echo         "capture_gesture": None,
    echo         "read_touch": None,
    echo         "width": 240,
    echo         "height": 320,
    echo     }
    echo.
    echo.
    echo def launch_game^(game_name, context^):
    echo     if game_name == "SNAKE":
    echo         return snake.run^(context^)
    echo.
    echo     if game_name == "TIC TAC TOE":
    echo         return tic_tac_toe.run^(context^)
    echo.
    echo     return "NOT_FOUND"
    echo.
    echo.
    echo def main^(^):
    echo     context = build_context^(^)
    echo     print^("KeychainOS modular scaffold created"^)
    echo     print^("Move the working display, touch, UI, and game code into the modules."^)
    echo.
    echo.
    echo main^(^)
)

REM Package markers
> "%ROOT%\games\__init__.py" echo """KeychainOS games package."""
> "%ROOT%\apps\__init__.py" echo """KeychainOS applications package."""
> "%ROOT%\system\__init__.py" echo """KeychainOS shared system package."""

REM Game modules
> "%ROOT%\games\snake.py" (
    echo """Snake game module."""
    echo.
    echo GAME_NAME = "SNAKE"
    echo.
    echo.
    echo def run^(context^):
    echo     """Run Snake and return control to main.py when finished."""
    echo     print^("Snake module loaded"^)
    echo     # Move the existing Snake functions and game loop here.
    echo     # Use callbacks from context instead of importing main.py.
    echo     return "EXIT"
)

> "%ROOT%\games\tic_tac_toe.py" (
    echo """Two-player Tic-Tac-Toe game module."""
    echo.
    echo GAME_NAME = "TIC TAC TOE"
    echo.
    echo.
    echo def run^(context^):
    echo     """Run Tic-Tac-Toe and return control to main.py when finished."""
    echo     print^("Tic-Tac-Toe module loaded"^)
    echo     # Move the existing Tic-Tac-Toe functions and game loop here.
    echo     # Use callbacks from context instead of importing main.py.
    echo     return "EXIT"
)

REM Future game template
> "%ROOT%\games\game_template.py" (
    echo """Copy this file when adding a new game."""
    echo.
    echo GAME_NAME = "NEW GAME"
    echo.
    echo.
    echo def run^(context^):
    echo     fill_screen = context.get^("fill_screen"^)
    echo     draw_text = context.get^("draw_text"^)
    echo     capture_gesture = context.get^("capture_gesture"^)
    echo.
    echo     # Add game initialization and loop here.
    echo     return "EXIT"
)

REM Shared system modules
> "%ROOT%\system\hardware.py" (
    echo """Hardware pin definitions and initialization.
    echo.
    echo Move the proven SPI, I2C, LCD, backlight, and touch initialization
    echo from the current main.py into this module.
    echo """
    echo.
    echo LCD_SCLK = 1
    echo LCD_MOSI = 2
    echo LCD_MISO = 42
    echo LCD_CS = 39
    echo LCD_DC = 41
    echo LCD_RST = 40
    echo LCD_BL = 6
    echo SD_CS = 38
    echo.
    echo TP_SDA = 15
    echo TP_SCL = 7
    echo TP_RST = 16
    echo TP_INT = 17
    echo TP_ADDRESS = 0x15
    echo.
    echo WIDTH = 240
    echo HEIGHT = 320
)

> "%ROOT%\system\display.py" (
    echo """Shared ST7789 display driver and drawing primitives.
    echo.
    echo Move lcd_command, init_display, set_window, fill_rect,
    echo fill_screen, outline_rect, and draw_text here.
    echo """
)

> "%ROOT%\system\touch.py" (
    echo """Shared CST816D touch driver and gesture detection.
    echo.
    echo Move init_touch, read_touch, transform_touch,
    echo capture_gesture, and related settings here.
    echo """
)

> "%ROOT%\system\colours.py" (
    echo """Shared RGB565 colour constants."""
    echo.
    echo BLACK = 0x0000
    echo WHITE = 0xFFFF
    echo RED = 0xF800
    echo GREEN = 0x07E0
    echo BLUE = 0x001F
    echo CYAN = 0x07FF
    echo YELLOW = 0xFFE0
    echo MAGENTA = 0xF81F
    echo ORANGE = 0xFD20
)

> "%ROOT%\system\ui.py" (
    echo """Shared KeychainOS UI components.
    echo.
    echo Move the status bar, carousel, app tiles, icons,
    echo home screen, and Games menu rendering here.
    echo """
)

REM App modules
> "%ROOT%\apps\files.py" (
    echo """Files application placeholder."""
    echo.
    echo APP_NAME = "FILES"
    echo.
    echo.
    echo def run^(context^):
    echo     print^("Files app opened"^)
    echo     return "EXIT"
)

> "%ROOT%\apps\notes.py" (
    echo """Notes application placeholder."""
    echo.
    echo APP_NAME = "NOTES"
    echo.
    echo.
    echo def run^(context^):
    echo     print^("Notes app opened"^)
    echo     return "EXIT"
)

> "%ROOT%\apps\settings.py" (
    echo """Settings application placeholder."""
    echo.
    echo APP_NAME = "SETTINGS"
    echo.
    echo.
    echo def run^(context^):
    echo     print^("Settings app opened"^)
    echo     return "EXIT"
)

REM Asset documentation so folders remain useful outside Git
> "%ROOT%\assets\README.txt" (
    echo KeychainOS runtime assets.
    echo.
    echo icons  - app and game icons
    echo images - wallpapers and image resources
)

> "%ROOT%\PROJECT_STRUCTURE.txt" (
    echo KeychainOS_MicroPython
    echo ^|-- main.py
    echo ^|-- system
    echo ^|   ^|-- __init__.py
    echo ^|   ^|-- hardware.py
    echo ^|   ^|-- display.py
    echo ^|   ^|-- touch.py
    echo ^|   ^|-- colours.py
    echo ^|   `-- ui.py
    echo ^|-- apps
    echo ^|   ^|-- __init__.py
    echo ^|   ^|-- files.py
    echo ^|   ^|-- notes.py
    echo ^|   `-- settings.py
    echo ^|-- games
    echo ^|   ^|-- __init__.py
    echo ^|   ^|-- snake.py
    echo ^|   ^|-- tic_tac_toe.py
    echo ^|   `-- game_template.py
    echo `-- assets
    echo     ^|-- icons
    echo     `-- images
)

echo.
echo SUCCESS: Project structure created.
echo.
tree "%ROOT%" /F
echo.
echo Open the project folder with:
echo explorer "%ROOT%"
echo.
echo IMPORTANT:
echo 1. This creates a safe scaffold; it does not split the existing game logic automatically.
echo 2. Keep a backup of the current working main.py.
echo 3. Upload folders and files to the ESP while preserving their paths.
echo 4. On the ESP, the entry file must be named exactly main.py.

endlocal
