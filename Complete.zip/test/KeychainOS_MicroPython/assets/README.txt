KeychainOS runtime assets.

icons  - app and game icons
images - wallpapers and image resources
