"""KeychainOS main launcher.

Responsibilities:
- Initialize display and touch
- Show the main app carousel
- Show the Games carousel
- Launch modular apps and games
- Restore the correct menu after an app exits
"""

import gc
import time

from system import display
from system import touch
from system import ui

from apps import files
from apps import notes
from apps import settings

from games import snake
from games import tic_tac_toe


# =========================================================
# MENU CONFIGURATION
# =========================================================

HOME_APPS = (
    "FILES",
    "GAMES",
    "NOTES",
    "SETTINGS"
)

GAME_APPS = (
    "SNAKE",
    "TIC TAC TOE"
)

home_index = 0
games_index = 0

screen_mode = "HOME"


# =========================================================
# SHARED CONTEXT
# =========================================================

def build_context():
    """Create shared functions for applications and games."""

    return {
        # Display information
        "width": display.WIDTH,
        "height": display.HEIGHT,

        # Display functions
        "fill_rect": display.fill_rect,
        "fill_screen": display.fill_screen,
        "outline_rect": display.outline_rect,
        "horizontal_line": display.horizontal_line,
        "vertical_line": display.vertical_line,
        "draw_text": display.draw_text,
        "centred_text": display.centred_text,
        "trim_text": display.trim_text,

        # Touch functions
        "read_touch": touch.read,
        "capture_gesture": touch.capture_gesture,
        "poll_gesture": touch.poll_gesture,
        "wait_for_release": touch.wait_for_release,
        "wait_for_tap": touch.wait_for_tap
    }


context = build_context()


# =========================================================
# SCREEN DRAWING
# =========================================================

def draw_home():
    """Draw the main KeychainOS application carousel."""

    global screen_mode

    screen_mode = "HOME"

    ui.draw_carousel(
        HOME_APPS,
        home_index,
        "KeychainOS"
    )


def draw_games_menu():
    """Draw the Games carousel."""

    global screen_mode

    screen_mode = "GAMES"

    ui.draw_carousel(
        GAME_APPS,
        games_index,
        "Games"
    )


# =========================================================
# APPLICATION LAUNCHING
# =========================================================

def launch_home_app():
    """Open the currently selected Home application."""

    selected_app = HOME_APPS[
        home_index
    ]

    print(
        "Opening app:",
        selected_app
    )

    if selected_app == "FILES":
        result = files.run(context)

        if result == "EXIT":
            draw_home()

    elif selected_app == "GAMES":
        draw_games_menu()

    elif selected_app == "NOTES":
        result = notes.run(context)

        if result == "EXIT":
            draw_home()

    elif selected_app == "SETTINGS":
        result = settings.run(context)

        if result == "EXIT":
            draw_home()


def launch_game():
    """Start the currently selected game."""

    selected_game = GAME_APPS[
        games_index
    ]

    print(
        "Starting game:",
        selected_game
    )

    if selected_game == "SNAKE":
        result = snake.run(context)

    elif selected_game == "TIC TAC TOE":
        result = tic_tac_toe.run(
            context
        )

    else:
        result = "NOT_FOUND"

    print(
        "Game result:",
        result
    )

    # Redraw the Games carousel after the game exits.
    draw_games_menu()


# =========================================================
# GESTURE HANDLING
# =========================================================

def handle_home_gesture(
    gesture_type,
    touch_x,
    touch_y
):
    """Handle input while the Home carousel is active."""

    global home_index

    if gesture_type == "LEFT":
        home_index = (
            home_index + 1
        ) % len(HOME_APPS)

        draw_home()

    elif gesture_type == "RIGHT":
        home_index = (
            home_index - 1
        ) % len(HOME_APPS)

        draw_home()

    elif gesture_type == "TAP":
        launch_home_app()


def handle_games_gesture(
    gesture_type,
    touch_x,
    touch_y
):
    """Handle input while the Games carousel is active."""

    global games_index

    if gesture_type == "LEFT":
        games_index = (
            games_index + 1
        ) % len(GAME_APPS)

        draw_games_menu()

    elif gesture_type == "RIGHT":
        games_index = (
            games_index - 1
        ) % len(GAME_APPS)

        draw_games_menu()

    elif gesture_type == "DOWN":
        draw_home()

    elif gesture_type == "TAP":
        launch_game()


# =========================================================
# STARTUP
# =========================================================

def initialize_keychainos():
    """Initialize KeychainOS hardware and draw Home."""

    print()
    print("================================")
    print("KeychainOS Modular Firmware")
    print("================================")

    gc.collect()

    print(
        "Free memory:",
        gc.mem_free()
    )

    display.init()

    if not touch.init():
        display.fill_screen(
            0xF800
        )

        display.centred_text(
            "TOUCH ERROR",
            140,
            0xFFFF,
            0xF800
        )

        display.centred_text(
            "CHECK TERMINAL",
            165,
            0xFFFF,
            0xF800
        )

        print(
            "KeychainOS stopped:"
            " touch controller unavailable"
        )

        return False

    draw_home()

    print("KeychainOS ready")

    return True


# =========================================================
# MAIN EVENT LOOP
# =========================================================

def run():
    """Run the KeychainOS menu loop."""

    if not initialize_keychainos():
        while True:
            time.sleep(1)

    while True:
        try:
            gesture = (
                touch.capture_gesture()
            )

            if gesture is None:
                time.sleep_ms(10)
                continue

            gesture_type = gesture[0]
            touch_x = gesture[1]
            touch_y = gesture[2]

            if screen_mode == "HOME":
                handle_home_gesture(
                    gesture_type,
                    touch_x,
                    touch_y
                )

            elif screen_mode == "GAMES":
                handle_games_gesture(
                    gesture_type,
                    touch_x,
                    touch_y
                )

        except KeyboardInterrupt:
            print(
                "KeychainOS stopped"
            )

            break

        except Exception as error:
            print(
                "KeychainOS runtime error:"
            )

            print(error)

            display.fill_screen(
                0xF800
            )

            display.centred_text(
                "RUNTIME ERROR",
                140,
                0xFFFF,
                0xF800
            )

            display.centred_text(
                "CHECK TERMINAL",
                165,
                0xFFFF,
                0xF800
            )

            time.sleep(2)

            draw_home()


run()