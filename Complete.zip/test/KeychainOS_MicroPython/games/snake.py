"""Snake game for KeychainOS.

The game does not initialize display or touch hardware.
Shared drawing and touch functions are supplied by main.py
through the context dictionary.
"""

import random
import time


GAME_NAME = "SNAKE"


# =========================================================
# GAME CONFIGURATION
# =========================================================

GRID_SIZE = 12

PLAY_X = 0
PLAY_Y = 48
PLAY_WIDTH = 240
PLAY_HEIGHT = 240

COLUMNS = PLAY_WIDTH // GRID_SIZE
ROWS = PLAY_HEIGHT // GRID_SIZE

STARTING_SPEED_MS = 180
MINIMUM_SPEED_MS = 75
SPEED_INCREASE_MS = 5


# =========================================================
# FALLBACK COLOURS
# =========================================================

BLACK = 0x0000
WHITE = 0xFFFF
RED = 0xF800
GREEN = 0x07E0
CYAN = 0x07FF
YELLOW = 0xFFE0

DARK_BACKGROUND = 0x0841
HEADER = 0x021F
CARD = 0x18E3
BORDER = 0x528A
MUTED = 0xA514

SNAKE_GREEN = 0x07E0
SNAKE_HEAD = 0xFFE0
FOOD_RED = 0xF800


# =========================================================
# SHARED FUNCTIONS
# =========================================================

def get_required_context(context):
    """Validate and extract shared KeychainOS functions."""

    required_names = (
        "fill_rect",
        "fill_screen",
        "draw_text",
        "outline_rect",
        "capture_gesture",
        "poll_gesture"
    )

    missing_names = []

    for name in required_names:
        if context.get(name) is None:
            missing_names.append(name)

    if missing_names:
        raise ValueError(
            "Snake missing context: "
            + ", ".join(missing_names)
        )

    return {
        "fill_rect": context["fill_rect"],
        "fill_screen": context["fill_screen"],
        "draw_text": context["draw_text"],
        "outline_rect": context["outline_rect"],
        "capture_gesture": context["capture_gesture"],
        "poll_gesture": context["poll_gesture"]
    }


# =========================================================
# GAME HELPERS
# =========================================================

def create_food(snake):
    """Return a random unoccupied grid position."""

    available_positions = (
        COLUMNS * ROWS
        - len(snake)
    )

    if available_positions <= 0:
        return None

    while True:
        position = (
            random.randrange(COLUMNS),
            random.randrange(ROWS)
        )

        if position not in snake:
            return position


def draw_cell(
    fill_rect,
    cell,
    colour,
    inset=1
):
    """Draw one Snake grid cell."""

    column, row = cell

    pixel_x = (
        PLAY_X
        + column * GRID_SIZE
        + inset
    )

    pixel_y = (
        PLAY_Y
        + row * GRID_SIZE
        + inset
    )

    cell_size = (
        GRID_SIZE
        - inset * 2
    )

    fill_rect(
        pixel_x,
        pixel_y,
        cell_size,
        cell_size,
        colour
    )


def clear_cell(
    fill_rect,
    cell
):
    """Clear one previously occupied grid cell."""

    draw_cell(
        fill_rect,
        cell,
        BLACK,
        inset=0
    )


def draw_header(
    fill_rect,
    draw_text,
    score,
    speed_ms
):
    """Draw the Snake title and score area."""

    fill_rect(
        0,
        0,
        240,
        48,
        HEADER
    )

    draw_text(
        "< SNAKE",
        8,
        5,
        WHITE,
        HEADER,
        72
    )

    draw_text(
        "SCORE {}".format(score),
        144,
        5,
        YELLOW,
        HEADER,
        88
    )

    draw_text(
        "Swipe to steer",
        60,
        27,
        CYAN,
        HEADER,
        120
    )


def draw_playfield(
    fill_rect,
    outline_rect,
    draw_text
):
    """Draw the gameplay area and footer."""

    fill_rect(
        PLAY_X,
        PLAY_Y,
        PLAY_WIDTH,
        PLAY_HEIGHT,
        BLACK
    )

    outline_rect(
        PLAY_X,
        PLAY_Y,
        PLAY_WIDTH,
        PLAY_HEIGHT,
        BORDER,
        2
    )

    fill_rect(
        0,
        288,
        240,
        32,
        DARK_BACKGROUND
    )

    draw_text(
        "Swipe to steer",
        64,
        298,
        MUTED,
        DARK_BACKGROUND,
        120
    )


def draw_initial_state(
    functions,
    snake,
    food,
    score,
    speed_ms
):
    """Render the initial game screen."""

    fill_screen = functions["fill_screen"]
    fill_rect = functions["fill_rect"]
    draw_text = functions["draw_text"]
    outline_rect = functions["outline_rect"]

    fill_screen(BLACK)

    draw_header(
        fill_rect,
        draw_text,
        score,
        speed_ms
    )

    draw_playfield(
        fill_rect,
        outline_rect,
        draw_text
    )

    # Draw the snake body.
    for segment_index in range(
        len(snake) - 1,
        -1,
        -1
    ):
        segment = snake[segment_index]

        if segment_index == 0:
            colour = SNAKE_HEAD
        else:
            colour = SNAKE_GREEN

        draw_cell(
            fill_rect,
            segment,
            colour
        )

    if food is not None:
        draw_cell(
            fill_rect,
            food,
            FOOD_RED,
            inset=2
        )


def update_direction(
    gesture,
    current_direction,
    pending_direction
):
    """Return the permitted next direction.

    The snake cannot instantly reverse into itself.
    """

    if gesture == "UP":
        if current_direction != (0, 1):
            return (0, -1)

    elif gesture == "DOWN":
        if current_direction != (0, -1):
            return (0, 1)

    elif gesture == "LEFT":
        if current_direction != (1, 0):
            return (-1, 0)

    elif gesture == "RIGHT":
        if current_direction != (-1, 0):
            return (1, 0)

    return pending_direction


def collision_detected(
    new_head,
    snake,
    growing
):
    """Check wall and body collisions."""

    head_x, head_y = new_head

    if (
        head_x < 0
        or head_x >= COLUMNS
        or head_y < 0
        or head_y >= ROWS
    ):
        return True

    # When not growing, the current tail will move away.
    # Excluding it avoids a false collision when moving
    # into the cell the tail is about to leave.
    if growing:
        body_to_check = snake
    else:
        body_to_check = snake[:-1]

    return new_head in body_to_check


# =========================================================
# RESULT SCREEN
# =========================================================

def show_result(
    functions,
    score
):
    """Show the result and wait for retry or exit.

    Returns:
        "RETRY"
        "EXIT"
    """

    fill_rect = functions["fill_rect"]
    draw_text = functions["draw_text"]
    outline_rect = functions["outline_rect"]
    capture_gesture = functions["capture_gesture"]

    fill_rect(
        20,
        108,
        200,
        112,
        CARD
    )

    outline_rect(
        20,
        108,
        200,
        112,
        RED,
        3
    )

    draw_text(
        "GAME OVER",
        76,
        126,
        RED,
        CARD,
        96
    )

    draw_text(
        "SCORE: {}".format(score),
        76,
        154,
        YELLOW,
        CARD,
        112
    )

    draw_text(
        "Tap: retry",
        68,
        181,
        WHITE,
        CARD,
        104
    )

    draw_text(
        "Swipe right: menu",
        44,
        201,
        MUTED,
        CARD,
        152
    )

    while True:
        gesture = capture_gesture()

        if gesture is None:
            time.sleep_ms(10)
            continue

        gesture_type = gesture[0]

        if gesture_type == "RIGHT":
            return "EXIT"

        if gesture_type == "TAP":
            return "RETRY"


def show_victory(
    functions,
    score
):
    """Show a board-completed message."""

    fill_rect = functions["fill_rect"]
    draw_text = functions["draw_text"]
    outline_rect = functions["outline_rect"]
    capture_gesture = functions["capture_gesture"]

    fill_rect(
        20,
        108,
        200,
        112,
        CARD
    )

    outline_rect(
        20,
        108,
        200,
        112,
        GREEN,
        3
    )

    draw_text(
        "BOARD CLEARED",
        56,
        126,
        GREEN,
        CARD,
        128
    )

    draw_text(
        "SCORE: {}".format(score),
        76,
        154,
        YELLOW,
        CARD,
        112
    )

    draw_text(
        "Tap: restart",
        64,
        181,
        WHITE,
        CARD,
        112
    )

    draw_text(
        "Swipe right: menu",
        44,
        201,
        MUTED,
        CARD,
        152
    )

    while True:
        gesture = capture_gesture()

        if gesture is None:
            time.sleep_ms(10)
            continue

        if gesture[0] == "RIGHT":
            return "EXIT"

        if gesture[0] == "TAP":
            return "RETRY"


# =========================================================
# GAME LOOP
# =========================================================

def play_round(functions):
    """Play one round of Snake.

    Returns:
        "RETRY"
        "EXIT"
    """

    fill_rect = functions["fill_rect"]
    draw_text = functions["draw_text"]
    poll_gesture = functions["poll_gesture"]

    snake = [
        (8, 10),
        (7, 10),
        (6, 10)
    ]

    current_direction = (1, 0)
    pending_direction = current_direction

    score = 0
    speed_ms = STARTING_SPEED_MS

    food = create_food(snake)

    draw_initial_state(
        functions,
        snake,
        food,
        score,
        speed_ms
    )

    last_step_time = (
        time.ticks_ms()
    )

    while True:
        gesture = poll_gesture()

        if gesture is not None:
            pending_direction = update_direction(
                gesture,
                current_direction,
                pending_direction
            )

        current_time = time.ticks_ms()

        if time.ticks_diff(
            current_time,
            last_step_time
        ) < speed_ms:
            time.sleep_ms(5)
            continue

        last_step_time = current_time
        current_direction = pending_direction

        current_head = snake[0]

        new_head = (
            current_head[0]
            + current_direction[0],

            current_head[1]
            + current_direction[1]
        )

        growing = (
            food is not None
            and new_head == food
        )

        if collision_detected(
            new_head,
            snake,
            growing
        ):
            return show_result(
                functions,
                score
            )

        # Previous head becomes a body segment.
        draw_cell(
            fill_rect,
            snake[0],
            SNAKE_GREEN
        )

        # Add and draw new head.
        snake.insert(
            0,
            new_head
        )

        draw_cell(
            fill_rect,
            new_head,
            SNAKE_HEAD
        )

        if growing:
            score += 1

            speed_ms = max(
                MINIMUM_SPEED_MS,
                STARTING_SPEED_MS
                - score * SPEED_INCREASE_MS
            )

            draw_header(
                fill_rect,
                draw_text,
                score,
                speed_ms
            )

            food = create_food(snake)

            if food is None:
                return show_victory(
                    functions,
                    score
                )

            draw_cell(
                fill_rect,
                food,
                FOOD_RED,
                inset=2
            )

        else:
            previous_tail = snake.pop()

            clear_cell(
                fill_rect,
                previous_tail
            )


# =========================================================
# PUBLIC ENTRY POINT
# =========================================================

def run(context):
    """Start Snake.

    Args:
        context:
            Dictionary containing shared KeychainOS display
            and touch functions.

    Returns:
        "EXIT" when the player returns to the Games menu.
    """

    print("Starting Snake")

    functions = get_required_context(
        context
    )

    while True:
        result = play_round(
            functions
        )

        if result == "EXIT":
            print("Exiting Snake")
            return "EXIT"

        # A RETRY result starts a new round.