"""Two-player Tic-Tac-Toe game for KeychainOS."""

import time


GAME_NAME = "TIC TAC TOE"


# Board layout
BOARD_X = 21
BOARD_Y = 66
CELL_SIZE = 66
BOARD_SIZE = CELL_SIZE * 3

# Colours
BLACK = 0x0000
WHITE = 0xFFFF
RED = 0xF800
GREEN = 0x07E0
CYAN = 0x07FF
YELLOW = 0xFFE0

DARK_BG = 0x0841
HEADER = 0x021F
CARD = 0x18E3
BORDER = 0x528A
MUTED = 0xA514

PLAYER_X_COLOUR = 0xF960
PLAYER_O_COLOUR = 0x04FF
WIN_COLOUR = 0x07E0


def get_functions(context):
    required = (
        "fill_rect",
        "fill_screen",
        "draw_text",
        "outline_rect",
        "capture_gesture"
    )

    for name in required:
        if context.get(name) is None:
            raise ValueError(
                "Tic-Tac-Toe missing context: " + name
            )

    return {
        "fill_rect": context["fill_rect"],
        "fill_screen": context["fill_screen"],
        "draw_text": context["draw_text"],
        "outline_rect": context["outline_rect"],
        "capture_gesture": context["capture_gesture"]
    }


def create_board():
    return [
        ["", "", ""],
        ["", "", ""],
        ["", "", ""]
    ]


def draw_grid(functions):
    fill_rect = functions["fill_rect"]
    fill_screen = functions["fill_screen"]
    draw_text = functions["draw_text"]
    outline_rect = functions["outline_rect"]

    fill_screen(DARK_BG)

    fill_rect(
        0,
        0,
        240,
        48,
        HEADER
    )

    draw_text(
        "< TIC TAC TOE",
        8,
        5,
        WHITE,
        HEADER,
        128
    )

    draw_text(
        "2 PLAYER",
        160,
        5,
        CYAN,
        HEADER,
        72
    )

    fill_rect(
        BOARD_X,
        BOARD_Y,
        BOARD_SIZE,
        BOARD_SIZE,
        BLACK
    )

    outline_rect(
        BOARD_X,
        BOARD_Y,
        BOARD_SIZE,
        BOARD_SIZE,
        WHITE,
        2
    )

    for index in (1, 2):
        line_x = (
            BOARD_X
            + index * CELL_SIZE
        )

        line_y = (
            BOARD_Y
            + index * CELL_SIZE
        )

        fill_rect(
            line_x - 1,
            BOARD_Y,
            3,
            BOARD_SIZE,
            BORDER
        )

        fill_rect(
            BOARD_X,
            line_y - 1,
            BOARD_SIZE,
            3,
            BORDER
        )

    fill_rect(
        0,
        278,
        240,
        42,
        DARK_BG
    )

    draw_text(
        "Tap an empty square",
        44,
        282,
        MUTED,
        DARK_BG,
        160
    )

    draw_text(
        "Swipe right to exit",
        44,
        301,
        MUTED,
        DARK_BG,
        160
    )


def show_turn(functions, player):
    fill_rect = functions["fill_rect"]
    draw_text = functions["draw_text"]

    fill_rect(
        0,
        24,
        240,
        24,
        HEADER
    )

    if player == "X":
        colour = PLAYER_X_COLOUR
    else:
        colour = PLAYER_O_COLOUR

    draw_text(
        "Player {} turn".format(player),
        68,
        27,
        colour,
        HEADER,
        112
    )


def draw_x(functions, row, column):
    fill_rect = functions["fill_rect"]

    start_x = (
        BOARD_X
        + column * CELL_SIZE
        + 13
    )

    start_y = (
        BOARD_Y
        + row * CELL_SIZE
        + 13
    )

    mark_size = CELL_SIZE - 26

    for offset in range(
        0,
        mark_size,
        3
    ):
        fill_rect(
            start_x + offset,
            start_y + offset,
            4,
            4,
            PLAYER_X_COLOUR
        )

        fill_rect(
            start_x + mark_size - 1 - offset,
            start_y + offset,
            4,
            4,
            PLAYER_X_COLOUR
        )


def draw_o(functions, row, column):
    outline_rect = functions["outline_rect"]

    start_x = (
        BOARD_X
        + column * CELL_SIZE
        + 13
    )

    start_y = (
        BOARD_Y
        + row * CELL_SIZE
        + 13
    )

    mark_size = CELL_SIZE - 26

    outline_rect(
        start_x,
        start_y,
        mark_size,
        mark_size,
     