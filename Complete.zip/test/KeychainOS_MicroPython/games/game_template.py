"""Copy this file when adding a new game."""

GAME_NAME = "NEW GAME"


def run(context):
    fill_screen = context.get("fill_screen")
    draw_text = context.get("draw_text")
    capture_gesture = context.get("capture_gesture")

    # Add game initialization and loop here.
    return "EXIT"
