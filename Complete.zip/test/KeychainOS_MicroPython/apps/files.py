"""Files application placeholder for KeychainOS.

SD-card support is temporarily postponed.
"""

import time


APP_NAME = "FILES"


# Colours
BLACK = 0x0000
WHITE = 0xFFFF
YELLOW = 0xFFE0
ORANGE = 0xFD20

CAROUSEL_BACKGROUND = 0xBDF7
MUTED = 0x4208


def get_functions(context):
    required = (
        "fill_rect",
        "fill_screen",
        "draw_text",
        "outline_rect",
        "capture_gesture"
    )

    functions = {}

    for name in required:
        function = context.get(name)

        if function is None:
            raise ValueError(
                "Files app missing context: "
                + name
            )

        functions[name] = function

    return functions


def draw_folder_icon(functions):
    fill_rect = functions["fill_rect"]
    outline_rect = functions["outline_rect"]

    tile_x = 54
    tile_y = 66
    tile_size = 132

    # Tile shadow
    fill_rect(
        tile_x + 4,
        tile_y + 5,
        tile_size,
        tile_size,
        BLACK
    )

    # Orange tile
    fill_rect(
        tile_x,
        tile_y,
        tile_size,
        tile_size,
        ORANGE
    )

    outline_rect(
        tile_x,
        tile_y,
        tile_size,
        tile_size,
        WHITE,
        2
    )

    # Gloss
    fill_rect(
        tile_x + 10,
        tile_y + 10,
        tile_size - 20,
        4,
        WHITE
    )

    # Folder
    folder_x = tile_x + 28
    folder_y = tile_y + 38

    fill_rect(
        folder_x,
        folder_y + 15,
        76,
        48,
        YELLOW
    )

    fill_rect(
        folder_x + 8,
        folder_y + 5,
        32,
        15,
        YELLOW
    )

    fill_rect(
        folder_x + 6,
        folder_y + 27,
        64,
        4,
        ORANGE
    )


def draw_screen(functions):
    fill_rect = functions["fill_rect"]
    fill_screen = functions["fill_screen"]
    draw_text = functions["draw_text"]
    outline_rect = functions["outline_rect"]

    fill_screen(
        CAROUSEL_BACKGROUND
    )

    # Status bar
    fill_rect(
        0,
        0,
        240,
        28,
        CAROUSEL_BACKGROUND
    )

    draw_text(
        "9:41",
        8,
        4,
        BLACK,
        CAROUSEL_BACKGROUND,
        40
    )

    draw_text(
        "Files",
        96,
        4,
        BLACK,
        CAROUSEL_BACKGROUND,
        48
    )

    # Back indicator
    draw_text(
        "<",
        8,
        34,
        BLACK,
        CAROUSEL_BACKGROUND,
        16
    )

    draw_folder_icon(
        functions
    )

    draw_text(
        "FILES",
        100,
        216,
        WHITE,
        CAROUSEL_BACKGROUND,
        40
    )

    draw_text(
        "SD support postponed",
        40,
        252,
        BLACK,
        CAROUSEL_BACKGROUND,
        168
    )

    draw_text(
        "Swipe right to return",
        36,
        286,
        MUTED,
        CAROUSEL_BACKGROUND,
        176
    )


def run(context):
    """Open the Files placeholder.

    Returns:
        "EXIT" when returning to the Home carousel.
    """

    print("Opening Files app")

    functions = get_functions(
        context
    )

    capture_gesture = functions[
        "capture_gesture"
    ]

    draw_screen(functions)

    while True:
        gesture = capture_gesture()

        if gesture is None:
            time.sleep_ms(10)
            continue

        gesture_type = gesture[0]
        touch_x = gesture[1]
        touch_y = gesture[2]

        if gesture_type == "RIGHT":
            print("Closing Files app")
            return "EXIT"

        if (
            gesture_type == "TAP"
            and touch_x < 55
            and touch_y < 65
        ):
            print("Closing Files app")
            return "EXIT"