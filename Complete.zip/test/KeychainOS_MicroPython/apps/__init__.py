"""KeychainOS applications package."""
