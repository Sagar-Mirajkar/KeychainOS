"""Notes application placeholder for KeychainOS."""

import time


APP_NAME = "NOTES"


# Colours
BLACK = 0x0000
WHITE = 0xFFFF
CYAN = 0x07FF
YELLOW = 0xFFE0

CAROUSEL_BACKGROUND = 0xBDF7
NOTE_PAPER = 0xFFDE
NOTE_LINE = 0x7BEF
MUTED = 0x4208


def get_functions(context):
    required = (
        "fill_rect",
        "fill_screen",
        "draw_text",
        "outline_rect",
        "capture_gesture"
    )

    functions = {}

    for name in required:
        function = context.get(name)

        if function is None:
            raise ValueError(
                "Notes app missing context: "
                + name
            )

        functions[name] = function

    return functions


def draw_notes_icon(functions):
    fill_rect = functions["fill_rect"]
    outline_rect = functions["outline_rect"]

    tile_x = 54
    tile_y = 66
    tile_size = 132

    # Tile shadow
    fill_rect(
        tile_x + 4,
        tile_y + 5,
        tile_size,
        tile_size,
        BLACK
    )

    # Cyan app tile
    fill_rect(
        tile_x,
        tile_y,
        tile_size,
        tile_size,
        CYAN
    )

    outline_rect(
        tile_x,
        tile_y,
        tile_size,
        tile_size,
        WHITE,
        2
    )

    # Gloss
    fill_rect(
        tile_x + 10,
        tile_y + 10,
        tile_size - 20,
        4,
        WHITE
    )

    # Note paper
    paper_x = tile_x + 34
    paper_y = tile_y + 30
    paper_width = 64
    paper_height = 76

    fill_rect(
        paper_x,
        paper_y,
        paper_width,
        paper_height,
        NOTE_PAPER
    )

    outline_rect(
        paper_x,
        paper_y,
        paper_width,
        paper_height,
        BLACK,
        2
    )

    # Paper lines
    for line_y in (
        paper_y + 18,
        paper_y + 31,
        paper_y + 44,
        paper_y + 57
    ):
        fill_rect(
            paper_x + 9,
            line_y,
            paper_width - 18,
            2,
            NOTE_LINE
        )

    # Binding marks
    for binding_x in range(
        paper_x + 10,
        paper_x + paper_width - 5,
        12
    ):
        fill_rect(
            binding_x,
            paper_y - 4,
            4,
            10,
            BLACK
        )


def draw_screen(functions):
    fill_rect = functions["fill_rect"]
    fill_screen = functions["fill_screen"]
    draw_text = functions["draw_text"]

    fill_screen(
        CAROUSEL_BACKGROUND
    )

    # Status bar
    fill_rect(
        0,
        0,
        240,
        28,
        CAROUSEL_BACKGROUND
    )

    draw_text(
        "9:41",
        8,
        4,
        BLACK,
        CAROUSEL_BACKGROUND,
        40
    )

    draw_text(
        "Notes",
        96,
        4,
        BLACK,
        CAROUSEL_BACKGROUND,
        48
    )

    # Back indicator
    draw_text(
        "<",
        8,
        34,
        BLACK,
        CAROUSEL_BACKGROUND,
        16
    )

    draw_notes_icon(
        functions
    )

    draw_text(
        "NOTES",
        100,
        216,
        WHITE,
        CAROUSEL_BACKGROUND,
        40
    )

    draw_text(
        "Notes app coming soon",
        36,
        252,
        BLACK,
        CAROUSEL_BACKGROUND,
        176
    )

    draw_text(
        "Swipe right to return",
        36,
        286,
        MUTED,
        CAROUSEL_BACKGROUND,
        176
    )


def run(context):
    """Open the Notes placeholder.

    Returns:
        "EXIT" when returning to the Home carousel.
    """

    print("Opening Notes app")

    functions = get_functions(
        context
    )

    capture_gesture = functions[
        "capture_gesture"
    ]

    draw_screen(functions)

    while True:
        gesture = capture_gesture()

        if gesture is None:
            time.sleep_ms(10)
            continue

        gesture_type = gesture[0]
        touch_x = gesture[1]
        touch_y = gesture[2]

        if gesture_type == "RIGHT":
            print("Closing Notes app")
            return "EXIT"

        if (
            gesture_type == "TAP"
            and touch_x < 55
            and touch_y < 65
        ):
            print("Closing Notes app")
            return "EXIT"