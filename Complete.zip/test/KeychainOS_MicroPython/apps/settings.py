"""Settings application placeholder for KeychainOS."""

import time


APP_NAME = "SETTINGS"


# Colours
BLACK = 0x0000
WHITE = 0xFFFF
CYAN = 0x07FF
GREEN = 0x07E0

CAROUSEL_BACKGROUND = 0xBDF7
SETTINGS_TILE = 0x4208
MUTED = 0x4208


def get_functions(context):
    required = (
        "fill_rect",
        "fill_screen",
        "draw_text",
        "outline_rect",
        "capture_gesture"
    )

    functions = {}

    for name in required:
        function = context.get(name)

        if function is None:
            raise ValueError(
                "Settings app missing context: "
                + name
            )

        functions[name] = function

    return functions


def draw_settings_icon(functions):
    fill_rect = functions["fill_rect"]
    outline_rect = functions["outline_rect"]

    tile_x = 54
    tile_y = 66
    tile_size = 132

    # Tile shadow
    fill_rect(
        tile_x + 4,
        tile_y + 5,
        tile_size,
        tile_size,
        BLACK
    )

    # Dark-grey app tile
    fill_rect(
        tile_x,
        tile_y,
        tile_size,
        tile_size,
        SETTINGS_TILE
    )

    outline_rect(
        tile_x,
        tile_y,
        tile_size,
        tile_size,
        WHITE,
        2
    )

    # Gloss
    fill_rect(
        tile_x + 10,
        tile_y + 10,
        tile_size - 20,
        4,
        WHITE
    )

    # Pixel-style settings gear
    gear_x = tile_x + 35
    gear_y = tile_y + 34

    fill_rect(
        gear_x + 23,
        gear_y,
        16,
        64,
        CYAN
    )

    fill_rect(
        gear_x,
        gear_y + 23,
        64,
        16,
        CYAN
    )

    fill_rect(
        gear_x + 10,
        gear_y + 10,
        44,
        44,
        CYAN
    )

    # Gear centre
    fill_rect(
        gear_x + 24,
        gear_y + 24,
        16,
        16,
        SETTINGS_TILE
    )

    # Corner teeth
    fill_rect(
        gear_x + 8,
        gear_y + 8,
        12,
        12,
        CYAN
    )

    fill_rect(
        gear_x + 44,
        gear_y + 8,
        12,
        12,
        CYAN
    )

    fill_rect(
        gear_x + 8,
        gear_y + 44,
        12,
        12,
        CYAN
    )

    fill_rect(
        gear_x + 44,
        gear_y + 44,
        12,
        12,
        CYAN
    )


def draw_screen(functions):
    fill_rect = functions["fill_rect"]
    fill_screen = functions["fill_screen"]
    draw_text = functions["draw_text"]

    fill_screen(
        CAROUSEL_BACKGROUND
    )

    # Status bar
    fill_