"""Shared CST816D touch driver for KeychainOS.

Hardware:
- Waveshare 2-inch capacitive-touch LCD
- CST816D-compatible touch controller
- I2C address: 0x15
"""

from machine import Pin, I2C
import time


# =========================================================
# TOUCH CONFIGURATION
# =========================================================

SCREEN_WIDTH = 240
SCREEN_HEIGHT = 320

TP_SDA = 15
TP_SCL = 7
TP_RST = 16
TP_INT = 17

TP_ADDRESS = 0x15

I2C_FREQUENCY = 400_000

# These values match the previously working swipe test.
TOUCH_SWAP_XY = False
TOUCH_INVERT_X = False
TOUCH_INVERT_Y = False

# Minimum movement required for a normal menu swipe.
SWIPE_THRESHOLD = 35

# Number of consecutive missing samples required before
# considering the finger released.
RELEASE_SAMPLES = 3

# Delay between touch samples.
SAMPLE_DELAY_MS = 10


# =========================================================
# CST816D REGISTERS
# =========================================================

GESTURE_REGISTER = 0x01
TOUCH_COUNT_REGISTER = 0x02
TOUCH_DATA_REGISTER = 0x03

CHIP_ID_REGISTER = 0xA7
FIRMWARE_VERSION_REGISTER = 0xA9


# =========================================================
# HARDWARE OBJECTS
# =========================================================

touch_reset = Pin(
    TP_RST,
    Pin.OUT,
    value=1
)

touch_interrupt = Pin(
    TP_INT,
    Pin.IN,
    Pin.PULL_UP
)

i2c = I2C(
    1,
    scl=Pin(TP_SCL),
    sda=Pin(TP_SDA),
    freq=I2C_FREQUENCY
)


# =========================================================
# INITIALIZATION
# =========================================================

def hardware_reset():
    """Reset the CST816D touch controller."""

    touch_reset.value(0)
    time.sleep_ms(200)

    touch_reset.value(1)
    time.sleep_ms(300)


def scan():
    """Return the addresses found on the touch I2C bus."""

    return i2c.scan()


def init():
    """Initialize and verify the CST816D touch controller.

    Returns:
        True if the controller is detected.
        False if the controller is not detected.
    """

    print("Initializing CST816D touch controller")

    hardware_reset()

    devices = scan()

    print(
        "Touch I2C devices:",
        [
            hex(address)
            for address in devices
        ]
    )

    if TP_ADDRESS not in devices:
        print(
            "Touch controller not found at",
            hex(TP_ADDRESS)
        )

        return False

    try:
        chip_id = i2c.readfrom_mem(
            TP_ADDRESS,
            CHIP_ID_REGISTER,
            1
        )[0]

        print(
            "CST816D chip ID:",
            hex(chip_id)
        )

    except OSError as error:
        print(
            "Unable to read touch chip ID:",
            error
        )

    try:
        firmware_version = i2c.readfrom_mem(
            TP_ADDRESS,
            FIRMWARE_VERSION_REGISTER,
            1
        )[0]

        print(
            "Touch firmware version:",
            hex(firmware_version)
        )

    except OSError:
        # Firmware-version reading is optional.
        pass

    print("CST816D touch controller ready")

    return True


# =========================================================
# COORDINATE HANDLING
# =========================================================

def transform(raw_x, raw_y):
    """Apply coordinate rotation or inversion settings."""

    x = raw_x
    y = raw_y

    if TOUCH_SWAP_XY:
        x, y = y, x

    if TOUCH_INVERT_X:
        x = (
            SCREEN_WIDTH
            - 1
            - x
        )

    if TOUCH_INVERT_Y:
        y = (
            SCREEN_HEIGHT
            - 1
            - y
        )

    return x, y


def read():
    """Read the current touch coordinates.

    Returns:
        (x, y) while the screen is touched.
        None when the screen is not touched.
    """

    try:
        touch_count = i2c.readfrom_mem(
            TP_ADDRESS,
            TOUCH_COUNT_REGISTER,
            1
        )[0]

        if touch_count == 0:
            return None

        coordinate_data = i2c.readfrom_mem(
            TP_ADDRESS,
            TOUCH_DATA_REGISTER,
            4
        )

        raw_x = (
            (
                coordinate_data[0]
                & 0x0F
            )
            << 8
        ) | coordinate_data[1]

        raw_y = (
            (
                coordinate_data[2]
                & 0x0F
            )
            << 8
        ) | coordinate_data[3]

        return transform(
            raw_x,
            raw_y
        )

    except OSError:
        return None


def interrupt_active():
    """Return True when the CST816D interrupt line is active."""

    return touch_interrupt.value() == 0


# =========================================================
# GESTURE DETECTION
# =========================================================

def capture_gesture(
    swipe_threshold=SWIPE_THRESHOLD,
    sample_delay_ms=SAMPLE_DELAY_MS,
    release_samples=RELEASE_SAMPLES
):
    """Wait for and capture one complete touch gesture.

    Returns:
        ("LEFT", x, y)
        ("RIGHT", x, y)
        ("UP", x, y)
        ("DOWN", x, y)
        ("TAP", x, y)

        Returns None if no valid gesture was captured.
    """

    start_point = None
    end_point = None
    missing_samples = 0

    while True:
        point = read()

        if point is not None:
            missing_samples = 0

            if start_point is None:
                start_point = point

            end_point = point

        elif start_point is not None:
            missing_samples += 1

            if missing_samples >= release_samples:
                break

        time.sleep_ms(
            sample_delay_ms
        )

    if (
        start_point is None
        or end_point is None
    ):
        return None

    start_x, start_y = start_point
    end_x, end_y = end_point

    delta_x = end_x - start_x
    delta_y = end_y - start_y

    print(
        "Gesture:",
        start_point,
        "to",
        end_point,
        "delta",
        delta_x,
        delta_y
    )

    # Horizontal gesture
    if (
        abs(delta_x) >= swipe_threshold
        and abs(delta_x) > abs(delta_y)
    ):
        if delta_x < 0:
            return (
                "LEFT",
                end_x,
                end_y
            )

        return (
            "RIGHT",
            end_x,
            end_y
        )

    # Vertical gesture
    if (
        abs(delta_y) >= swipe_threshold
        and abs(delta_y) > abs(delta_x)
    ):
        if delta_y < 0:
            return (
                "UP",
                end_x,
                end_y
            )

        return (
            "DOWN",
            end_x,
            end_y
        )

    return (
        "TAP",
        end_x,
        end_y
    )


def poll_gesture(
    swipe_threshold=24
):
    """Capture a gesture after detecting an active touch.

    This variant is intended for games. It returns immediately
    when no finger is touching the display instead of waiting
    indefinitely.

    Returns:
        "LEFT"
        "RIGHT"
        "UP"
        "DOWN"
        "TAP"
        None
    """

    first_point = read()

    if first_point is None:
        return None

    start_point = first_point
    end_point = first_point
    missing_samples = 0

    while True:
        point = read()

        if point is not None:
            end_point = point
            missing_samples = 0

        else:
            missing_samples += 1

            if missing_samples >= 2:
                break

        time.sleep_ms(5)

    delta_x = (
        end_point[0]
        - start_point[0]
    )

    delta_y = (
        end_point[1]
        - start_point[1]
    )

    if (
        abs(delta_x) >= swipe_threshold
        and abs(delta_x) > abs(delta_y)
    ):
        if delta_x < 0:
            return "LEFT"

        return "RIGHT"

    if (
        abs(delta_y) >= swipe_threshold
        and abs(delta_y) > abs(delta_x)
    ):
        if delta_y < 0:
            return "UP"

        return "DOWN"

    return "TAP"


def wait_for_release():
    """Wait until the finger has been removed from the screen."""

    missing_samples = 0

    while True:
        point = read()

        if point is None:
            missing_samples += 1

            if missing_samples >= RELEASE_SAMPLES:
                return

        else:
            missing_samples = 0

        time.sleep_ms(
            SAMPLE_DELAY_MS
        )


def wait_for_tap():
    """Wait until a tap or another gesture is completed."""

    while True:
        gesture = capture_gesture()

        if gesture is not None:
            return gesture