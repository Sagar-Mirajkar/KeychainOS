"""Shared ST7789 display driver for KeychainOS.

Hardware:
- Waveshare ESP32-S3 LCD Driver Board
- ST7789T3 display
- Resolution: 240 x 320
- RGB565 colour format
"""

from machine import Pin, SPI
import framebuf
import time

from system.colours import BLACK, WHITE, DARK_BG


# =========================================================
# DISPLAY CONFIGURATION
# =========================================================

WIDTH = 240
HEIGHT = 320

LCD_SCLK = 1
LCD_MOSI = 2
LCD_MISO = 42

LCD_CS = 39
LCD_DC = 41
LCD_RST = 40
LCD_BL = 6

# LCD and SD share the SPI bus.
# Keep the SD card deselected during LCD operations.
SD_CS = 38

SPI_FREQUENCY = 20_000_000


# =========================================================
# HARDWARE OBJECTS
# =========================================================

lcd_cs = Pin(
    LCD_CS,
    Pin.OUT,
    value=1
)

lcd_dc = Pin(
    LCD_DC,
    Pin.OUT,
    value=0
)

lcd_rst = Pin(
    LCD_RST,
    Pin.OUT,
    value=1
)

lcd_bl = Pin(
    LCD_BL,
    Pin.OUT,
    value=0
)

sd_cs = Pin(
    SD_CS,
    Pin.OUT,
    value=1
)

spi = SPI(
    2,
    baudrate=SPI_FREQUENCY,
    polarity=0,
    phase=0,
    sck=Pin(LCD_SCLK),
    mosi=Pin(LCD_MOSI),
    miso=Pin(LCD_MISO)
)


# =========================================================
# LOW-LEVEL DISPLAY FUNCTIONS
# =========================================================

def command(command_byte, data=None):
    """Send one command and optional data to the ST7789."""

    # Deselect SD before accessing the shared SPI bus.
    sd_cs.value(1)

    lcd_cs.value(0)
    lcd_dc.value(0)

    spi.write(
        bytes([command_byte])
    )

    if data is not None:
        lcd_dc.value(1)
        spi.write(data)

    lcd_cs.value(1)


def hardware_reset():
    """Perform a hardware reset of the ST7789."""

    lcd_rst.value(1)
    time.sleep_ms(10)

    lcd_rst.value(0)
    time.sleep_ms(100)

    lcd_rst.value(1)
    time.sleep_ms(120)


def init():
    """Initialize the Waveshare ST7789T3 display."""

    print("Initializing ST7789 display")

    # Hide uninitialized or retained display RAM.
    lcd_bl.value(0)

    # Both devices must initially be deselected.
    lcd_cs.value(1)
    sd_cs.value(1)

    hardware_reset()

    # Software reset
    command(0x01)
    time.sleep_ms(150)

    # Exit sleep mode
    command(0x11)
    time.sleep_ms(120)

    # RGB565, 16 bits per pixel
    command(
        0x3A,
        b"\x55"
    )

    # Portrait orientation
    command(
        0x36,
        b"\x00"
    )

    # Display inversion on for this panel
    command(0x21)

    # Normal display mode
    command(0x13)

    # Display on
    command(0x29)
    time.sleep_ms(100)

    # Clear retained display contents.
    fill_screen(BLACK)

    # Reveal the initialized display.
    lcd_bl.value(1)

    print("ST7789 display ready")


def set_backlight(enabled):
    """Turn the LCD backlight on or off."""

    if enabled:
        lcd_bl.value(1)
    else:
        lcd_bl.value(0)


def set_window(x0, y0, x1, y1):
    """Set the rectangular ST7789 drawing window."""

    command(
        0x2A,
        bytes([
            x0 >> 8,
            x0 & 0xFF,
            x1 >> 8,
            x1 & 0xFF
        ])
    )

    command(
        0x2B,
        bytes([
            y0 >> 8,
            y0 & 0xFF,
            y1 >> 8,
            y1 & 0xFF
        ])
    )

    # Start display-memory write
    command(0x2C)


# =========================================================
# DRAWING PRIMITIVES
# =========================================================

def fill_rect(x, y, width, height, colour):
    """Draw a filled RGB565 rectangle with screen clipping."""

    if width <= 0 or height <= 0:
        return

    # Clip the left edge.
    if x < 0:
        width += x
        x = 0

    # Clip the top edge.
    if y < 0:
        height += y
        y = 0

    # Completely outside the display.
    if x >= WIDTH or y >= HEIGHT:
        return

    # Clip the right and lower edges.
    if x + width > WIDTH:
        width = WIDTH - x

    if y + height > HEIGHT:
        height = HEIGHT - y

    if width <= 0 or height <= 0:
        return

    set_window(
        x,
        y,
        x + width - 1,
        y + height - 1
    )

    high_byte = (
        colour >> 8
    ) & 0xFF

    low_byte = colour & 0xFF

    pixel = bytes([
        high_byte,
        low_byte
    ])

    # Send pixels in manageable blocks.
    chunk_pixels = 256
    chunk = pixel * chunk_pixels

    total_pixels = width * height
    complete_chunks = (
        total_pixels // chunk_pixels
    )
    remaining_pixels = (
        total_pixels % chunk_pixels
    )

    sd_cs.value(1)
    lcd_cs.value(0)
    lcd_dc.value(1)

    for _ in range(complete_chunks):
        spi.write(chunk)

    if remaining_pixels:
        spi.write(
            pixel * remaining_pixels
        )

    lcd_cs.value(1)


def fill_screen(colour):
    """Fill the complete 240 x 320 display."""

    fill_rect(
        0,
        0,
        WIDTH,
        HEIGHT,
        colour
    )


def horizontal_line(x, y, width, colour):
    """Draw a horizontal line."""

    fill_rect(
        x,
        y,
        width,
        1,
        colour
    )


def vertical_line(x, y, height, colour):
    """Draw a vertical line."""

    fill_rect(
        x,
        y,
        1,
        height,
        colour
    )


def outline_rect(
    x,
    y,
    width,
    height,
    colour,
    thickness=1
):
    """Draw an outlined rectangle."""

    if thickness < 1:
        thickness = 1

    fill_rect(
        x,
        y,
        width,
        thickness,
        colour
    )

    fill_rect(
        x,
        y + height - thickness,
        width,
        thickness,
        colour
    )

    fill_rect(
        x,
        y,
        thickness,
        height,
        colour
    )

    fill_rect(
        x + width - thickness,
        y,
        thickness,
        height,
        colour
    )


# =========================================================
# TEXT RENDERING
# =========================================================

def _swap_rgb565_byte_pairs(data):
    """Convert framebuf RGB565 byte order to ST7789 byte order."""

    for index in range(
        0,
        len(data),
        2
    ):
        temporary = data[index]

        data[index] = (
            data[index + 1]
        )

        data[index + 1] = temporary


def draw_text(
    text,
    x,
    y,
    colour=WHITE,
    background=DARK_BG,
    width=None,
    height=16
):
    """Draw text using MicroPython's built-in 8 x 8 bitmap font.

    A small temporary framebuffer is created only for the text line.
    This avoids allocating a complete 240 x 320 framebuffer.
    """

    text = str(text)

    if width is None:
        width = WIDTH - x

    # Handle text whose starting position is partially off-screen.
    if x < 0:
        x = 0

    if y < 0:
        y = 0

    if x >= WIDTH or y >= HEIGHT:
        return

    width = min(
        width,
        WIDTH - x
    )

    height = min(
        height,
        HEIGHT - y
    )

    if width <= 0 or height <= 0:
        return

    text_buffer = bytearray(
        width
        * height
        * 2
    )

    text_framebuffer = framebuf.FrameBuffer(
        text_buffer,
        width,
        height,
        framebuf.RGB565
    )

    text_framebuffer.fill(
        background
    )

    text_framebuffer.text(
        text,
        0,
        4,
        colour
    )

    _swap_rgb565_byte_pairs(
        text_buffer
    )

    set_window(
        x,
        y,
        x + width - 1,
        y + height - 1
    )

    sd_cs.value(1)
    lcd_cs.value(0)
    lcd_dc.value(1)

    for start in range(
        0,
        len(text_buffer),
        2048
    ):
        spi.write(
            text_buffer[
                start:start + 2048
            ]
        )

    lcd_cs.value(1)


def centred_text(
    text,
    y,
    colour=WHITE,
    background=DARK_BG
):
    """Draw horizontally centred 8 x 8 text."""

    text = str(text)

    text_width = len(text) * 8

    if text_width > WIDTH:
        text = text[:WIDTH // 8]
        text_width = len(text) * 8

    x = (
        WIDTH - text_width
    ) // 2

    draw_text(
        text,
        x,
        y,
        colour,
        background,
        text_width
    )


def trim_text(text, character_limit):
    """Shorten long text and add an ellipsis."""

    text = str(text)

    if len(text) <= character_limit:
        return text

    if character_limit <= 3:
        return text[:character_limit]

    return (
        text[:character_limit - 3]
        + "..."
    )