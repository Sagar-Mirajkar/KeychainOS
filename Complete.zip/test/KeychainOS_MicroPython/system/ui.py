"""Shared carousel UI and thumbnail icons for KeychainOS."""

from system import display
from system.colours import (
    BLACK,
    WHITE,
    GREEN,
    CYAN,
    YELLOW,
    MAGENTA,
    ORANGE,
    FOLDER_YELLOW,
    GAME_PURPLE,
    SNAKE_GREEN,
    FOOD_RED,
    TICTAC_BLUE,
    TICTAC_RED,
    CAROUSEL_BACKGROUND,
    CAROUSEL_MUTED,
    CAROUSEL_DOT
)


WIDTH = display.WIDTH
HEIGHT = display.HEIGHT

CAROUSEL_TILE = 132
CAROUSEL_X = 54
CAROUSEL_Y = 78
PEEK_WIDTH = 22


def draw_folder_icon(x, y, background):
    display.fill_rect(
        x + 5,
        y + 15,
        58,
        38,
        FOLDER_YELLOW
    )

    display.fill_rect(
        x + 11,
        y + 7,
        25,
        12,
        FOLDER_YELLOW
    )

    display.fill_rect(
        x + 9,
        y + 24,
        50,
        3,
        ORANGE
    )


def draw_gamepad_icon(x, y, background):
    display.fill_rect(
        x + 5,
        y + 17,
        60,
        34,
        GAME_PURPLE
    )

    display.fill_rect(
        x + 13,
        y + 10,
        44,
        48,
        GAME_PURPLE
    )

    # D-pad
    display.fill_rect(
        x + 17,
        y + 28,
        18,
        6,
        WHITE
    )

    display.fill_rect(
        x + 23,
        y + 22,
        6,
        18,
        WHITE
    )

    # Action buttons
    display.fill_rect(
        x + 48,
        y + 25,
        7,
        7,
        CYAN
    )

    display.fill_rect(
        x + 56,
        y + 34,
        7,
        7,
        YELLOW
    )


def draw_snake_icon(x, y, background):
    blocks = (
        (0, 24),
        (10, 24),
        (20, 24),
        (20, 14),
        (30, 14),
        (40, 14),
        (40, 24),
        (50, 24)
    )

    for block_x, block_y in blocks:
        display.fill_rect(
            x + block_x,
            y + block_y,
            9,
            9,
            SNAKE_GREEN
        )

    # Eye
    display.fill_rect(
        x + 57,
        y + 27,
        3,
        3,
        BLACK
    )

    # Food
    display.fill_rect(
        x + 66,
        y + 16,
        8,
        8,
        FOOD_RED
    )


def draw_tic_tac_toe_icon(x, y, background):
    # Grid
    display.fill_rect(
        x + 22,
        y + 5,
        3,
        58,
        WHITE
    )

    display.fill_rect(
        x + 45,
        y + 5,
        3,
        58,
        WHITE
    )

    display.fill_rect(
        x + 4,
        y + 23,
        62,
        3,
        WHITE
    )

    display.fill_rect(
        x + 4,
        y + 45,
        62,
        3,
        WHITE
    )

    # X symbol
    for offset in range(0, 13, 3):
        display.fill_rect(
            x + 7 + offset,
            y + 8 + offset,
            3,
            3,
            TICTAC_RED
        )

        display.fill_rect(
            x + 19 - offset,
            y + 8 + offset,
            3,
            3,
            TICTAC_RED
        )

    # O symbol
    display.outline_rect(
        x + 28,
        y + 29,
        14,
        14,
        TICTAC_BLUE,
        3
    )


def draw_notes_icon(x, y, background):
    display.fill_rect(
        x + 10,
        y + 7,
        50,
        51,
        WHITE
    )

    display.fill_rect(
        x + 17,
        y + 17,
        36,
        3,
        0x021F
    )

    display.fill_rect(
        x + 17,
        y + 27,
        36,
        3,
        0x021F
    )

    display.fill_rect(
        x + 17,
        y + 37,
        28,
        3,
        0x021F
    )

    display.fill_rect(
        x + 17,
        y + 47,
        32,
        3,
        0x021F
    )


def draw_settings_icon(x, y, background):
    display.fill_rect(
        x + 25,
        y + 10,
        20,
        48,
        CYAN
    )

    display.fill_rect(
        x + 11,
        y + 24,
        48,
        20,
        CYAN
    )

    display.fill_rect(
        x + 18,
        y + 17,
        34,
        34,
        CYAN
    )

    display.fill_rect(
        x + 27,
        y + 26,
        16,
        16,
        background
    )


def app_colours(name):
    if name == "FILES":
        return 0xFFE0, 0xFD20

    if name == "GAMES":
        return 0xF81F, 0x8010

    if name == "NOTES":
        return 0x07FF, 0x021F

    if name == "SETTINGS":
        return 0xC618, 0x4208

    if name == "SNAKE":
        return 0x07E0, 0x0320

    if name == "TIC TAC TOE":
        return 0x07FF, 0x001F

    return 0xC618, 0x4208


def draw_soft_tile(
    x,
    y,
    size,
    top_colour,
    bottom_colour
):
    # Shadow
    display.fill_rect(
        x + 4,
        y + 5,
        size,
        size,
        BLACK
    )

    # Rounded-corner illusion
    display.fill_rect(
        x + 8,
        y,
        size - 16,
        3,
        top_colour
    )

    display.fill_rect(
        x + 4,
        y + 3,
        size - 8,
        4,
        top_colour
    )

    display.fill_rect(
        x,
        y + 7,
        size,
        size - 14,
        top_colour
    )

    display.fill_rect(
        x + 4,
        y + size - 7,
        size - 8,
        4,
        bottom_colour
    )

    display.fill_rect(
        x + 8,
        y + size - 3,
        size - 16,
        3,
        bottom_colour
    )

    # Lower colour section
    display.fill_rect(
        x + 1,
        y + size // 2,
        size - 2,
        size // 2 - 7,
        bottom_colour
    )

    # Gloss
    display.fill_rect(
        x + 8,
        y + 9,
        size - 16,
        4,
        WHITE
    )

    display.fill_rect(
        x + 12,
        y + 13,
        size - 24,
        2,
        0xCFFF
    )

    display.outline_rect(
        x + 4,
        y + 3,
        size - 8,
        size - 6,
        WHITE,
        1
    )


def draw_app_icon(
    name,
    x,
    y,
    size,
    background
):
    icon_x = (
        x
        + (size - 72) // 2
    )

    icon_y = y + 26

    if name == "FILES":
        draw_folder_icon(
            icon_x,
            icon_y,
            background
        )

    elif name == "GAMES":
        draw_gamepad_icon(
            icon_x,
            icon_y,
            background
        )

    elif name == "NOTES":
        draw_notes_icon(
            icon_x,
            icon_y,
            background
        )

    elif name == "SETTINGS":
        draw_settings_icon(
            icon_x,
            icon_y,
            background
        )

    elif name == "SNAKE":
        draw_snake_icon(
            icon_x,
            icon_y,
            background
        )

    elif name == "TIC TAC TOE":
        draw_tic_tac_toe_icon(
            icon_x,
            icon_y,
            background
        )


def draw_status_bar(section):
    display.fill_rect(
        0,
        0,
        WIDTH,
        27,
        CAROUSEL_BACKGROUND
    )

    display.draw_text(
        "9:41",
        8,
        4,
        BLACK,
        CAROUSEL_BACKGROUND,
        40
    )

    section_text = display.trim_text(
        section,
        10
    )

    display.draw_text(
        section_text,
        82,
        4,
        BLACK,
        CAROUSEL_BACKGROUND,
        80
    )

    # Battery outline
    display.outline_rect(
        202,
        8,
        27,
        11,
        BLACK,
        1
    )

    display.fill_rect(
        229,
        11,
        3,
        5,
        BLACK
    )

    # Battery charge
    display.fill_rect(
        205,
        11,
        18,
        5,
        GREEN
    )


def draw_peek_tile(side, colour):
    y = CAROUSEL_Y + 18

    if side == "LEFT":
        x = (
            -CAROUSEL_TILE
            + PEEK_WIDTH
        )

    else:
        x = WIDTH - PEEK_WIDTH

    display.fill_rect(
        x,
        y,
        CAROUSEL_TILE,
        CAROUSEL_TILE - 36,
        colour
    )

    display.outline_rect(
        x,
        y,
        CAROUSEL_TILE,
        CAROUSEL_TILE - 36,
        WHITE,
        2
    )


def draw_page_dots(
    selected,
    total
):
    dot_start = (
        WIDTH
        - total * 18
    ) // 2

    for index in range(total):
        if index == selected:
            dot_colour = WHITE
        else:
            dot_colour = CAROUSEL_DOT

        display.fill_rect(
            dot_start + index * 18,
            268,
            10,
            6,
            dot_colour
        )


def draw_carousel(
    items,
    selected,
    section
):
    display.fill_screen(
        CAROUSEL_BACKGROUND
    )

    draw_status_bar(section)

    previous_name = items[
        (selected - 1)
        % len(items)
    ]

    current_name = items[
        selected
    ]

    next_name = items[
        (selected + 1)
        % len(items)
    ]

    previous_colours = app_colours(
        previous_name
    )

    current_colours = app_colours(
        current_name
    )

    next_colours = app_colours(
        next_name
    )

    draw_peek_tile(
        "LEFT",
        previous_colours[1]
    )

    draw_peek_tile(
        "RIGHT",
        next_colours[1]
    )

    draw_soft_tile(
        CAROUSEL_X,
        CAROUSEL_Y,
        CAROUSEL_TILE,
        current_colours[0],
        current_colours[1]
    )

    draw_app_icon(
        current_name,
        CAROUSEL_X,
        CAROUSEL_Y,
        CAROUSEL_TILE,
        current_colours[1]
    )

    label_width = (
        len(current_name) * 8
    )

    if label_width > 216:
        label_width = 216

    label_x = (
        WIDTH - label_width
    ) // 2

    display.draw_text(
        current_name,
        label_x,
        228,
        WHITE,
        CAROUSEL_BACKGROUND,
        label_width
    )

    draw_page_dots(
        selected,
        len(items)
    )

    display.draw_text(
        "Swipe to browse",
        64,
        288,
        CAROUSEL_MUTED,
        CAROUSEL_BACKGROUND,
        120
    )

    display.draw_text(
        "Tap to open",
        76,
        304,
        BLACK,
        CAROUSEL_BACKGROUND,
        96
    )


def draw_placeholder(
    title,
    message
):
    display.fill_screen(
        CAROUSEL_BACKGROUND
    )

    draw_status_bar(title)

    tile_colours = app_colours(
        title
    )

    draw_soft_tile(
        CAROUSEL_X,
        70,
        CAROUSEL_TILE,
        tile_colours[0],
        tile_colours[1]
    )

    draw_app_icon(
        title,
        CAROUSEL_X,
        70,
        CAROUSEL_TILE,
        tile_colours[1]
    )

    title_width = min(
        WIDTH,
        len(title) * 8
    )

    display.draw_text(
        title,
        (
            WIDTH
            - title_width
        ) // 2,
        222,
        WHITE,
        CAROUSEL_BACKGROUND,
        title_width
    )

    display.draw_text(
        display.trim_text(
            message,
            25
        ),
        20,
        260,
        BLACK,
        CAROUSEL_BACKGROUND,
        200
    )

    display.draw_text(
        "Swipe right to return",
        36,
        292,
        CAROUSEL_MUTED,
        CAROUSEL_BACKGROUND,
        176
    )