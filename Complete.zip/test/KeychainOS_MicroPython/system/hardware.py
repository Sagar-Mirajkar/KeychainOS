"""Hardware pin definitions and initialization.

Move the proven SPI, I2C, LCD, backlight, and touch initialization
from the current main.py into this module.
"""

LCD_SCLK = 1
LCD_MOSI = 2
LCD_MISO = 42
LCD_CS = 39
LCD_DC = 41
LCD_RST = 40
LCD_BL = 6
SD_CS = 38

TP_SDA = 15
TP_SCL = 7
TP_RST = 16
TP_INT = 17
TP_ADDRESS = 0x15

WIDTH = 240
HEIGHT = 320
