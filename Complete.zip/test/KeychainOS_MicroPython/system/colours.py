"""Shared RGB565 colour constants for KeychainOS."""

# Basic colours
BLACK = 0x0000
WHITE = 0xFFFF

RED = 0xF800
GREEN = 0x07E0
BLUE = 0x001F

CYAN = 0x07FF
YELLOW = 0xFFE0
MAGENTA = 0xF81F
ORANGE = 0xFD20

# KeychainOS interface colours
DARK_BG = 0x0841
HEADER = 0x021F
CARD = 0x18E3
CARD_ALT = 0x2104
BORDER = 0x528A
MUTED = 0xA514

# App colours
FOLDER_YELLOW = 0xFFE0
GAME_PURPLE = 0x8010

# Snake colours
SNAKE_GREEN = 0x07E0
FOOD_RED = 0xF800

# Tic-Tac-Toe colours
TICTAC_BLUE = 0x04FF
TICTAC_RED = 0xF960
WIN_GREEN = 0x07E0

# Carousel interface colours
CAROUSEL_BACKGROUND = 0xBDF7
CAROUSEL_TEXT = BLACK
CAROUSEL_MUTED = 0x4208
CAROUSEL_DOT = 0x7BEF