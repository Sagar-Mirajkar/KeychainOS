"""Dynamic and backward-compatible UI for KeychainOS.

The UI adapts to arbitrary app names supplied by main.py or a registry.
Known apps receive dedicated icons. Unknown apps receive a generated
letter icon, so adding a new module does not require editing this file.

Compatibility API:
- draw_text
- centred_text
- draw_back_button
- draw_status_bar
- draw_carousel
- draw_placeholder
- draw_theme_settings
- get_theme / get_theme_name / get_theme_display_name
- set_theme / next_theme / previous_theme
"""

import framebuf

try:
    import theme_manager
except ImportError:
    theme_manager = None

WIDTH = 240
HEIGHT = 320

BLACK = 0x0000
WHITE = 0xFFFF
RED = 0xF800
GREEN = 0x07E0
BLUE = 0x001F
CYAN = 0x07FF
YELLOW = 0xFFE0
MAGENTA = 0xF81F
ORANGE = 0xFD20
DARK = 0x0841
MUTED = 0x8410


class _FallbackTheme:
    NAME = "fallback"
    DISPLAY_NAME = "Fallback"
    BACKGROUND = 0xBDF7
    STATUS_BACKGROUND = 0xBDF7
    STATUS_TEXT = BLACK
    TITLE_TEXT = BLACK
    PRIMARY_TEXT = BLACK
    SECONDARY_TEXT = 0x4208
    LABEL_TEXT = WHITE
    INSTRUCTION_TEXT = 0x4208
    TILE_TOP = 0x07FF
    TILE_BOTTOM = 0x001F
    TILE_BORDER = WHITE
    TILE_SHADOW = 0x8410
    TILE_GLOSS = WHITE
    PEEK_TILE = 0x7BEF
    DOT_ACTIVE = WHITE
    DOT_INACTIVE = 0x7BEF
    BATTERY_BORDER = BLACK
    BATTERY_FILL = GREEN
    TILE_SIZE = 132
    TILE_X = 54
    TILE_Y = 78
    PEEK_WIDTH = 22
    LABEL_Y = 228
    DOT_Y = 268
    INSTRUCTION_Y = 288
    ACTION_Y = 304
    SHOW_GLOSS = True
    SHOW_SHADOW = True
    PIXEL_STYLE = False
    COMPACT_LAYOUT = False
    ROUNDED_STEPS = 8

    @staticmethod
    def app_colours(name):
        palette = (
            (0xFFE0, 0xFD20),
            (0x07FF, 0x001F),
            (0xF81F, 0x8010),
            (0x07E0, 0x0320),
            (0xC618, 0x4208),
        )
        total = sum(ord(character) for character in str(name))
        return palette[total % len(palette)]


def _load_initial_theme():
    if theme_manager is None:
        return _FallbackTheme()

    try:
        return theme_manager.load_theme()
    except Exception:
        return _FallbackTheme()


_theme = _load_initial_theme()


def get_theme():
    return _theme


def get_theme_name():
    return getattr(_theme, "NAME", "fallback")


def get_theme_display_name():
    return getattr(_theme, "DISPLAY_NAME", get_theme_name())


def set_theme(theme_name, save=True):
    global _theme

    if theme_manager is None:
        _theme = _FallbackTheme()
        return _theme

    _theme = theme_manager.load_theme(theme_name)

    if save:
        theme_manager.save_theme(theme_name)

    return _theme


def next_theme(save=True):
    if theme_manager is None:
        return _theme
    return set_theme(theme_manager.next_theme(get_theme_name()), save)


def previous_theme(save=True):
    if theme_manager is None:
        return _theme
    return set_theme(theme_manager.previous_theme(get_theme_name()), save)


def theme_value(name, default):
    return getattr(_theme, name, default)


def app_colours(name):
    try:
        return _theme.app_colours(name)
    except Exception:
        return _FallbackTheme.app_colours(name)


def swap_byte_pairs(data):
    for index in range(0, len(data), 2):
        data[index], data[index + 1] = data[index + 1], data[index]


def draw_text(display, text, x, y, colour=WHITE, background=BLACK,
              width=None, height=16):
    text = str(text)

    if width is None:
        width = WIDTH - x

    x = max(0, int(x))
    y = max(0, int(y))

    if x >= WIDTH or y >= HEIGHT:
        return

    width = max(1, min(int(width), WIDTH - x))
    height = max(1, min(int(height), HEIGHT - y))

    buffer = bytearray(width * height * 2)
    framebuffer = framebuf.FrameBuffer(buffer, width, height, framebuf.RGB565)
    framebuffer.fill(background)
    framebuffer.text(text, 0, 4, colour)
    swap_byte_pairs(buffer)

    display.set_window(x, y, x + width - 1, y + height - 1)
    display.sd_cs.value(1)
    display.cs.value(0)
    display.dc.value(1)

    for start in range(0, len(buffer), 2048):
        display.spi.write(buffer[start:start + 2048])

    display.cs.value(1)


def centred_text(display, text, y, colour=WHITE, background=BLACK):
    text = str(text)

    if len(text) > 29:
        text = text[:26] + "..."

    width = max(8, len(text) * 8)
    x = max(0, (WIDTH - width) // 2)
    draw_text(display, text, x, y, colour, background, min(width, WIDTH))


def draw_back_button(display, background=None, foreground=None):
    if background is None:
        background = theme_value("STATUS_BACKGROUND", DARK)
    if foreground is None:
        foreground = theme_value("STATUS_TEXT", WHITE)

    display.fill_rect(2, 2, 66, 30, background)
    display.outline_rect(2, 2, 66, 30, foreground, 2)
    draw_text(display, "< BACK", 10, 9, foreground, background, 48)


def draw_status_bar(display, section, show_back=False):
    background = theme_value("STATUS_BACKGROUND", DARK)
    foreground = theme_value("STATUS_TEXT", WHITE)

    display.fill_rect(0, 0, WIDTH, 34, background)

    if show_back:
        draw_back_button(display, background, foreground)
        title_x = 76
        title_width = 118
    else:
        title_x = 8
        title_width = 160

    draw_text(display, str(section)[:14], title_x, 9,
              foreground, background, title_width)

    display.outline_rect(204, 10, 25, 10,
                         theme_value("BATTERY_BORDER", foreground), 1)
    display.fill_rect(229, 13, 3, 4,
                      theme_value("BATTERY_BORDER", foreground))
    display.fill_rect(207, 13, 16, 4,
                      theme_value("BATTERY_FILL", GREEN))


def draw_soft_tile(display, x, y, size, top_colour, bottom_colour):
    shadow = theme_value("TILE_SHADOW", BLACK)
    border = theme_value("TILE_BORDER", WHITE)

    if theme_value("PIXEL_STYLE", False):
        display.fill_rect(x, y, size, size, bottom_colour)
        display.outline_rect(x, y, size, size, border, 3)
        return

    if theme_value("SHOW_SHADOW", True):
        display.fill_rect(x + 4, y + 5, size, size, shadow)

    display.fill_rect(x + 7, y, size - 14, 4, top_colour)
    display.fill_rect(x + 3, y + 4, size - 6, 5, top_colour)
    display.fill_rect(x, y + 9, size, size - 18, top_colour)
    display.fill_rect(x + 1, y + size // 2,
                      size - 2, size // 2 - 9, bottom_colour)
    display.fill_rect(x + 3, y + size - 9,
                      size - 6, 5, bottom_colour)
    display.fill_rect(x + 7, y + size - 4,
                      size - 14, 4, bottom_colour)

    if theme_value("SHOW_GLOSS", True):
        gloss = theme_value("TILE_GLOSS", WHITE)
        display.fill_rect(x + 10, y + 10, size - 20, 3, gloss)

    display.outline_rect(x + 3, y + 4, size - 6, size - 8, border, 1)


def draw_generic_icon(display, name, x, y, background):
    """Generate an icon for any app name without editing ui.py."""

    text = str(name).strip()
    initial = text[0].upper() if text else "?"

    display.fill_rect(x + 8, y + 8, 56, 56, background)
    display.outline_rect(x + 8, y + 8, 56, 56, WHITE, 3)
    draw_text(display, initial, x + 32, y + 28, WHITE, background, 8)


def draw_folder_icon(display, x, y, background):
    display.fill_rect(x + 6, y + 20, 58, 38, YELLOW)
    display.fill_rect(x + 12, y + 11, 25, 12, YELLOW)
    display.fill_rect(x + 10, y + 29, 50, 3, ORANGE)


def draw_gamepad_icon(display, x, y, background):
    display.fill_rect(x + 8, y + 22, 56, 32, MAGENTA)
    display.fill_rect(x + 16, y + 16, 40, 44, MAGENTA)
    display.fill_rect(x + 18, y + 34, 18, 6, WHITE)
    display.fill_rect(x + 24, y + 28, 6, 18, WHITE)
    display.fill_rect(x + 48, y + 30, 7, 7, CYAN)


def draw_tools_icon(display, x, y, background):
    display.fill_rect(x + 6, y + 25, 60, 34, ORANGE)
    display.outline_rect(x + 6, y + 25, 60, 34, WHITE, 2)
    display.fill_rect(x + 22, y + 14, 28, 13, ORANGE)
    display.outline_rect(x + 22, y + 14, 28, 13, WHITE, 2)


def draw_calculator_icon(display, x, y, background):
    display.fill_rect(x + 13, y + 5, 46, 62, 0x4208)
    display.outline_rect(x + 13, y + 5, 46, 62, WHITE, 2)
    display.fill_rect(x + 19, y + 11, 34, 13, BLACK)

    for row in range(3):
        for column in range(3):
            display.fill_rect(x + 19 + column * 12,
                              y + 30 + row * 10, 7, 6,
                              CYAN if column == 2 else WHITE)


def draw_clock_icon(display, x, y, background):
    display.fill_rect(x + 11, y + 8, 50, 50, WHITE)
    display.outline_rect(x + 11, y + 8, 50, 50, CYAN, 4)
    display.fill_rect(x + 34, y + 17, 4, 18, BLACK)
    display.fill_rect(x + 36, y + 33, 14, 4, BLACK)


def draw_settings_icon(display, x, y, background):
    display.fill_rect(x + 27, y + 10, 18, 50, CYAN)
    display.fill_rect(x + 11, y + 26, 50, 18, CYAN)
    display.fill_rect(x + 19, y + 18, 34, 34, CYAN)
    display.fill_rect(x + 28, y + 27, 16, 16, background)


def draw_app_icon(display, name, x, y, size, background):
    icon_x = x + (size - 72) // 2
    icon_y = y + max(14, (size - 80) // 3)
    normalized = str(name).upper()

    if normalized == "FILES":
        draw_folder_icon(display, icon_x, icon_y, background)
    elif normalized == "GAMES":
        draw_gamepad_icon(display, icon_x, icon_y, background)
    elif normalized == "TOOLS":
        draw_tools_icon(display, icon_x, icon_y, background)
    elif normalized == "CALCULATOR":
        draw_calculator_icon(display, icon_x, icon_y, background)
    elif normalized in ("CLOCK", "STOPWATCH", "TIMER"):
        draw_clock_icon(display, icon_x, icon_y, background)
    elif normalized == "SETTINGS":
        draw_settings_icon(display, icon_x, icon_y, background)
    else:
        draw_generic_icon(display, normalized, icon_x, icon_y, background)


def draw_carousel(display, items, selected, section):
    """Render any sequence of labels; no hardcoded app list is required."""

    items = tuple(items)

    if not items:
        draw_placeholder(display, section, "No items installed")
        return

    selected = int(selected) % len(items)
    background = theme_value("BACKGROUND", DARK)
    tile_size = theme_value("TILE_SIZE", 132)
    tile_x = theme_value("TILE_X", 54)
    tile_y = theme_value("TILE_Y", 78)
    peek_width = theme_value("PEEK_WIDTH", 22)

    display.fill(background)
    draw_status_bar(display, section, section != "KeychainOS")

    previous_name = items[(selected - 1) % len(items)]
    current_name = items[selected]
    next_name = items[(selected + 1) % len(items)]

    previous_colours = app_colours(previous_name)
    current_colours = app_colours(current_name)
    next_colours = app_colours(next_name)

    peek_y = tile_y + 18
    display.fill_rect(-tile_size + peek_width, peek_y,
                      tile_size, max(20, tile_size - 36),
                      previous_colours[1])
    display.fill_rect(WIDTH - peek_width, peek_y,
                      tile_size, max(20, tile_size - 36),
                      next_colours[1])

    draw_soft_tile(display, tile_x, tile_y, tile_size,
                   current_colours[0], current_colours[1])
    draw_app_icon(display, current_name, tile_x, tile_y,
                  tile_size, current_colours[1])

    centred_text(display, current_name,
                 theme_value("LABEL_Y", 228),
                 theme_value("LABEL_TEXT", WHITE), background)

    dot_width = 12
    total_width = min(WIDTH - 16, len(items) * dot_width)
    visible_count = max(1, total_width // dot_width)
    start_index = max(0, min(selected - visible_count // 2,
                             len(items) - visible_count))
    dot_x = (WIDTH - visible_count * dot_width) // 2

    for local_index in range(visible_count):
        item_index = start_index + local_index
        colour = (theme_value("DOT_ACTIVE", WHITE)
                  if item_index == selected
                  else theme_value("DOT_INACTIVE", MUTED))
        display.fill_rect(dot_x + local_index * dot_width,
                          theme_value("DOT_Y", 268), 7, 5, colour)

    centred_text(display, "Swipe to browse",
                 theme_value("INSTRUCTION_Y", 288),
                 theme_value("INSTRUCTION_TEXT", MUTED), background)
    centred_text(display, "Tap to open",
                 theme_value("ACTION_Y", 304),
                 theme_value("PRIMARY_TEXT", BLACK), background)


def draw_placeholder(display, title, message):
    background = theme_value("BACKGROUND", DARK)
    display.fill(background)
    draw_status_bar(display, title, True)
    centred_text(display, title, 88,
                 theme_value("TITLE_TEXT", WHITE), background)
    centred_text(display, message, 145,
                 theme_value("PRIMARY_TEXT", WHITE), background)
    centred_text(display, "Tap Back or swipe right", 282,
                 theme_value("SECONDARY_TEXT", MUTED), background)


def draw_theme_settings(display, selected_index):
    if theme_manager is None:
        draw_placeholder(display, "THEMES", "Theme manager unavailable")
        return

    names = theme_manager.THEMES

    if not names:
        draw_placeholder(display, "THEMES", "No themes installed")
        return

    selected_index %= len(names)
    selected_name = names[selected_index]

    try:
        preview = theme_manager.load_theme(selected_name)
    except Exception:
        preview = _FallbackTheme()

    background = getattr(preview, "BACKGROUND", DARK)
    display.fill(background)
    draw_status_bar(display, "Themes", True)
    centred_text(display, getattr(preview, "DISPLAY_NAME", selected_name),
                 75, getattr(preview, "TITLE_TEXT", WHITE), background)

    colours = preview.app_colours("SETTINGS")
    size = getattr(preview, "TILE_SIZE", 132)
    x = (WIDTH - size) // 2
    draw_soft_tile(display, x, 105, size, colours[0], colours[1])
    draw_settings_icon(display, x + (size - 72) // 2,
                       126, colours[1])

    centred_text(display, "Swipe to preview", 278,
                 getattr(preview, "INSTRUCTION_TEXT", MUTED), background)
    centred_text(display, "Tap to apply", 298,
                 getattr(preview, "PRIMARY_TEXT", WHITE), background)
