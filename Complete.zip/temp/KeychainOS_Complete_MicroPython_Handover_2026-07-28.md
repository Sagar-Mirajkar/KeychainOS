# KeychainOS Complete MicroPython Development Handover

**Project owner:** Sagar Mirajkar  
**Last updated:** 28 July 2026  
**Current phase:** MicroPython rapid prototyping and hardware reality testing  
**Target hardware:** Waveshare ESP32-S3 LCD Driver Board with 2-inch 240 x 320 capacitive-touch LCD

---

## 1. Purpose of This Handover

This document captures the complete KeychainOS development context from the first successful MicroPython hardware tests through the latest dynamic launcher and UI experiments.

Use this file when continuing the project:

- In another Microsoft Copilot conversation
- On another computer or phone
- During later migration to Arduino-ESP32 C++ or Arduino as an ESP-IDF component
- When reviewing which modules are proven, generated, experimental, disabled, or still missing hardware

The project has intentionally used MicroPython for rapid prototyping. Many modules were generated to explore the full product vision, but only a smaller group has been proven on physical hardware. Treat generated modules as prototypes requiring individual testing.

---

## 2. Product Vision

KeychainOS is intended to become a compact, touch-first pocket computer with the following identities:

- Portable utility computer
- Personal organizer
- Electronics reference and diagnostic tool
- Remote-control device
- File and SD media viewer
- Small game console
- Wi-Fi, BLE, NFC, USB, and future infrared utility
- Developer and hardware test platform

KeychainOS is not currently intended to include a camera.

The long-term user experience should resemble a small mobile device with installable applications, optional packages, firmware updates, network provisioning, application categories, permissions, dependencies, an App Centre, and clean uninstall support.

Potential future package types:

```text
.kapp     KeychainOS application package
.ktheme   KeychainOS theme package
.kos      KeychainOS system or firmware package
```

This package system is planned for later, likely during or after migration away from MicroPython.

---

## 3. Confirmed Hardware

### Board

```text
Waveshare ESP32-S3 LCD Driver Board
ESP32-S3-WROOM-1-N8R8
8 MB flash
8 MB Octal PSRAM
```

### Display

```text
Controller: ST7789T3 / ST7789-compatible
Resolution: 240 x 320
Orientation: Portrait
Colour mode: RGB565
Inversion: Enabled
SPI bus: 2
Current tested SPI speed: 20 MHz
```

### Touch

```text
Controller: CST816D
I2C address: 0x15
Additional detected I2C address: 0x20
```

### Display and shared SPI pins

```python
LCD_SCLK = 1
LCD_MOSI = 2
LCD_MISO = 42
LCD_CS = 39
LCD_DC = 41
LCD_RST = 40
LCD_BL = 6
SD_CS = 38
```

The display and SD card share SCLK, MOSI, and MISO. They use separate chip-select pins.

### Touch pins

```python
TP_SDA = 15
TP_SCL = 7
TP_RST = 16
TP_INT = 17
TP_ADDRESS = 0x15
```

### Confirmed touch orientation

```python
TOUCH_SWAP_XY = False
TOUCH_INVERT_X = False
TOUCH_INVERT_Y = False
```

### Backlight

The LCD backlight is controlled by:

```python
from machine import Pin
Pin(6, Pin.OUT).value(1)
```

The backlight turning on while the screen remains blank usually means `main.py` started but crashed before drawing the interface.

---

## 4. MicroPython Environment

Confirmed firmware:

```text
MicroPython v1.28.0
Release date: 6 April 2026
Target: Generic ESP32S3 module with ESP32S3
```

Confirmed capabilities:

- Display initialization
- Backlight control
- CST816D touch initialization
- Horizontal and vertical swipe detection
- I2C scanning
- Internal filesystem access
- Wi-Fi through an iPhone Personal Hotspot
- HTTPS downloads from GitHub Raw
- Python source validation using `compile()`
- OTA module installation and rollback

Recommended iPhone hotspot settings:

```text
Allow Others to Join: On
Maximize Compatibility: On
```

Wi-Fi credentials are stored locally in:

```text
/wifi_secrets.py
```

Recommended structure:

```python
WIFI_NAME = "HOTSPOT_NAME"
WIFI_PASSWORD = "HOTSPOT_PASSWORD"
```

Never commit this file or paste its contents into a chat.

---

## 5. Android Upload and REPL Issues

Development was often performed from an Android phone. Long code pasted directly into the MicroPython REPL repeatedly lost indentation or was converted into HTML entities such as:

```text
&lt;
&gt;
<br>
```

This caused many syntax errors.

### Recommended workflow

- Generate complete downloadable `.py` files
- Upload files directly to ESP storage
- Avoid pasting large indented scripts into the REPL
- Prefer short one-line REPL commands
- Save every replacement to the exact intended path
- Verify filenames after upload

### Validation command

```python
compile(open("/filename.py").read(), "/filename.py", "exec")
```

A successful result returns silently or shows:

```text
<code>
```

### Verify uploaded contents

```python
print(open("/filename.py").read(300))
```

### Stop and reset

```text
Ctrl+C   Stop the running program and return to REPL
Ctrl+D   Soft reboot MicroPython
```

---

## 6. Display Driver Findings

A custom pure-Python ST7789 driver was created. No external `st7789_mpy` package is required for the current prototype.

Working initialization sequence:

```python
command(0x01)           # Software reset
command(0x11)           # Exit sleep
command(0x3A, b"\x55")  # RGB565
command(0x36, b"\x00")  # Portrait
command(0x21)           # Inversion on
command(0x13)           # Normal mode
command(0x29)           # Display on
```

The custom driver provides:

```text
Display initialization
Window selection
Full-screen fill
Rectangle fill
Rectangle outline
Backlight on/off
Raw SPI writes
```

### Current display limitation

The UI performs many sequential rectangle and text writes. Full-screen redraws are visibly reconstructed and cause noticeable lag.

The current carousel often performs:

```text
Clear full screen
Draw status bar
Draw side previews
Draw central tile
Draw icon
Draw label
Draw page indicators
Draw instructions
```

This is a major reality-check finding.

### Planned performance experiments

Generated modules include:

```text
display_benchmark.py
dirty_rect_test.py
framebuffer_test.py
double_buffer_test.py
spi_speed_test.py
transition_test.py
refresh_manager.py
performance_monitor.py
```

Potential strategies:

- Dirty rectangles
- Card-only redraw
- Full framebuffer in PSRAM
- Double buffering
- Reduced animation
- Instant replacement
- Higher ST7789 SPI speed
- DMA after migration to compiled firmware

A complete 240 x 320 RGB565 framebuffer requires:

```text
240 x 320 x 2 = 153,600 bytes
```

Two buffers require approximately:

```text
307,200 bytes
```

The board has PSRAM, so framebuffer testing is reasonable.

---

## 7. Touch Driver Findings

The CST816D touch controller was confirmed at:

```text
0x15
```

The driver supports:

- Raw coordinate reading
- Coordinate transformation
- Tap detection
- Left swipe
- Right swipe
- Up swipe
- Down swipe
- Blocking menu gestures
- Non-blocking game gestures
- Release detection

Confirmed chip ID output:

```text
Touch chip ID: 0xb6
```

Touch tests should continue for:

- False taps
- Diagonal swipes
- Edge accuracy
- Gesture latency
- Small targets
- Release delay
- Large touch target mode
- Left-handed controls

---

## 8. First Working Modular Structure

The initial successful flat structure was:

```text
/
├── main.py
├── st7789.py
├── touch.py
├── ui.py
├── snake.py
└── tic_tac_toe.py
```

This structure successfully loaded a swipeable Home menu and launched tested applications.

The flat structure was chosen because older `system/` and `games/` files had suffered indentation damage during Android paste operations.

---

## 9. Proven UI and Applications

### Proven or partly proven on hardware

```text
ST7789 display
CST816D touch
Swipe carousel
Home categories
Games submenu
Tools submenu
Visible error screens
Snake
Tic-Tac-Toe
Calculator
Clock
Themes
Wi-Fi hotspot access
GitHub HTTPS download
OTA rollback
```

### Snake requirements

Snake uses Nokia-style wraparound:

```python
new_head = (
    (current_head[0] + direction[0]) % columns,
    (current_head[1] + direction[1]) % rows
)
```

Wall contact should not cause Game Over. Self-collision should cause Game Over.

### Tic-Tac-Toe

The game supports:

- Local two-player play
- Touch-based 3 x 3 board
- X and O turns
- Horizontal wins
- Vertical wins
- Diagonal wins
- Draw detection
- Winning-cell highlighting

---

## 10. Theme System

A theme manager and six themes were created:

```text
theme_manager.py
theme_minimal_light.py
theme_dark_modern.py
theme_pastel_rounded.py
theme_glassy_blur.py
theme_retro_pixel.py
theme_compact_clean.py
```

Theme selection is saved in:

```text
/theme.cfg
```

Created themes:

```text
Minimal Light
Dark Modern
Pastel Rounded
Glassy Blur
Retro Pixel
Compact Clean
```

### Theme reality check

The themes mainly change:

- Colours
- Tile dimensions
- Borders
- Gloss
- Shadows
- Text contrast
- Spacing
- Page indicators

The generated visual concept showed more structurally different layouts than the implementation. Future themes should eventually provide separate layout renderers rather than only colour and spacing values.

---

## 11. Dynamic UI

The latest generated UI file is:

```text
ui_dynamic_compatible.py
```

It should be uploaded and renamed to:

```text
/ui.py
```

The dynamic UI provides:

```python
draw_text()
centred_text()
draw_back_button()
draw_status_bar()
draw_carousel()
draw_placeholder()
draw_theme_settings()
get_theme()
get_theme_name()
get_theme_display_name()
set_theme()
next_theme()
previous_theme()
```

Dynamic behavior:

- Accepts arbitrary menu lengths
- Handles empty menus
- Handles long menus with moving page indicators
- Handles arbitrary app names
- Generates a letter icon for unknown apps
- Uses dedicated icons for selected known apps
- Falls back to an internal theme if theme loading fails
- Safely truncates long labels

This means future app names can be added through `main.py` or registries without editing `ui.py` for every new app.

### Current dynamic UI file size

```text
14,225 bytes
```

---

## 12. Back Button Design

A clearly visible top-left Back button was added for submenu-style screens:

```text
< BACK
```

Recommended touch area:

```text
x: 0 to 69
y: 0 to 41
```

Submenus should also support a swipe-right or swipe-down escape where appropriate.

A physical Back/Home button is strongly recommended for future hardware because it would provide:

- Reliable escape from frozen applications
- Wake input
- Safe Mode trigger
- Game control
- Recovery input

---

## 13. Tools Generated

Generated Tools include:

```text
calculator.py
clock.py
stopwatch.py
timer.py
alarm.py
calendar_tool.py
pomodoro.py
flashlight.py
counter.py
converter.py
dice.py
random_number.py
password_generator.py
drawing_pad.py
metronome.py
morse_code.py
number_converter.py
ohms_law.py
resistor_calculator.py
gpio_reference.py
i2c_scanner.py
wifi_scanner.py
wifi_info.py
system_monitor.py
```

Calculator and Clock were integrated and tested earlier. Most additional tools remain generated prototypes requiring individual testing.

---

## 14. Games Generated

Existing and additional games include:

```text
snake.py
tic_tac_toe.py
pong.py
breakout.py
game_2048.py
minesweeper.py
memory_match.py
lights_out.py
connect_four.py
simon_says.py
reaction_test.py
```

Many of these are early prototypes and have not been validated on the device.

---

## 15. Personal Organization Modules

Generated modules include:

```text
keyboard.py
notes.py
checklist.py
tasks.py
reminders.py
habit_tracker.py
calendar_events.py
alarm_manager.py
```

Planned capabilities:

- On-screen keyboard
- Plain-text notes
- Persistent checklist
- Tasks
- Reminders
- Habit completion records
- Calendar events
- Persistent alarms

The on-screen keyboard is an early prototype and requires usability testing on the 240 x 320 display.

---

## 16. File and Storage Modules

Generated modules include:

```text
file_manager.py
text_viewer.py
storage_manager.py
recent_files.py
favourites.py
sd_health.py
sd_benchmark.py
media_index.py
media_importer.py
thumbnail_cache.py
```

Planned file capabilities:

- Browse internal flash
- Browse SD card
- Text viewing
- Protected system files
- Storage usage
- Temporary-file cleanup
- Recent files
- Favourites
- Media indexing
- SD health information
- SD read/write benchmarking

---

## 17. SD Card and Media Status

An SD Media Pack was created containing:

```text
sdcard.py
sd_manager.py
media_browser.py
bmp_viewer.py
rgb565_viewer.py
sd_text_viewer.py
frame_animation.py
media_info.py
```

### Intended supported media

```text
TXT
Markdown
JSON
CSV
Python source
Logs
Uncompressed 24-bit BMP
Raw RGB565
Folders of raw RGB565 animation frames
```

### Image policy

Default image behavior must be:

```text
Fit / Contain
Preserve aspect ratio
Show the complete image
Never crop by default
Centre the image
Use letterboxing where necessary
Preserve the original file
```

### Current SD reality check

Opening Media produced a visible error screen:

```text
MEDIA ERROR
OSError
SD init timeout
Tap to continue
```

A later direct command:

```python
import sd_manager
sd_manager.mount()
```

returned no visible error, so the SD issue is not fully understood. It may involve:

- Card seating
- FAT32 compatibility
- Generic SD driver compatibility
- Shared SPI state
- Chip-select handling
- Initialization speed
- Application timing

### Temporary decision

SD and Media functionality remain installed but are removed from the active test launcher for now.

Do not delete these files. Leave SD integration for a focused later test.

---

## 18. Remote Control Platform

Remote Control is a primary intended KeychainOS feature.

Generated remote modules include:

```text
remote_home.py
remote_registry.py
computer_remote.py
presentation_remote.py
media_remote.py
http_remote.py
mqtt_remote.py
ble_remote.py
usb_remote.py
ir_remote.py
ir_service.py
macro_manager.py
macro_runner.py
```

Intended capabilities:

- Computer media control
- Presentation navigation
- Media playback control
- HTTP webhooks
- MQTT commands
- Custom BLE GATT remote
- USB HID remote later
- Infrared appliance control after hardware is added
- Multi-step macros

Some features require:

- A companion computer application
- `umqtt.simple`
- Future USB HID firmware support
- Infrared LED and receiver hardware

---

## 19. Connectivity

### Wi-Fi

Proven:

- iPhone hotspot connection
- HTTPS access
- GitHub Raw download

Generated Wi-Fi features:

```text
Wi-Fi scanning
Wi-Fi information
Connection status
RSSI
IP address
Gateway
DNS
Connect/disconnect architecture
NTP architecture
HTTP requests
MQTT foundation
```

Future Wi-Fi settings should provide:

- Wi-Fi On/Off
- Scan networks
- Saved profiles
- Connect
- Disconnect
- Forget network
- Auto-connect
- Hotspot setup
- Temporary KeychainOS setup access point
- Local phone-based setup portal

### BLE

Generated modules:

```text
ble_scanner.py
bluetooth_manager.py
ble_remote.py
```

Current BLE foundation:

- Activate BLE
- Scan advertisements
- Record addresses
- Record RSSI
- Future GATT client architecture

The ESP32-S3 does not provide normal Bluetooth Classic A2DP speaker and earphone support. Conventional Bluetooth audio is not a simple future module.

### USB

Future intended USB modes:

```text
USB keyboard
USB mouse
USB media controller
USB presentation remote
USB gamepad
USB macro pad
```

---

## 20. NFC

Generated NFC modules:

```text
nfc_service.py
nfc_app.py
nfc_ndef.py
nfc_registry.py
```

Intended NFC capabilities:

- Scan NFC tags
- Read tag IDs
- Read NDEF records
- Write text records
- Write URL records
- Display tag information

Actual NFC operation requires external hardware, likely a PN532-class reader. Pins are intentionally not hardcoded until the NFC module and bus are selected.

---

## 21. Optional Hardware Service Placeholders

Generated placeholder modules:

```text
battery_service.py
audio_service.py
haptic_service.py
button_service.py
ir_service.py
nfc_service.py
hardware_readiness.py
```

Until hardware is installed, these modules report that hardware is unavailable.

Recommended optional hardware:

- Physical Back/Home button
- Piezo buzzer or I2S speaker
- Vibration motor with transistor or MOSFET driver
- Li-Po battery and charger
- Fuel-gauge IC
- Infrared LED and receiver
- PN532-class NFC reader
- Expansion connector

---

## 22. OTA and Update Work

The OTA workflow is one of the most successfully tested capabilities.

Repository:

```text
https://github.com/Sagar-Mirajkar/KeychainOS
```

Confirmed raw-file downloads were performed from GitHub.

### Proven OTA sequence

```text
Download filename.new
Validate HTTP response
Reject empty file
Compile Python syntax
Rename existing file to filename.bak
Install filename.new as filename
Import and run new module
Keep update when validation succeeds
Restore filename.bak when validation fails
Delete backup after success
```

### Proven rollback test

A deliberately failing OTA module returned `False`. The updater restored the previous good version.

Confirmed working areas:

```text
Wi-Fi connection
HTTPS GitHub download
Temporary .new file
Syntax validation
.bak backup
Updated-module installation
Runtime validation
Automatic rollback
Previous-module restoration
Successful-update cleanup
```

### OTA test module

Good version:

```text
/update_test.py
VERSION = "0.2"
```

### Generated OTA modules

```text
ota_test.py
ota_module_test.py
ota_safe_update.py
updater.py
recovery_guard.py
install_keychainos.py
```

### Boot recovery status

A backup of the original boot file was created:

```text
/boot_original.py
```

A recovery helper was created:

```text
/ota_boot_guard.py
```

However, boot recovery was not fully proven for production `main.py` updates. Do not assume `main.py` OTA recovery is active without inspecting the current `/boot.py`.

---

## 23. Activity Logging

Generated files:

```text
activity_log.py
activity_viewer.py
```

The full logger was designed to record:

- Boot
- Hardware initialization
- System ready
- App launch
- App exit
- App failure
- Import failure
- Main-loop failure
- REPL interrupt
- Navigation
- Tool results
- File installed
- File removed
- File changed
- Free memory
- Uptime

Log paths:

```text
/keychainos_logs/events.jsonl
/keychainos_logs/events.previous.jsonl
/keychainos_logs/filesystem_snapshot.json
```

### Logging reality check

After uploading a large number of files, boot-time filesystem comparison and per-file event writes likely contributed to lag.

### Temporary decision

The logging files remain installed, but the active lightweight launcher uses a no-op logger and does not perform filesystem auditing.

Activity logging should be reintroduced later with:

- Batched filesystem changes
- Deferred scanning after the Home screen appears
- One write for many changes
- Ignored cache and temporary files
- Optional logging levels

---

## 24. Main Launcher History

Several launcher variants were created:

```text
main.py
main_snake_test.py
main_ipod_nano_ui.py
main_with_tictactoe.py
main_theme_settings.py
main_with_tools.py
main_back_buttons.py
main_lite_no_logs_no_sd.py
main_diagnostic_no_logs_no_sd.py
```

### Full launcher

A complete launcher was generated with categories:

```text
Files
Media
Apps
Games
Tools
Remote
Connections
Developer
Settings
About
```

It used lazy app imports, app failure recovery, and activity logging.

### Problems found

- Menus loaded slowly
- Full-screen redraw remained visibly lagged
- Media failed with SD initialization timeout
- Many applications showed red error screens
- The large full launcher made it difficult to isolate shared interface problems

### Current recommended launcher for diagnosis

Use:

```text
main_diagnostic_no_logs_no_sd.py
```

Rename it to:

```text
/main.py
```

This version:

- Disables activity-log writes
- Disables filesystem snapshot audit
- Removes Media from Home
- Removes Activity Log from Developer
- Prints full application tracebacks to the terminal
- Keeps app error recovery

Current generated size:

```text
10,921 bytes
```

### Diagnostic output marker

The correct file should contain:

```text
APP FAILURE
sys.print_exception
```

Verify with:

```python
source = open("/main.py").read()
print("APP FAILURE" in source)
print("sys.print_exception" in source)
print(len(source))
```

Expected approximately:

```text
True
True
10921
```

---

## 25. Current Critical Problem

After all generated modules were uploaded, the Home menu became less responsive and many apps showed red error screens.

The red screen is useful because it confirms:

- The launcher caught the error
- The device did not permanently freeze
- The failure was isolated to the app launch
- The user can return to the launcher

However, the short red screen is not enough to diagnose the cause.

### Required next diagnostic

Use the diagnostic `main.py`, launch one known app such as Calculator, and copy the complete terminal output beginning with:

```text
APP FAILURE
App: CALCULATOR
Module: calculator
Error: ...
Traceback ...
```

One full traceback may reveal a shared compatibility issue affecting many apps.

Likely causes:

- Active `ui.py` is not the latest dynamic version
- App `run()` signatures differ
- Apps expect missing UI methods
- Shared dependencies are missing
- Files were uploaded under incorrect names
- Older module versions remain active
- Applications use unsupported display methods
- Some generated modules are architectural shells, not directly launchable apps

---

## 26. Generated Module Packs

The following archives were produced during development:

```text
KeychainOS_Tools_Settings_Modules.zip
KeychainOS_Complete_Module_Library.zip
KeychainOS_Everything_Except_OneDrive.zip
KeychainOS_SD_Media_Pack.zip
KeychainOS_All_Pending_PY_With_NFC.zip
```

These packs contain many overlapping files and versions. Uploading every file from every pack can leave obsolete or conflicting versions in the root filesystem.

Important:

- Do not assume every generated module is production-ready
- Do not import every module at boot
- Load applications only when selected
- Keep one authoritative version of each filename
- Use exact root-level filenames
- Avoid uploading alternate launcher files as `/main.py` accidentally

---

## 27. Generated System Services

Generated architecture modules include:

```text
config_manager.py
app_registry.py
home_registry.py
games_registry.py
tools_registry.py
settings_registry.py
navigation_manager.py
lazy_loader.py
input_manager.py
power_manager.py
time_service.py
timezone_manager.py
wifi_manager.py
storage_manager.py
notification_manager.py
performance_monitor.py
refresh_manager.py
diagnostics.py
boot_log.py
alarm_manager.py
safe_mode.py
recovery_guard.py
error_screen.py
status_bar.py
```

Many are foundations or shells rather than fully integrated production services.

---

## 28. Planned Mobile-Style Platform

After feature testing, KeychainOS may evolve into a lightweight package-driven mobile-style system.

Recommended filesystem separation:

```text
/
├── boot.py
├── main.py
├── system/
├── apps/
├── data/
├── packages/
├── cache/
└── logs/
```

### App package manifest concept

```json
{
  "package_format": 1,
  "id": "com.keychainos.snake",
  "name": "Snake",
  "version": "1.2.0",
  "type": "app",
  "entry": "app.py",
  "minimum_os": "0.5.0",
  "permissions": ["display", "touch"],
  "dependencies": []
}
```

### Planned package lifecycle

```text
Download
Validate manifest
Check compatibility
Check permissions
Check dependencies
Verify checksum
Install into temporary location
Compile Python files
Back up existing app
Activate new app
Run validation
Register app
Roll back on failure
```

### Planned App Centre

```text
Featured
Categories
Installed
Updates
Firmware
Themes
Downloads
Local packages
```

This architecture should be developed after the current MicroPython prototype clarifies which features are worth retaining.

---

## 29. Future Migration Direction

Current intent:

```text
Prototype features in MicroPython
Test real usability and hardware limits
Refine workflows
Move final architecture to compiled C++
```

Likely migration path:

```text
MicroPython prototype
→ Arduino-ESP32 C++ proof of concept
→ Multi-file Arduino project
→ Optionally Arduino as ESP-IDF component
```

UI refinement can happen later. Current priority is reality testing:

- App usefulness
- Touch usability
- Lag
- Display redraw
- Memory use
- SD reliability
- Connectivity
- Optional hardware value

---

## 30. Recommended Immediate Next Steps

Do not generate additional features until the shared app-launch problem is understood.

### Step 1: Install the latest compatible UI

Upload:

```text
ui_dynamic_compatible.py
```

Rename to:

```text
/ui.py
```

### Step 2: Install the diagnostic launcher

Upload:

```text
main_diagnostic_no_logs_no_sd.py
```

Rename to:

```text
/main.py
```

### Step 3: Verify active versions

```python
source = open("/main.py").read()
print("APP FAILURE" in source)
print("sys.print_exception" in source)

ui_source = open("/ui.py").read()
print("def centred_text" in ui_source)
print("def draw_carousel" in ui_source)
print("def draw_placeholder" in ui_source)
print("def draw_back_button" in ui_source)
```

All UI checks should return:

```text
True
```

### Step 4: Reboot

```text
Ctrl+D
```

### Step 5: Test only Calculator

Open:

```text
Tools → Calculator
```

### Step 6: Capture terminal traceback

Copy the complete output beginning with:

```text
APP FAILURE
```

Do not rely only on the red screen.

### Step 7: Fix the shared compatibility issue

After Calculator launches successfully, test:

```text
Clock
Stopwatch
Snake
Tic-Tac-Toe
```

Then test one app from each category.

### Step 8: Performance work

Once app launches work:

1. Measure full-screen draw time
2. Test dirty rectangles
3. Test 40 MHz SPI
4. Test framebuffer allocation
5. Test double buffering
6. Reduce carousel redraws

### Step 9: Revisit SD separately

Use a known-good FAT32 card and a board-specific SD test before re-enabling Media.

### Step 10: Reintroduce logging later

Use batched, deferred logging rather than per-file startup writes.

---

## 31. Safety and Stability Rules

- Do not update `boot.py` and `main.py` together
- Keep `boot_original.py`
- Keep backups before boot-critical changes
- Download OTA files as `.new`
- Validate Python syntax before installation
- Preserve `.bak` until runtime validation succeeds
- Do not commit `wifi_secrets.py`
- Never log Wi-Fi passwords or authentication tokens
- Do not automatically remove user data when uninstalling apps
- Do not delete original media after conversion
- Protect display, touch, SD, USB, and boot GPIO pins from generic GPIO tools
- Treat generated modules as prototypes until tested
- Keep SD and display chip-select handling mutually exclusive
- Avoid importing every app at startup
- Use lazy loading and garbage collection

---

## 32. Prompt for a New Copilot Conversation

Copy this prompt into a new Microsoft Copilot chat and attach this Markdown file:

```text
I am continuing the KeychainOS project on a Waveshare ESP32-S3 LCD
Driver Board with a 240 x 320 ST7789 display and CST816D touch.

Read the attached KeychainOS Complete MicroPython Development Handover
fully before suggesting changes.

Current state:
- MicroPython v1.28.0 is installed.
- Display, touch, Wi-Fi, GitHub download, OTA module rollback, themes,
  Snake, Tic-Tac-Toe, Calculator, and Clock have worked at earlier stages.
- A very large set of prototype modules has now been uploaded.
- The full launcher became laggy.
- SD Media produced an SD init timeout, so SD and Media are temporarily
  disabled in the active launcher.
- Persistent activity logging is temporarily disabled because startup
  filesystem auditing may have added lag.
- Many applications currently show the red app error screen.
- The next task is not to add more features. The next task is to install
  ui_dynamic_compatible.py as /ui.py, install
  main_diagnostic_no_logs_no_sd.py as /main.py, launch Calculator, and
  capture the complete terminal traceback beginning with APP FAILURE.
- Android copying can damage indentation, so provide downloadable files
  instead of long pasted scripts.

Continue from the section called Recommended Immediate Next Steps.
Work one diagnostic step at a time and do not re-enable SD or logging yet.
```

---

## 33. Final Current-State Summary

### Working foundation

```text
ESP32-S3 hardware
ST7789 display
CST816D touch
Swipe gestures
Wi-Fi hotspot
GitHub HTTPS
Basic modular launcher
Themes
Snake
Tic-Tac-Toe
Calculator
Clock
OTA module rollback
Error-screen recovery
```

### Installed but temporarily inactive

```text
SD media
Persistent activity logging
Filesystem installation audit
```

### Generated but mostly untested

```text
Expanded games
Expanded tools
Organizer apps
Remote controls
BLE utilities
NFC shell
Developer tools
Diagnostics
Display performance experiments
Optional hardware services
Mobile package platform foundations
```

### Current blocker

```text
Most applications show red error screens after the large module upload.
A complete diagnostic terminal traceback is still required.
```

### Immediate goal

```text
Stabilize one app launch
→ Fix shared interface problems
→ Test apps category by category
→ Measure display performance
→ Revisit SD
→ Reintroduce efficient logging
→ Refine architecture
→ Migrate later
```
