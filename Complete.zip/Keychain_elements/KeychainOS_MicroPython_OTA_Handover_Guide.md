# KeychainOS MicroPython Development and OTA Handover Guide

**Prepared:** 25 July 2026  
**Purpose:** Transfer the current project status, tested hardware configuration, working MicroPython workflow, and OTA progress to another Microsoft Copilot conversation or another computer.

---

## 1. Project Summary

KeychainOS is a pocket utility-computer project based on:

- Waveshare ESP32-S3 LCD Driver Board
- ESP32-S3-WROOM-1-N8R8
- 8 MB flash and 8 MB Octal PSRAM
- Waveshare 2-inch 240 x 320 capacitive-touch LCD
- ST7789T3 display controller
- CST816D touch controller
- Display-side microSD card

The current development environment is MicroPython rather than Arduino.

The current objective is to build a touch-operated interface containing applications and games. Snake and two-player Tic-Tac-Toe were prototyped. The immediate focus became a safe Python-file OTA update system.

---

## 2. Confirmed Hardware Pin Mapping

### LCD and shared SPI bus

```python
LCD_SCLK = 1
LCD_MOSI = 2
LCD_MISO = 42
LCD_CS = 39
LCD_DC = 41
LCD_RST = 40
LCD_BL = 6
```

### SD card

```python
SD_CS = 38
```

The LCD and SD card share SCLK, MOSI, and MISO. They use different chip-select pins.

### CST816D touch

```python
TP_SDA = 15
TP_SCL = 7
TP_RST = 16
TP_INT = 17
TP_ADDRESS = 0x15
```

### Display settings

```text
Resolution: 240 x 320
Orientation: Portrait
SPI bus: 2
SPI speed: 20 MHz during current testing
Colour mode: RGB565
Display inversion: On
```

---

## 3. MicroPython Environment

Confirmed firmware:

```text
MicroPython v1.28.0
Release date: 6 April 2026
Target: Generic ESP32S3 module with ESP32S3
```

The board can connect to an iPhone Personal Hotspot. The iPhone hotspot should use:

```text
Allow Others to Join: On
Maximize Compatibility: On
```

Keep Wi-Fi credentials only in an ESP-local file named:

```text
/wifi_secrets.py
```

Example structure:

```python
WIFI_NAME = "YOUR_HOTSPOT_NAME"
WIFI_PASSWORD = "YOUR_HOTSPOT_PASSWORD"
```

Do not store actual credentials in GitHub or in future Copilot chats. The hotspot password used during testing was exposed in the original conversation and should be changed.

---

## 4. Important Android Development Limitation

Development was being performed from an Android phone using Micro REPL or a similar editor.

A repeated issue occurred: code pasted into the Android editor sometimes lost indentation. This caused errors such as:

```text
SyntaxError: invalid syntax
```

Examples included function docstrings and bodies appearing at column zero instead of being indented.

### Recommended Android workflow

1. Prefer uploading complete `.py` files instead of pasting long code.
2. Keep test files short.
3. Validate every uploaded file before resetting:

```python
compile(open("/filename.py").read(), "/filename.py", "exec")
```

A successful compile returns silently or displays a code object. A syntax error identifies the bad filename and line.

4. Inspect suspicious lines with:

```python
lines = open("/filename.py").read().splitlines()

for number in range(START, END):
    print(number + 1, repr(lines[number]))
```

5. Confirm that the file was saved to ESP device storage, not Android local storage:

```python
print(open("/filename.py").read(200))
```

6. Use `Ctrl+C` to stop a running script and return to the REPL.
7. Use `Ctrl+D` for a MicroPython soft reset.

---

## 5. Display Findings

The backlight can be enabled manually with:

```python
from machine import Pin
Pin(6, Pin.OUT).value(1)
```

This proved:

- GPIO6 is the correct backlight pin.
- The backlight circuit works.
- A black display with the backlight off often means the Python program crashed before display initialization.

The project does not require an external `st7789_mpy` package. A custom minimal `st7789.py` driver can send ST7789 commands directly over SPI.

Working initialization sequence:

```python
command(0x01)          # Software reset
command(0x11)          # Exit sleep
command(0x3A, b"\x55") # RGB565
command(0x36, b"\x00") # Portrait
command(0x21)          # Inversion on
command(0x13)          # Normal mode
command(0x29)          # Display on
```

A basic red/green/blue/white colour cycle previously worked using the raw SPI display code.

---

## 6. Touch Findings

The CST816D controller was detected on I2C address `0x15`.

A scan also displayed `0x20`, likely another onboard device or expander.

The following orientation settings worked during touch colour-swipe tests:

```python
TOUCH_SWAP_XY = False
TOUCH_INVERT_X = False
TOUCH_INVERT_Y = False
```

Horizontal swipes were successfully used to change solid display colours.

---

## 7. Snake Game Requirement

The desired Snake behavior is the classic monochrome Nokia-style wrapping model:

- Crossing the left edge returns from the right edge.
- Crossing the right edge returns from the left edge.
- Crossing the top edge returns from the bottom edge.
- Crossing the bottom edge returns from the top edge.
- Wall contact does not cause Game Over.
- Collision with the snake's own body causes Game Over.

The wraparound calculation is:

```python
new_head = (
    (current_head[0] + direction[0]) % columns,
    (current_head[1] + direction[1]) % rows
)
```

The preferred future structure is modular:

```text
/
├── boot.py
├── main.py
├── st7789.py
├── touch.py
├── games/
│   ├── __init__.py
│   ├── snake.py
│   └── tic_tac_toe.py
└── apps/
```

However, because Android file management became confusing, it was agreed that simple two-file or flat-file tests should be used first. Old `system/` and `games/` folders can remain on the ESP if `main.py` does not import them.

---

## 8. GitHub OTA Repository Files

Repository:

```text
https://github.com/Sagar-Mirajkar/KeychainOS
```

The repository is public.

OTA folder:

```text
ota/
├── hello.txt
└── update_test.py
```

### `ota/hello.txt`

```text
Hello from KeychainOS OTA
Version 0.1
```

Permanent raw URL:

```text
https://raw.githubusercontent.com/Sagar-Mirajkar/KeychainOS/refs/heads/main/ota/hello.txt
```

### Good `ota/update_test.py`

```python
"""Harmless KeychainOS OTA Python module test."""

VERSION = "0.2"


def run():
    print("Downloaded Python module is working")
    print("OTA module version:", VERSION)
    return True
```

Permanent raw URL:

```text
https://raw.githubusercontent.com/Sagar-Mirajkar/KeychainOS/refs/heads/main/ota/update_test.py
```

A temporary failing version was used to test rollback:

```python
"""Deliberately failing OTA rollback test."""

VERSION = "0.3-ROLLBACK-TEST"


def run():
    print("Running deliberately failing update")
    print("OTA module version:", VERSION)
    return False
```

After rollback validation, the GitHub file was restored to the good version `0.2`.

---

## 9. OTA Tests Completed

### Test 1: Harmless text download

The ESP downloaded `hello.txt` over HTTPS from GitHub and saved it as:

```text
/ota_download.txt
```

Confirmed output:

```text
HTTP status: 200
Hello from KeychainOS OTA
Version 0.1
OTA DOWNLOAD TEST PASSED
```

This proved:

- Wi-Fi access through the iPhone hotspot
- DNS and HTTPS access to GitHub
- Raw GitHub file download
- Internal filesystem write
- File read-back

### Test 2: Download and import a Python module

The ESP downloaded:

```text
ota/update_test.py
```

as:

```text
/update_test.py.new
```

It then:

1. Validated Python syntax with `compile()`.
2. Installed the file as `/update_test.py`.
3. Imported the downloaded module.
4. Ran `update_test.run()`.
5. Received `True`.

Confirmed output ended with:

```text
Downloaded Python module is working
OTA module version: 0.2
Module returned: True
OTA PYTHON MODULE TEST PASSED
```

### Test 3: Safe update with backup and rollback

The updater sequence was proven:

```text
Download filename.new
→ Validate syntax
→ Rename current file to filename.bak
→ Install filename.new as filename
→ Import and run new module
→ Keep update if validation succeeds
→ Restore backup if validation fails
```

A deliberately failing `0.3-ROLLBACK-TEST` module returned `False`.

Confirmed output included:

```text
Backup created: /update_test.py.bak
Installed update as: /update_test.py
Module returned: False
UPDATE VALIDATION FAILED
ROLLBACK STARTED
Backup restored: /update_test.py
```

The restored module was verified as version `0.2`, and the good GitHub version was restored.

### Current OTA verdict

```text
Wi-Fi connection                         PASS
HTTPS GitHub download                    PASS
Temporary .new file                      PASS
Python syntax validation                 PASS
Existing-file .bak backup                PASS
Updated-module installation              PASS
Runtime validation                       PASS
Successful update cleanup                PASS
Automatic rollback                       PASS
Previous module restoration              PASS
```

---

## 10. Existing ESP Files During OTA Testing

The ESP root contained files similar to:

```text
/
├── boot.py
├── boot_original.py
├── main.py
├── st7789.py
├── ota_boot_guard.py
├── ota_download.txt
├── ota_module_test.py
├── ota_safe_update.py
├── ota_test.py
├── update_test.py
├── wifi_secrets.py
├── wifi_test.py
├── games/
└── system/
```

Old folders may contain syntax-corrupted experimental files. They should not affect a flat-file test unless `main.py` imports them.

---

## 11. Boot Recovery Work Started

A backup of the original boot file was successfully created:

```text
/boot_original.py
```

At that time:

```text
/boot.py size: 139 bytes
/boot_original.py size: 139 bytes
```

A recovery helper was created:

```text
/ota_boot_guard.py
```

The intended marker files are:

```text
/ota_main_pending
/ota_main_testing
```

Intended behavior:

1. A safe updater installs a new `main.py` and creates `/ota_main_pending`.
2. On the next hard or soft boot, `boot.py` calls `ota_boot_guard.on_boot()`.
3. The guard renames `/ota_main_pending` to `/ota_main_testing` and permits one test boot.
4. The new `main.py` must call `ota_boot_guard.confirm()` after successful startup.
5. Confirmation deletes `/ota_main_testing` and `/main.py.bak`.
6. If another boot occurs while `/ota_main_testing` still exists, the previous test boot was not confirmed. The guard restores `/main.py.bak`.

### Important current status

The recovery-aware replacement `boot.py` was proposed, but the save was not proven. The observed file sizes remained:

```text
boot.py: 139 bytes
boot_original.py: 139 bytes
```

Therefore, assume the original `boot.py` is still active unless the file contents are inspected.

Before proceeding, run:

```python
print(open("/boot.py").read())
```

Do not assume `main.py` recovery is active until the new `boot.py` is visibly present and successfully tested.

---

## 12. Recovery-Aware `boot.py` Intended Content

Once ready to continue, `/boot.py` should contain:

```python
"""KeychainOS boot recovery entry point."""

print("KeychainOS boot guard starting")

try:
    import ota_boot_guard
    ota_boot_guard.on_boot()
except Exception as error:
    print("BOOT GUARD ERROR:")
    print(repr(error))

print("KeychainOS boot guard finished")
```

Do not modify `boot.py` from an Android editor unless the save can be verified.

Validate before resetting:

```python
compile(open("/boot.py").read(), "/boot.py", "exec")
```

Inspect contents:

```python
print(open("/boot.py").read())
```

Confirm that `/boot_original.py` is still present.

---

## 13. Recommended Next Steps

Proceed one step at a time:

### Step A: Inspect current boot state

```python
print(open("/boot.py").read())
print(open("/boot_original.py").read())
```

### Step B: Verify current main state

```python
compile(open("/main.py").read(), "/main.py", "exec")
print(open("/main.py").read(300))
```

### Step C: Avoid updating `main.py` immediately

First use the safe updater on another noncritical module such as:

```text
/st7789.py
```

but only after a known-good local copy exists and a validation function is defined.

### Step D: Complete boot recovery

Only after `/boot.py` is confirmed to call the guard should `main.py` OTA be tested.

### Step E: Test a harmless `main.py`

Use a test `main.py` that:

1. Prints a clear version.
2. Turns on GPIO6 backlight immediately.
3. Does not initialize all KeychainOS features.
4. Calls `ota_boot_guard.confirm()` only after successfully reaching the end of startup.

### Step F: Deliberately test failed-main rollback

Use a `main.py` that passes syntax but intentionally raises an exception before confirmation. Reboot a second time and verify that `main.py.bak` is restored.

Do not apply `main.py` OTA to the full interface until the failed-boot rollback test passes.

---

## 14. Prompt for the Next Copilot Conversation

Copy this prompt into the next Microsoft Copilot conversation and attach this guide:

```text
I am continuing my KeychainOS MicroPython project on a Waveshare
ESP32-S3 LCD Driver Board with a 240 x 320 ST7789T3 display and CST816D
touch controller.

Read the attached KeychainOS MicroPython Development and OTA Handover
Guide completely before suggesting changes.

Important current facts:
- MicroPython v1.28.0 is installed on a Generic ESP32S3 target.
- Display and touch pins are documented in the guide.
- Wi-Fi through an iPhone hotspot works.
- GitHub raw HTTPS file download works.
- Python-module OTA with .new, .bak, syntax validation, runtime
  validation, and automatic rollback has passed.
- update_test.py was restored to the good version 0.2.
- main.py OTA recovery is not yet fully activated.
- boot_original.py exists as a backup.
- Android copy/paste has repeatedly removed Python indentation, so prefer
  providing complete downloadable files and one instruction at a time.

Continue from the section called Recommended Next Steps. Do not replace
main.py or boot.py until you first inspect and verify their exact current
contents. Give only one action at a time and wait for my result.
```

---

## 15. Safety Rules for Future OTA Work

- Never update `boot.py` and `main.py` in the same OTA transaction.
- Never delete `boot_original.py` until main recovery is fully proven.
- Never install directly over a working file before a `.bak` exists.
- Always download as `.new` first.
- Always reject empty downloads.
- Always require HTTP status 200.
- Always compile Python files before installation.
- Always validate behavior after installation.
- Restore the backup automatically if runtime validation fails.
- Keep Wi-Fi credentials out of GitHub.
- Avoid tokenized GitHub Raw URLs. Use public token-free Raw URLs.
- Change the hotspot password that was exposed during testing.
- Prefer complete file uploads over long Android copy/paste operations.

---

## 16. Current Proven OTA Architecture

```text
GitHub public repository
        |
        | HTTPS Raw URL
        v
ESP32 downloads filename.new
        |
        v
Reject non-200 or empty response
        |
        v
Compile Python source
        |
        v
Rename current file to filename.bak
        |
        v
Rename filename.new to filename
        |
        v
Import and run validation
        |
        +-- Success --> Remove .bak
        |
        `-- Failure --> Remove failed file and restore .bak
```

This architecture is proven for ordinary MicroPython modules. The additional boot-confirmation layer is still required before applying it to automatically executed `main.py`.
