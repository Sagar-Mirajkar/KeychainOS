"""BLE advertisement scanner for ESP32-S3 MicroPython."""
import bluetooth
import time

_IRQ_SCAN_RESULT = 5
_IRQ_SCAN_DONE = 6

class BLEScanner:
    def __init__(self):
        self.ble = bluetooth.BLE()
        self.ble.active(True)
        self.results = []
        self.ble.irq(self._irq)

    def _irq(self, event, data):
        if event == _IRQ_SCAN_RESULT:
            address_type, address, adv_type, rssi, adv_data = data
            key = bytes(address)
            if not any(item[0] == key for item in self.results):
                self.results.append((key, rssi, bytes(adv_data)))

    def scan(self, duration_ms=5000):
        self.results = []
        self.ble.gap_scan(duration_ms, 30000, 30000)
        time.sleep_ms(duration_ms + 200)
        return self.results


def run(display, touch, ui):
    scanner = BLEScanner()
    display.fill(0x0841)
    ui.centred_text(display, "BLE SCANNING", 30, 0x07FF, 0x0841)
    results = scanner.scan()
    for index, item in enumerate(results[:10]):
        address = ":".join("{:02X}".format(byte) for byte in item[0])
        ui.draw_text(display, address[:17] + " " + str(item[1]), 4, 60 + index * 22, 0xFFFF, 0x0841, 232)
    while True:
        gesture = touch.capture_gesture()
        if gesture and gesture[0] in ("RIGHT", "TAP"): return "EXIT"
