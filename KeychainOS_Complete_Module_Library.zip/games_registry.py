"""Games available in KeychainOS."""
GAMES = (
    ("SNAKE", "snake"),
    ("TIC TAC TOE", "tic_tac_toe"),
)
