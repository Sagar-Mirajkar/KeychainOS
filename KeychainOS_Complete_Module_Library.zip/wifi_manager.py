"""Wi-Fi connection manager for KeychainOS."""
import network
import time

wlan = network.WLAN(network.STA_IF)


def enable():
    wlan.active(True)


def disable():
    wlan.active(False)


def connect(ssid, password, timeout_seconds=30):
    enable()
    if wlan.isconnected():
        return True
    wlan.connect(ssid, password)
    started = time.ticks_ms()
    while not wlan.isconnected():
        if time.ticks_diff(time.ticks_ms(), started) > timeout_seconds * 1000:
            return False
        time.sleep_ms(250)
    return True


def disconnect():
    wlan.disconnect()


def status():
    return {
        "active": wlan.active(),
        "connected": wlan.isconnected(),
        "ifconfig": wlan.ifconfig() if wlan.isconnected() else None,
        "rssi": wlan.status("rssi") if wlan.isconnected() else None
    }


def scan():
    enable()
    return wlan.scan()
