"""Random number generator."""
import random

def run(display,touch,ui):
    value=random.randint(1,100)
    while True:
        display.fill(0x0841); ui.centred_text(display,"RANDOM 1-100",40,0xFFE0,0x0841); ui.centred_text(display,str(value),135,0x07FF,0x0841)
        g=touch.capture_gesture()
        if g and g[0]=="RIGHT": return "EXIT"
        if g and g[0]=="TAP": value=random.randint(1,100)
