"""Small text-file viewer with vertical paging."""

def run(display, touch, ui, path="/last_error.txt"):
    try: text = open(path, "r").read()
    except Exception as error: text = repr(error)
    lines = text.splitlines() or [""]
    offset = 0
    while True:
        display.fill(0x0841)
        ui.draw_text(display, "< VIEWER", 8, 8, 0xFFFF, 0x001F, 80)
        for index, line in enumerate(lines[offset:offset + 15]):
            ui.draw_text(display, line[:28], 6, 40 + index * 18, 0xFFFF, 0x0841, 228)
        gesture = touch.capture_gesture()
        if gesture and gesture[0] == "RIGHT": return "EXIT"
        if gesture and gesture[0] == "UP": offset = min(max(0, len(lines) - 15), offset + 5)
        elif gesture and gesture[0] == "DOWN": offset = max(0, offset - 5)
