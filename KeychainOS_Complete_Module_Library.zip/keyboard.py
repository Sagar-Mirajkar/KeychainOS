"""Simple touch on-screen keyboard for KeychainOS."""
import time

ROWS = ("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM", " 123 < OK")


def draw(display, ui, text):
    display.fill(0x0841)
    ui.draw_text(display, text[-26:], 8, 20, 0xFFFF, 0x0000, 224)
    y = 70
    for row in ROWS:
        width = 240 // len(row)
        for index, char in enumerate(row):
            x = index * width
            display.outline_rect(x + 1, y, width - 2, 44, 0xFFFF, 1)
            ui.draw_text(display, char, x + max(2, (width - 8) // 2), y + 15, 0xFFFF, 0x0841, 8)
        y += 50


def run(display, touch, ui, initial=""):
    text = initial
    while True:
        draw(display, ui, text)
        gesture = touch.capture_gesture()
        if gesture is None:
            time.sleep_ms(10)
            continue
        kind, x, y = gesture
        if kind == "RIGHT":
            return None
        if kind != "TAP" or y < 70:
            continue
        row_index = min(3, (y - 70) // 50)
        row = ROWS[row_index]
        width = 240 // len(row)
        index = min(len(row) - 1, x // width)
        char = row[index]
        if row_index == 3:
            if char == "<": text = text[:-1]
            elif char == "O" or char == "K": return text
            elif char == " ": text += " "
        elif len(text) < 120:
            text += char
