"""Registry loader for KeychainOS applications."""

HOME = (
    ("FILES", "file_manager", "app"),
    ("GAMES", "games_registry", "menu"),
    ("TOOLS", "tools_registry", "menu"),
    ("NOTES", "notes", "app"),
    ("SETTINGS", "settings_registry", "menu"),
)


def import_module(module_name):
    return __import__(module_name)


def launch(module_name, display, touch, ui):
    module = import_module(module_name)
    if not hasattr(module, "run"):
        raise AttributeError(module_name + " has no run()")
    return module.run(display, touch, ui)
