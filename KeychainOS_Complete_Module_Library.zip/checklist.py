"""Persistent checklist utility."""
import json
import keyboard

FILE = "/checklist.json"


def load():
    try: return json.load(open(FILE, "r"))
    except Exception: return []


def save(items):
    with open(FILE, "w") as output: json.dump(items, output)


def run(display, touch, ui):
    items = load()
    while True:
        display.fill(0x0841)
        ui.centred_text(display, "CHECKLIST", 20, 0xFFE0, 0x0841)
        for index, item in enumerate(items[:7]):
            mark = "[X] " if item.get("done") else "[ ] "
            ui.draw_text(display, mark + item.get("text", "")[:20], 8, 55 + index * 32, 0xFFFF, 0x0841, 224)
        ui.centred_text(display, "Tap row / bottom adds", 285, 0xA514, 0x0841)
        gesture = touch.capture_gesture()
        if gesture and gesture[0] == "RIGHT": save(items); return "EXIT"
        if gesture and gesture[0] == "TAP":
            row = (gesture[2] - 55) // 32
            if 0 <= row < len(items): items[row]["done"] = not items[row].get("done")
            elif gesture[2] > 260:
                value = keyboard.run(display, touch, ui, "")
                if value: items.append({"text": value, "done": False})
