"""Protected internal-flash file browser."""
import os


def run(display, touch, ui):
    path = "/"
    offset = 0
    while True:
        names = sorted(os.listdir(path))
        display.fill(0x0841)
        ui.draw_text(display, "< FILES", 8, 8, 0xFFFF, 0x001F, 72)
        for index, name in enumerate(names[offset:offset + 12]):
            ui.draw_text(display, name[:27], 8, 42 + index * 21, 0xFFFF, 0x0841, 220)
        gesture = touch.capture_gesture()
        if gesture and gesture[0] == "RIGHT": return "EXIT"
        if gesture and gesture[0] == "UP": offset = min(max(0, len(names) - 12), offset + 4)
        elif gesture and gesture[0] == "DOWN": offset = max(0, offset - 4)
