"""Recovery markers for future main.py OTA updates."""
import os

PENDING = "/ota_main_pending"
TESTING = "/ota_main_testing"
MAIN = "/main.py"
BACKUP = "/main.py.bak"


def exists(path):
    try: os.stat(path); return True
    except OSError: return False


def on_boot():
    if exists(TESTING):
        try: os.remove(MAIN)
        except OSError: pass
        if exists(BACKUP): os.rename(BACKUP, MAIN)
        try: os.remove(TESTING)
        except OSError: pass
        return False
    if exists(PENDING):
        os.rename(PENDING, TESTING)
    return True


def confirm():
    try: os.remove(TESTING)
    except OSError: pass
    try: os.remove(BACKUP)
    except OSError: pass
