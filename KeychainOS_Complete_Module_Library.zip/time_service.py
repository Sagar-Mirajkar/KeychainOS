"""RTC, time format, timezone, and NTP services."""
from machine import RTC
import time

rtc = RTC()


def now():
    return rtc.datetime()


def set_datetime(year, month, day, weekday, hour, minute, second):
    rtc.datetime((year, month, day, weekday, hour, minute, second, 0))


def sync_ntp(host="pool.ntp.org"):
    import ntptime
    ntptime.host = host
    ntptime.settime()
    return rtc.datetime()


def apply_timezone_minutes(minutes):
    seconds = int(minutes) * 60
    epoch = time.time() + seconds
    values = time.localtime(epoch)
    rtc.datetime((values[0], values[1], values[2], values[6], values[3], values[4], values[5], 0))
    return rtc.datetime()


def format_time(date_time, use_24=True):
    hour, minute, second = date_time[4], date_time[5], date_time[6]
    if use_24:
        return "{:02d}:{:02d}:{:02d}".format(hour, minute, second)
    suffix = "AM" if hour < 12 else "PM"
    hour = hour % 12 or 12
    return "{:02d}:{:02d}:{:02d} {}".format(hour, minute, second, suffix)
