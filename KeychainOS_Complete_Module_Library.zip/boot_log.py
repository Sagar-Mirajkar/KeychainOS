"""Persistent boot and error logger."""
LOG_FILE = "/last_error.txt"


def write_error(source, error):
    with open(LOG_FILE, "w") as output:
        output.write(str(source) + "\n")
        output.write(repr(error) + "\n")


def read_error():
    try:
        return open(LOG_FILE, "r").read()
    except OSError:
        return ""


def clear():
    import os
    try:
        os.remove(LOG_FILE)
    except OSError:
        pass
