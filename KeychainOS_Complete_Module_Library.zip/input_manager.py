"""Unified touch and future external-input event manager."""
class InputManager:
    def __init__(self, touch):
        self.touch = touch
        self.external_queue = []

    def push_external(self, event):
        self.external_queue.append(event)

    def poll(self):
        if self.external_queue:
            return self.external_queue.pop(0)
        gesture = self.touch.poll_gesture()
        if gesture is None:
            return None
        return ("GESTURE", gesture)

    def wait(self):
        if self.external_queue:
            return self.external_queue.pop(0)
        return ("TOUCH", self.touch.capture_gesture())
