"""Persistent alarm storage and due-alarm checking."""
import json

ALARM_FILE = "/alarms.json"


def load():
    try:
        value = json.load(open(ALARM_FILE, "r"))
        return value if isinstance(value, list) else []
    except Exception:
        return []


def save(alarms):
    with open(ALARM_FILE + ".new", "w") as output:
        json.dump(alarms, output)
    import os
    try:
        os.remove(ALARM_FILE)
    except OSError:
        pass
    os.rename(ALARM_FILE + ".new", ALARM_FILE)


def add(hour, minute, label="Alarm", enabled=True):
    alarms = load()
    alarms.append({"hour": hour, "minute": minute, "label": label, "enabled": enabled})
    save(alarms)
    return alarms


def due(date_time):
    hour, minute = date_time[4], date_time[5]
    return [a for a in load() if a.get("enabled") and a.get("hour") == hour and a.get("minute") == minute]
