"""Ohm's Law reference calculator."""

def calculate(voltage=None,current=None,resistance=None):
    if voltage is None: return current*resistance
    if current is None: return voltage/resistance
    if resistance is None: return voltage/current
    return None

def run(display,touch,ui):
    display.fill(0x0841); ui.centred_text(display,"OHM'S LAW",30,0xFFE0,0x0841); ui.centred_text(display,"V = I x R",105,0x07FF,0x0841); ui.centred_text(display,"I = V / R",145,0xFFFF,0x0841); ui.centred_text(display,"R = V / I",185,0xFFFF,0x0841)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ("RIGHT","TAP"): return "EXIT"
