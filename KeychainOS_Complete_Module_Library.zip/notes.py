"""Persistent plain-text Notes app."""
import os
import keyboard

NOTES_DIR = "/notes"


def ensure_dir():
    try:
        os.mkdir(NOTES_DIR)
    except OSError:
        pass


def list_notes():
    ensure_dir()
    return sorted(os.listdir(NOTES_DIR))


def save_note(name, text):
    ensure_dir()
    safe = name.replace("/", "_") or "note"
    with open(NOTES_DIR + "/" + safe + ".txt", "w") as output:
        output.write(text)


def run(display, touch, ui):
    ensure_dir()
    display.fill(0x0841)
    ui.centred_text(display, "NOTES", 40, 0xFFE0, 0x0841)
    ui.centred_text(display, "Tap to create note", 130, 0xFFFF, 0x0841)
    ui.centred_text(display, "Swipe right to exit", 280, 0xA514, 0x0841)
    while True:
        gesture = touch.capture_gesture()
        if gesture and gesture[0] == "RIGHT": return "EXIT"
        if gesture and gesture[0] == "TAP":
            text = keyboard.run(display, touch, ui, "")
            if text:
                save_note("note_" + str(len(list_notes()) + 1), text)
            return "EXIT"
