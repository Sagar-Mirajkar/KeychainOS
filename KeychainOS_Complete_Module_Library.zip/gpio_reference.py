"""Read-only KeychainOS GPIO reference."""
ROWS=("LCD SCLK 1","LCD MOSI 2","LCD MISO 42","LCD CS 39","LCD DC 41","LCD RST 40","LCD BL 6","SD CS 38","TOUCH SDA 15","TOUCH SCL 7","TOUCH RST 16","TOUCH INT 17")

def run(display,touch,ui):
    display.fill(0x0841); ui.centred_text(display,"GPIO REFERENCE",15,0xFFE0,0x0841)
    for i,text in enumerate(ROWS): ui.draw_text(display,text,15,45+i*21,0xFFFF,0x0841,210)
    while True:
        g=touch.capture_gesture()
        if g and g[0] in ("RIGHT","TAP"): return "EXIT"
