"""Decimal, hex, binary, and octal converter."""

def formats(value): return str(value), hex(value), bin(value), oct(value)

def run(display,touch,ui):
    value=10
    while True:
        display.fill(0x0841); dec,hx,bn,oc=formats(value); ui.centred_text(display,"NUMBER CONVERTER",20,0xFFE0,0x0841)
        for i,text in enumerate(("DEC "+dec,"HEX "+hx,"BIN "+bn,"OCT "+oc)): ui.draw_text(display,text,10,65+i*42,0xFFFF,0x0841,220)
        g=touch.capture_gesture()
        if g and g[0]=="RIGHT": return "EXIT"
        if g and g[0]=="TAP": value+=1 if g[2]<170 else -1
