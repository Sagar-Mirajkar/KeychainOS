"""Interactive display, touch, I2C, and memory hardware test."""
import gc


def run(display, touch, ui):
    colours = (0xF800, 0x07E0, 0x001F, 0xFFFF, 0x0000)
    index = 0
    while True:
        display.fill(colours[index])
        ui.draw_text(display, "Tap: next", 70, 140, 0xFFFF if index != 3 else 0x0000, colours[index], 80)
        gesture = touch.capture_gesture()
        if gesture and gesture[0] == "RIGHT": return "EXIT"
        if gesture and gesture[0] == "TAP": index = (index + 1) % len(colours)
