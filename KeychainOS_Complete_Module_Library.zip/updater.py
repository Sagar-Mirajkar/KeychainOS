"""Manifest-driven safe multi-file OTA updater."""
import gc
import hashlib
import json
import os
import sys

try:
    import requests
except ImportError:
    import urequests as requests


def download(url):
    response = requests.get(url)
    try:
        if getattr(response, "status_code", 200) != 200:
            raise RuntimeError("HTTP failure")
        return response.content
    finally:
        response.close()


def sha256(data):
    value = hashlib.sha256(data).digest()
    return "".join("{:02x}".format(byte) for byte in value)


def update_file(path, data, expected_hash=None):
    if expected_hash and sha256(data) != expected_hash.lower():
        raise ValueError("SHA-256 mismatch")
    temp = path + ".new"
    backup = path + ".bak"
    if path.endswith(".py"):
        compile(data.decode("utf-8"), path, "exec")
    with open(temp, "wb") as output: output.write(data)
    try:
        os.remove(backup)
    except OSError:
        pass
    try:
        os.rename(path, backup)
    except OSError:
        pass
    try:
        os.rename(temp, path)
    except Exception:
        try: os.rename(backup, path)
        except OSError: pass
        raise
    return backup


def update_from_manifest(url):
    manifest = json.loads(download(url).decode("utf-8"))
    backups = []
    try:
        for item in manifest.get("files", []):
            data = download(item["url"])
            backups.append((item["path"], update_file(item["path"], data, item.get("sha256"))))
        for path, backup in backups:
            try: os.remove(backup)
            except OSError: pass
        return manifest.get("version")
    except Exception:
        for path, backup in reversed(backups):
            try: os.remove(path)
            except OSError: pass
            try: os.rename(backup, path)
            except OSError: pass
        raise
