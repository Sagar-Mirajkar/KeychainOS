"""Timezone presets with half-hour support."""
PRESETS = (
    ("UTC", 0),
    ("INDIA", 330),
    ("DUBAI", 240),
    ("LONDON", 0),
    ("NEW YORK", -300),
    ("LOS ANGELES", -480),
    ("TOKYO", 540),
    ("SYDNEY", 600),
)


def find(name):
    for display_name, minutes in PRESETS:
        if display_name == name:
            return minutes
    return 0
