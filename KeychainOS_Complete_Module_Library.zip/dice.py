"""Touch dice roller."""
import random

def run(display,touch,ui):
    value=1
    while True:
        display.fill(0x0841); ui.centred_text(display,"DICE",30,0xFFE0,0x0841); ui.centred_text(display,str(value),130,0x07FF,0x0841); ui.centred_text(display,"Tap to roll",260,0xFFFF,0x0841)
        g=touch.capture_gesture()
        if g and g[0]=="RIGHT": return "EXIT"
        if g and g[0]=="TAP": value=random.randint(1,6)
