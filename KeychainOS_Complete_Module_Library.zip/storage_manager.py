"""Internal-storage utilities for KeychainOS."""
import os

PROTECTED = ("/boot.py", "/main.py", "/st7789.py", "/touch.py", "/ui.py")


def usage(path="/"):
    values = os.statvfs(path)
    block = values[0]
    total = values[2] * block
    free = values[3] * block
    return {"total": total, "free": free, "used": total - free}


def list_files(path="/"):
    return sorted(os.listdir(path))


def safe_remove(path):
    if path in PROTECTED:
        raise ValueError("Protected system file")
    os.remove(path)


def cleanup_temporary(path="/"):
    removed = []
    for name in os.listdir(path):
        if name.endswith((".new", ".tmp")):
            full = path.rstrip("/") + "/" + name
            os.remove(full)
            removed.append(full)
    return removed
