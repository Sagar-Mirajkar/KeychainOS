"""Safe persistent JSON configuration manager for KeychainOS."""
import json
import os

CONFIG_FILE = "/keychainos_config.json"
TEMP_FILE = CONFIG_FILE + ".new"
BACKUP_FILE = CONFIG_FILE + ".bak"

DEFAULTS = {
    "theme": "minimal_light",
    "time_format": 24,
    "date_format": "YYYY-MM-DD",
    "timezone_minutes": 330,
    "screen_timeout_seconds": 60,
    "brightness_percent": 100,
    "swipe_threshold": 35,
    "wifi_auto_connect": True,
    "developer_mode": False
}


def exists(path):
    try:
        os.stat(path)
        return True
    except OSError:
        return False


def load():
    data = dict(DEFAULTS)
    try:
        with open(CONFIG_FILE, "r") as source:
            saved = json.load(source)
        if isinstance(saved, dict):
            data.update(saved)
    except Exception:
        pass
    return data


def save(data):
    with open(TEMP_FILE, "w") as output:
        json.dump(data, output)
    try:
        os.remove(BACKUP_FILE)
    except OSError:
        pass
    if exists(CONFIG_FILE):
        os.rename(CONFIG_FILE, BACKUP_FILE)
    try:
        os.rename(TEMP_FILE, CONFIG_FILE)
        try:
            os.remove(BACKUP_FILE)
        except OSError:
            pass
    except Exception:
        if exists(BACKUP_FILE):
            os.rename(BACKUP_FILE, CONFIG_FILE)
        raise


def get(key, default=None):
    return load().get(key, default)


def set_value(key, value):
    data = load()
    data[key] = value
    save(data)
    return value


def reset_defaults():
    save(dict(DEFAULTS))
    return dict(DEFAULTS)
