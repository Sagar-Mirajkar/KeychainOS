"""KeychainOS diagnostics and syntax checks."""
import gc
import os
import sys


def system_report():
    gc.collect()
    return {
        "free_ram": gc.mem_free(),
        "implementation": str(sys.implementation),
        "root_files": len(os.listdir("/"))
    }


def syntax_check(path):
    source = open(path, "r").read()
    compile(source, path, "exec")
    return True


def check_all_python(path="/"):
    results = []
    for name in os.listdir(path):
        if name.endswith(".py"):
            full = path.rstrip("/") + "/" + name
            try:
                syntax_check(full)
                results.append((name, True, "OK"))
            except Exception as error:
                results.append((name, False, repr(error)))
    return results
