"""Home-screen entries for KeychainOS."""
HOME_APPS = (
    ("FILES", "file_manager"),
    ("GAMES", "games_registry"),
    ("TOOLS", "tools_registry"),
    ("NOTES", "notes"),
    ("SETTINGS", "settings_registry"),
)
