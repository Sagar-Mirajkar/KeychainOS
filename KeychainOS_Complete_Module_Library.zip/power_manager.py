"""Backlight and inactivity manager for KeychainOS."""
import time

class PowerManager:
    def __init__(self, display, timeout_seconds=60):
        self.display = display
        self.timeout_ms = timeout_seconds * 1000
        self.last_activity = time.ticks_ms()
        self.sleeping = False

    def activity(self):
        self.last_activity = time.ticks_ms()
        if self.sleeping:
            self.wake()

    def set_timeout(self, seconds):
        self.timeout_ms = max(0, int(seconds) * 1000)

    def sleep(self):
        self.display.backlight_off()
        self.sleeping = True

    def wake(self):
        self.display.backlight_on()
        self.sleeping = False
        self.last_activity = time.ticks_ms()

    def update(self):
        if self.timeout_ms and not self.sleeping:
            if time.ticks_diff(time.ticks_ms(), self.last_activity) >= self.timeout_ms:
                self.sleep()
        return self.sleeping
