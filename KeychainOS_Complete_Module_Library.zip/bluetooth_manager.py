"""BLE-only connection capability description and manager shell."""
import bluetooth

ble = bluetooth.BLE()


def enable():
    ble.active(True)


def disable():
    ble.active(False)


def supported_capabilities():
    return {
        "ble_scan": True,
        "ble_gatt_client": True,
        "ble_hid_host": "future work",
        "classic_a2dp_audio": False,
        "classic_hid": False
    }
