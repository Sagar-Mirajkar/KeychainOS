"""Common notification and confirmation screens."""
import time


def banner(display, ui, text, colour=0x001F, duration_ms=900):
    display.fill_rect(8, 36, 224, 34, colour)
    ui.centred_text(display, text, 45, 0xFFFF, colour)
    time.sleep_ms(duration_ms)


def alert(display, touch, ui, title, message, colour=0xF800):
    display.fill(0x0841)
    display.fill_rect(0, 0, 240, 38, colour)
    ui.centred_text(display, title, 10, 0xFFFF, colour)
    ui.centred_text(display, message, 130, 0xFFFF, 0x0841)
    ui.centred_text(display, "Tap to close", 280, 0xFFE0, 0x0841)
    while True:
        gesture = touch.capture_gesture()
        if gesture and gesture[0] in ("TAP", "RIGHT"):
            return


def confirm(display, touch, ui, title, message):
    display.fill(0x0841)
    ui.centred_text(display, title, 50, 0xFFE0, 0x0841)
    ui.centred_text(display, message, 100, 0xFFFF, 0x0841)
    ui.centred_text(display, "Tap top: YES", 220, 0x07E0, 0x0841)
    ui.centred_text(display, "Tap bottom: NO", 260, 0xF800, 0x0841)
    while True:
        gesture = touch.capture_gesture()
        if gesture and gesture[0] == "TAP":
            return gesture[2] < 240
        if gesture and gesture[0] == "RIGHT":
            return False
